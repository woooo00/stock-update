package com.apple.stockmonitor

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import android.graphics.drawable.ColorDrawable
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 主界面（按高保真预览重写）：深色苹果风三视图（监控 / 记录 / 设置），
 * 常用 3 城门店直选 + 其他城市折叠分组 + 搜索、多目标监控列表、六档间隔、
 * 限流自适应开关、SendKey 留空 + 申请入口 + 测试推送。
 */
class MainActivity : Activity() {

    // 配色
    private val BG = Color.parseColor("#070B12")
    private val CARD = Color.parseColor("#121927")
    private val CARD2 = Color.parseColor("#182133")
    private val LINE = Color.parseColor("#222D42")
    private val TXT = Color.parseColor("#EEF2F8")
    private val SUB = Color.parseColor("#8B98AF")
    private val FAINT = Color.parseColor("#5F6C83")
    private val BLUE = Color.parseColor("#3B82F6")
    private val GREEN = Color.parseColor("#34D399")
    private val RED = Color.parseColor("#F0565B")
    private val AMBER = Color.parseColor("#FBBF24")
    private val CHIP_ON_BG = Color.parseColor("#1A3A6B")
    private val CHIP_ON_TXT = Color.parseColor("#9CC2FF")

    // 状态
    private val initialModel = Catalog.parsePart(Prefs.DEFAULT_PART)
    private var selSize = Catalog.SIZES.indexOf(initialModel.first).coerceAtLeast(0)
    private var selStorage = Catalog.STORAGES.indexOf(initialModel.second).coerceAtLeast(0)
    private var selColor = Catalog.COLORS_PRO.indexOf(initialModel.third).coerceAtLeast(0)
    private var selModel = Catalog.MODELS.indexOfFirst { it.part == Prefs.DEFAULT_PART }.coerceAtLeast(0)
    private var selStore = "R639"
    private var selIvl = 3 // 默认 60s
    private var running = false
    private val openCities = mutableSetOf("广州")
    private var openRest = false

    // 视图
    private lateinit var vMonitor: ScrollView
    private lateinit var vLog: ScrollView
    private lateinit var vSetting: ScrollView
    private lateinit var tabMonitor: LinearLayout
    private lateinit var tabLog: LinearLayout
    private lateinit var tabSetting: LinearLayout
    private lateinit var maskAdd: FrameLayout
    private lateinit var sheetAdd: LinearLayout
    private lateinit var storeTreeBox: LinearLayout
    private lateinit var targetListBox: LinearLayout
    private lateinit var logBox: LinearLayout
    private lateinit var sizeChipsBox: LinearLayout
    private lateinit var colorChipsBox: LinearLayout
    private lateinit var storageChipsBox: LinearLayout
    private lateinit var modelBox: LinearLayout
    private lateinit var ivlChipsBox: FlowLayout
    private lateinit var ivlNetText: TextView
    private lateinit var updateBanner: LinearLayout
    private lateinit var updateBannerText: TextView
    private lateinit var netPolicyBox: LinearLayout
    private lateinit var searchInput: EditText
    private lateinit var heroDot: View
    private lateinit var heroState: TextView
    private lateinit var heroBig: TextView
    private lateinit var heroTarget: TextView
    private lateinit var mLast: TextView
    private lateinit var mNext: TextView
    private lateinit var mStreak: TextView
    private lateinit var btnToggle: TextView
    private lateinit var btnCheck: TextView
    private lateinit var inputKey: EditText
    // 多选门店：添加记录时选中的门店code集合
    private val addSelectedStores = mutableSetOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 隐私政策：未同意则强制弹窗，拒绝退出
        if (!Prefs.privacyAgreed(this)) {
            showPrivacyConsent()
            return
        }

        requestNotifPermission()

        val root = FrameLayout(this)
        root.setBackgroundColor(BG)

        val column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL
        root.addView(column, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        // ---- 顶栏 ----
        val topbar = LinearLayout(this)
        topbar.orientation = LinearLayout.HORIZONTAL
        topbar.gravity = Gravity.CENTER_VERTICAL
        topbar.setPadding(dp(20), dp(18), dp(20), dp(4))
        column.addView(topbar, lpW())

        val titleBox = LinearLayout(this)
        titleBox.orientation = LinearLayout.VERTICAL
        val title = TextView(this)
        title.text = "库存提醒助手"
        title.setTextColor(TXT)
        title.textSize = 21f
        title.setTypeface(null, Typeface.BOLD)
        titleBox.addView(title)
        val subtitle = TextView(this)
        subtitle.text = "苹果官网自提库存"
        subtitle.setTextColor(SUB)
        subtitle.textSize = 12f
        titleBox.addView(subtitle)
        topbar.addView(titleBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val gear = iconBtn("⚙")
        gear.setOnClickListener { switchTab(2) }
        topbar.addView(gear)

        // ---- 三个视图 ----
        vMonitor = makeScrolled()
        vLog = makeScrolled()
        vSetting = makeScrolled()
        column.addView(vMonitor, lpMM())
        column.addView(vLog, lpMM())
        column.addView(vSetting, lpMM())

        // ---- 底部 tab ----
        val tabbar = LinearLayout(this)
        tabbar.orientation = LinearLayout.HORIZONTAL
        tabbar.gravity = Gravity.CENTER
        tabbar.setPadding(0, dp(8), 0, dp(10))
        tabbar.setBackgroundColor(Color.parseColor("#0C111B"))
        tabMonitor = tab("监控")
        tabLog = tab("记录")
        tabSetting = tab("设置")
        tabbar.addView(tabMonitor, LinearLayout.LayoutParams(0, dp(52), 1f))
        tabbar.addView(tabLog, LinearLayout.LayoutParams(0, dp(52), 1f))
        tabbar.addView(tabSetting, LinearLayout.LayoutParams(0, dp(52), 1f))
        tabMonitor.setOnClickListener { switchTab(0) }
        tabLog.setOnClickListener { switchTab(1) }
        tabSetting.setOnClickListener { switchTab(2) }
        column.addView(tabbar, lpW())

        buildMonitorView()
        buildLogView()
        buildSettingView()

        // ---- 添加目标弹层 ----
        maskAdd = FrameLayout(this)
        maskAdd.setBackgroundColor(Color.parseColor("#8C000000"))
        maskAdd.visibility = View.GONE
        maskAdd.setOnClickListener { if (it === maskAdd) closeAdd() }

        sheetAdd = LinearLayout(this)
        sheetAdd.orientation = LinearLayout.VERTICAL
        sheetAdd.setPadding(dp(20), dp(22), dp(20), dp(30))
        val sheetBg = GradientDrawable()
        sheetBg.cornerRadii = floatArrayOf(dp(22).toFloat(), dp(22).toFloat(), dp(22).toFloat(), dp(22).toFloat(), 0f, 0f, 0f, 0f)
        sheetBg.setColor(CARD2)
        sheetAdd.background = sheetBg
        val sheetWrap = FrameLayout(this)
        sheetWrap.addView(sheetAdd, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM))
        maskAdd.addView(sheetWrap)
        root.addView(maskAdd, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        buildAddSheet()

        setContentView(root)
        switchTab(0)
        refreshAll()

        // 升级迁移：监控记录超过上限时裁掉多余的，明确告知用户而不是静默丢失
        val dropped = Prefs.migrateTargets(this)
        if (dropped > 0) {
            toast("监控记录超过 ${Prefs.MAX_TARGETS} 条，已保留前 ${Prefs.MAX_TARGETS} 条")
        }
        renderUpdateBanner()

        // 启动时检查新版本
        UpdateChecker.check(this) { renderUpdateBanner() }
    }

    // ================= 监控视图 =================
    private fun buildMonitorView() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(24))
        vMonitor.addView(box)

        // ---- 更新提示条：发现新版本后常驻，直到用户更新为止 ----
        updateBanner = LinearLayout(this)
        updateBanner.orientation = LinearLayout.HORIZONTAL
        updateBanner.gravity = Gravity.CENTER_VERTICAL
        updateBanner.setPadding(dp(16), dp(12), dp(16), dp(12))
        updateBanner.isClickable = true
        val ubBg = GradientDrawable()
        ubBg.cornerRadius = dp(14).toFloat()
        ubBg.setColor(Color.parseColor("#2A2410"))
        ubBg.setStroke(dp(1), Color.parseColor("#6B5416"))
        updateBanner.background = ubBg
        updateBannerText = TextView(this)
        updateBannerText.setTextColor(AMBER)
        updateBannerText.textSize = 13.5f
        updateBanner.addView(updateBannerText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val ubGo = TextView(this)
        ubGo.text = "去更新 ›"
        ubGo.setTextColor(AMBER)
        ubGo.setTypeface(null, Typeface.BOLD)
        ubGo.textSize = 13f
        updateBanner.addView(ubGo)
        val ubLp = lpW()
        ubLp.bottomMargin = dp(12)
        box.addView(updateBanner, ubLp)
        updateBanner.visibility = View.GONE
        updateBanner.setOnClickListener { UpdateChecker.promptUpdate(this) }

        // hero 卡
        val hero = card()
        hero.setPadding(dp(20), dp(22), dp(20), dp(22))
        val heroLabel = LinearLayout(this)
        heroLabel.orientation = LinearLayout.HORIZONTAL
        heroLabel.gravity = Gravity.CENTER_VERTICAL
        heroDot = View(this)
        val dotLp = LinearLayout.LayoutParams(dp(9), dp(9))
        dotLp.rightMargin = dp(8)
        dotDot(heroDot, FAINT)
        heroLabel.addView(heroDot, dotLp)
        heroState = TextView(this)
        heroState.text = "监控未启动"
        heroState.setTextColor(SUB)
        heroState.textSize = 13f
        heroLabel.addView(heroState)
        hero.addView(heroLabel)

        heroBig = TextView(this)
        heroBig.text = "当前无货"
        heroBig.textSize = 30f
        heroBig.setTypeface(null, Typeface.BOLD)
        heroBig.setTextColor(FAINT)
        val bigLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        bigLp.topMargin = dp(10)
        hero.addView(heroBig, bigLp)

        heroTarget = TextView(this)
        heroTarget.text = ""
        heroTarget.setTextColor(SUB)
        heroTarget.textSize = 14f
        val tLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        tLp.topMargin = dp(8)
        hero.addView(heroTarget, tLp)

        val metaRow = LinearLayout(this)
        metaRow.orientation = LinearLayout.HORIZONTAL
        val sepLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1))
        sepLp.topMargin = dp(14)
        val sep = View(this)
        sep.setBackgroundColor(LINE)
        hero.addView(sep, sepLp)
        mLast = metaCell(metaRow, "上次检查")
        mNext = metaCell(metaRow, "下次检查")
        mStreak = metaCell(metaRow, "连续无货")
        val metaLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        metaLp.topMargin = dp(14)
        hero.addView(metaRow, metaLp)
        box.addView(hero, lpW())

        // 操作按钮
        val actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        val actLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        actLp.topMargin = dp(16)
        btnToggle = btn("启动监控", BLUE) { toggleMonitor() }
        btnCheck = btn("立即查询", CARD2) { checkOnce() }
        actions.addView(btnToggle, LinearLayout.LayoutParams(0, dp(52), 1f))
        val gap = View(this)
        gap.layoutParams = LinearLayout.LayoutParams(dp(12), 1)
        actions.addView(gap)
        actions.addView(btnCheck, LinearLayout.LayoutParams(0, dp(52), 1f))
        box.addView(actions, actLp)

        // 监控列表（提到监控型号上方）
        groupHeader(box, "监控列表", "＋ 添加目标")
        targetListBox = LinearLayout(this)
        targetListBox.orientation = LinearLayout.VERTICAL
        box.addView(targetListBox, lpW())
        renderTargets()

        // 监控型号（三层胶囊：尺寸 / 颜色 / 内存）
        groupHeader(box, "监控型号", "")
        modelBox = LinearLayout(this)
        modelBox.orientation = LinearLayout.VERTICAL
        box.addView(modelBox, lpW())
        renderModelBox()

        // 关注门店
        groupHeader(box, "关注门店", "常用城市直选，其余收进分组")
        searchInput = EditText(this)
        searchInput.hint = "搜索城市或门店，如：上海 / 万象城"
        searchInput.setTextColor(TXT)
        searchInput.setHintTextColor(FAINT)
        searchInput.setTextSize(14f)
        searchInput.setSingleLine(true)
        searchInput.setBackgroundColor(CARD2)
        searchInput.setPadding(dp(14), dp(12), dp(14), dp(12))
        searchInput.inputType = InputType.TYPE_CLASS_TEXT
        val srchLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        srchLp.topMargin = dp(10)
        box.addView(searchInput, srchLp)
        val srchBg = GradientDrawable()
        srchBg.cornerRadius = dp(12).toFloat()
        srchBg.setColor(CARD2)
        srchBg.setStroke(dp(1), LINE)
        searchInput.background = srchBg
        searchInput.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { renderStoreTree() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        storeTreeBox = LinearLayout(this)
        storeTreeBox.orientation = LinearLayout.VERTICAL
        val treeLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        treeLp.topMargin = dp(10)
        box.addView(storeTreeBox, treeLp)
        renderStoreTree()

        // 门店目录同步：动态拉取官网门店清单（7 天缓存）
        val syncBtn = btn("同步门店列表", CARD2) { startStoreSync() }
        val syncLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46))
        syncLp.topMargin = dp(4)
        box.addView(syncBtn, syncLp)
        box.addView(hintText("门店列表直接取自官网接口，每 7 天自动更新一次，苹果新开门店会自动出现。首次同步约需 3 分钟（受官网限流约束，期间 App 正常使用）。"))

        // 检查间隔
        groupHeader(box, "检查间隔", "")
        ivlNetText = TextView(this)
        ivlNetText.setTextColor(SUB)
        ivlNetText.textSize = 13f
        val ivlTextLp = lpW()
        ivlTextLp.bottomMargin = dp(10)
        box.addView(ivlNetText, ivlTextLp)
        ivlChipsBox = FlowLayout(this)
        ivlChipsBox.hGap = dp(10)
        ivlChipsBox.vGap = dp(10)
        box.addView(ivlChipsBox, lpW())
        renderIvlChips()

        val hint = hintText("说明：仅查询是否有货，不抢货。当前网络是 WiFi 就用高频档，切到移动数据自动降速省流量；被官网限流会自动暂停并恢复。")
        box.addView(hint)
    }

    private fun groupHeader(box: LinearLayout, title: String, action: String) {
        val h = LinearLayout(this)
        h.orientation = LinearLayout.HORIZONTAL
        h.gravity = Gravity.CENTER_VERTICAL
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(22)
        lp.leftMargin = dp(4)
        lp.rightMargin = dp(4)
        lp.bottomMargin = dp(12)
        val t = TextView(this)
        t.text = title
        t.setTextColor(SUB)
        t.textSize = 14f
        t.setTypeface(null, Typeface.BOLD)
        h.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (action.isNotBlank()) {
            val a = TextView(this)
            a.text = action
            a.setTextColor(BLUE)
            a.textSize = 13f
            a.setTypeface(null, Typeface.BOLD)
            a.setOnClickListener { openAdd() }
            h.addView(a)
        }
        box.addView(h, lp)
    }

    private fun metaCell(row: LinearLayout, key: String): TextView {
        val cell = LinearLayout(this)
        cell.orientation = LinearLayout.VERTICAL
        val k = TextView(this)
        k.text = key
        k.setTextColor(FAINT)
        k.textSize = 11f
        cell.addView(k)
        val v = TextView(this)
        v.text = "--:--"
        v.setTextColor(TXT)
        v.textSize = 14f
        v.setTypeface(null, Typeface.BOLD)
        cell.addView(v)
        row.addView(cell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        return v
    }

    // ================= 记录视图 =================
    private fun buildLogView() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(24))
        vLog.addView(box)
        logBox = LinearLayout(this)
        logBox.orientation = LinearLayout.VERTICAL
        box.addView(logBox, lpW())
        renderLog()
    }

    // ================= 设置视图 =================
    private fun buildSettingView() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(24))
        vSetting.addView(box)

        groupHeader(box, "微信推送（Server酱）", "")
        val keyRow = setRow("SendKey", "有货时推送到微信；留空则只用本地通知", null)
        box.addView(keyRow)
        inputKey = EditText(this)
        inputKey.hint = "粘贴你的 SendKey，形如 SCT..."
        inputKey.setText(Prefs.sendkey(this))
        inputKey.setTextColor(TXT)
        inputKey.setHintTextColor(FAINT)
        inputKey.setTextSize(14f)
        inputKey.setSingleLine(true)
        val keyBg = GradientDrawable()
        keyBg.cornerRadius = dp(12).toFloat()
        keyBg.setColor(CARD2)
        keyBg.setStroke(dp(1), LINE)
        inputKey.background = keyBg
        inputKey.setPadding(dp(14), dp(12), dp(14), dp(12))
        box.addView(inputKey, lpW())

        val applyLink = TextView(this)
        applyLink.text = "没有 SendKey？点此去 Server酱 免费申请 →"
        applyLink.setTextColor(BLUE)
        applyLink.textSize = 14f
        applyLink.setTypeface(null, Typeface.BOLD)
        applyLink.setPadding(0, dp(10), 0, 0)
        applyLink.setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://sct.ftqq.com")))
        }
        box.addView(applyLink, lpW())

        val guide = hintText("申请步骤：① 打开 sct.ftqq.com，微信扫码登录；② 首页复制「SendKey」（SCT 开头一长串）；③ 粘贴回上方输入框，点「测试推送」，微信收到消息即配置成功。")
        box.addView(guide)

        val testBtn = btn("测试推送", CARD2) { testPush() }
        val tbLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50))
        tbLp.topMargin = dp(12)
        box.addView(testBtn, tbLp)

        groupHeader(box, "提醒方式", "")
        box.addView(setRow("本地弹窗通知", "有货时弹出高优先级通知",
            Prefs.notifyLocal(this)) { Prefs.saveNotifyLocal(this, it) })
        box.addView(setRow("提示音", "有货时播放提醒音",
            Prefs.notifySound(this)) { Prefs.saveNotifySound(this, it) })
        box.addView(setRow("震动", "有货时震动提醒",
            Prefs.notifyVibrate(this)) { Prefs.saveNotifyVibrate(this, it) })
        // 通知渠道的声音/震动/重要性在 Android 上创建后不可改，
        // 只能由用户在系统通知设置里调整 → 这里给出直达入口。
        val chRow = setRow("系统通知设置", "调整通知渠道的声音、震动与免打扰", null)
        chRow.setOnClickListener { openNotificationSettings() }
        box.addView(chRow)
        box.addView(hintText("提示：如果开了「本地弹窗通知」却收不到横幅或听不到声音，多半是系统把本应用的「有货提醒」渠道静音或降级了，点上面一行去系统设置里调整。"))

        groupHeader(box, "网络策略", "")
        netPolicyBox = LinearLayout(this)
        netPolicyBox.orientation = LinearLayout.VERTICAL
        box.addView(netPolicyBox, lpW())
        renderNetPolicy()
        box.addView(hintText("WiFi 下默认 10 秒（最高频），移动数据下默认 30 秒省流量；切换网络自动生效。同一片区的多个监控目标会合并成一次请求，被官网限流时自动暂停并恢复。"))

        groupHeader(box, "限流自适应", "")
        box.addView(setRow("失败自动降频", "连续被限流或超时，自动拉长间隔，恢复后逐步回落，不硬撞",
            Prefs.adaptive(this)) { Prefs.saveAdaptive(this, it) })
        val rule = hintText("规则：连续 2 次失败 → 临时间隔 ×1.8（最高到 5 分钟）；连续 2 次成功 → 逐步回落回你设定的间隔；失败当轮不立即重试。")
        box.addView(rule)

        groupHeader(box, "后台保活（关键！）", "")
        val batteryBtn = btn("打开电池优化设置", CARD2) {
            try {
                val intent = Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                startActivity(intent)
            } catch (e: Exception) {
                toast("请手动到：设置 → 应用 → 库存提醒助手 → 电池 → 不限制")
            }
        }
        box.addView(batteryBtn, lpW())
        val keepHint = hintText("必须操作：① 点上方按钮，把本App设为「不优化/无限制」；② 系统设置 → 应用 → 自启动 → 允许；③ 最近任务列表里下拉锁定本App。否则系统会杀死后台监控，表现为「显示在运行但不再查询」。")
        box.addView(keepHint)

        groupHeader(box, "诊断与日志", "")
        val exportBtn = btn("导出错误日志（可发送给开发）", BLUE) {
            if (AppLogger.hasLogs(this)) {
                val ok = AppLogger.export(this)
                toast(if (ok) "请选择微信/QQ/文件传输等方式发送" else "导出失败，请稍后重试")
            } else {
                toast("当前没有错误日志")
            }
        }
        box.addView(exportBtn, lpW())
        val clearBtn = btn("清空错误日志", CARD2) {
            AppLogger.clear(this)
            toast("错误日志已清空")
        }
        val clLp = lpW(); clLp.topMargin = dp(10)
        box.addView(clearBtn, clLp)
        box.addView(hintText("日志只保存在本机，包含错误时间、原因、解决建议和设备信息，不含任何账号密码。出现报错后点「导出错误日志」，把文件发给开发人员即可定位问题；每条错误下面都附有对应的可能原因和解决办法。"))

        groupHeader(box, "版本与更新", "")
        var verDesc: TextView? = null
        val updateRow = setRow("检查更新", versionDescText(), null, null) { d -> verDesc = d }
        updateRow.setOnClickListener {
            toast("正在检查更新…")
            UpdateChecker.check(this) {
                renderUpdateBanner()
                verDesc?.text = versionDescText()
            }
        }
        box.addView(updateRow)
        box.addView(hintText("有新版本时，主界面顶部会出现常驻提示条，点它可以随时更新。"))

        groupHeader(box, "关于与隐私", "")
        val privacyRow = setRow("隐私政策", "开发者：TxooxT · 个人信息保护说明", null)
        privacyRow.setOnClickListener { showPrivacyPolicy() }
        box.addView(privacyRow)
        val permRow = setRow("权限说明", "查看本应用申请的每一项权限及其用途", null)
        permRow.setOnClickListener { showPermissionUsage() }
        box.addView(permRow)
        val aboutHint = hintText("库存提醒助手 v${BuildConfig.VERSION_NAME} · 个人开发者 TxooxT · 联系邮箱 403960468@qq.com\n本应用仅查询苹果官方门店库存，不收集位置、通讯录、相册等个人信息。")
        box.addView(aboutHint)
    }

    /**
     * 权限用途说明弹窗：逐条列出申请的权限、用途与影响。
     * 商店审核与用户都能在应用内直接看到，无需跳转外部文档。
     */
    private fun showPermissionUsage() {
        val items = arrayOf(
            "网络访问（INTERNET）\n用于向苹果官方商店查询您所选门店的实时库存状态，并下载本应用自身的官方更新包。",
            "前台服务（FOREGROUND_SERVICE / FOREGROUND_SERVICE_DATA_SYNC）\n用于在您主动开启监控后于后台持续轮询库存。监控关闭后服务立即停止。",
            "通知（POST_NOTIFICATIONS）\n用于在目标门店有货时推送通知提醒。拒绝后不影响其他功能。",
            "振动（VIBRATE）\n用于有货时的震动提醒。",
            "唤醒锁（WAKE_LOCK）\n用于屏幕熄灭时保持后台轮询不被系统休眠中断。",
            "开机广播（RECEIVE_BOOT_COMPLETED）\n用于设备重启后恢复您此前已开启的监控，关闭监控即停止该行为。",
            "安装未知来源应用（REQUEST_INSTALL_PACKAGES）\n仅用于下载并安装本应用自身的官方更新包（设置页「检查更新」）。不会安装任何第三方应用，只在您主动点击更新并确认安装时才需要。",
            "静默下载（DOWNLOAD_WITHOUT_NOTIFICATION）\n用于通过系统下载管理器获取更新包。"
        )
        val sv = ScrollView(this)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(16), dp(20), dp(16))
        items.forEach { txt ->
            val tv = TextView(this)
            tv.text = txt
            tv.setTextColor(TXT)
            tv.textSize = 13f
            tv.setLineSpacing(0f, 1.35f)
            tv.setPadding(0, 0, 0, dp(14))
            box.addView(tv)
        }
        sv.addView(box)
        android.app.AlertDialog.Builder(this)
            .setTitle("权限说明")
            .setView(sv)
            .setPositiveButton("关闭", null)
            .show()
    }

    /**
     * 打开本应用的系统通知设置。
     *
     * 优先跳到「有货提醒」渠道的详情页（Android 8.0+ 支持）：
     * 渠道的声音、震动模式、重要性一旦创建就不可由 App 修改，
     * 只能由用户在这里改。
     * 拿不到渠道页时退回到应用通知设置列表页。
     */
    private fun openNotificationSettings() {
        val channelId = MonitorService.CHANNEL_ALERT
        val intents = listOf(
            // API 26+：直接进渠道详情
            android.content.Intent(android.provider.Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, packageName)
                .putExtra(android.provider.Settings.EXTRA_CHANNEL_ID, channelId),
            // 通用：应用通知设置页
            android.content.Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, packageName),
            // 兜底：应用详情页
            android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                .setData(android.net.Uri.parse("package:$packageName"))
        )
        for (i in intents) {
            try {
                startActivity(i)
                return
            } catch (e: Exception) {
                // 换下一个候选
            }
        }
        toast("请到系统设置 → 应用 → 库存提醒助手 → 通知 中调整")
    }

    /** 版本状态文案：有待更新版本时直接显示。 */
    private fun versionDescText(): String {
        val cur = "v${BuildConfig.VERSION_NAME}"
        val pending = UpdateChecker.pendingUpdate(this)
        return if (pending != null) "$cur · 有新版本 v${pending.versionName} 可更新"
        else "$cur · 点击检查是否有新版本"
    }

    // ================= 添加目标弹层 =================
    private fun buildAddSheet() {
        val t = TextView(this)
        t.text = "添加监控目标"
        t.setTextColor(TXT)
        t.textSize = 17f
        t.setTypeface(null, Typeface.BOLD)
        sheetAdd.addView(t)

        val lbl1 = sheetLabel("选择型号")
        sheetAdd.addView(lbl1)
        sheetAdd.addView(chipRow("机型", Catalog.SIZES, { selSize }) { pos ->
            selSize = pos; selColor = 0; updateAddSelModel()
            // 重建弹层
            sheetAdd.removeAllViews()
            buildAddSheet()
        }, lpW())
        val scLp = lpW(); scLp.topMargin = dp(8)
        sheetAdd.addView(chipRow("内存", Catalog.STORAGES, { selStorage }) { pos ->
            selStorage = pos; updateAddSelModel()
            sheetAdd.removeAllViews(); buildAddSheet()
        }, scLp)
        val addColorBox = LinearLayout(this)
        addColorBox.orientation = LinearLayout.VERTICAL
        val acLp = lpW(); acLp.topMargin = dp(8)
        sheetAdd.addView(addColorBox, acLp)
        addColorBox.addView(chipRow("颜色", Catalog.colorsFor(Catalog.SIZES[selSize]), { selColor }) { pos ->
            selColor = pos; updateAddSelModel()
            sheetAdd.removeAllViews(); buildAddSheet()
        })

        val lbl2 = sheetLabel("选择门店（可多选）")
        sheetAdd.addView(lbl2)

        // 多选门店列表
        val storeScroll = ScrollView(this)
        val storeBox = LinearLayout(this)
        storeBox.orientation = LinearLayout.VERTICAL
        storeScroll.addView(storeBox)
        val scrollLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(280))
        scrollLp.topMargin = dp(4)
        storeScroll.layoutParams = scrollLp

        // 初始化默认选中当前门店
        if (addSelectedStores.isEmpty()) addSelectedStores.add(selStore)

        // 门店列表来源：动态目录（接口拉取 + 7 天缓存）优先，
        // 没有缓存时才用内置表兜底。分组按接口返回的 city 字段。
        val dynamic = StoreDirectory.cachedStores(this)
        if (dynamic.isEmpty()) {
            // 还没有任何缓存：提示先同步
            val tip = hintText("门店列表正在获取，首次使用需要联网同步一次（约 3 分钟）。也可以先从内置列表选择。")
            storeBox.addView(tip)
        }
        dynamic.forEach { (city, entries) ->
            storeBox.addView(cityHeader(city, entries.size))
            entries.forEach { e ->
                storeBox.addView(makeMultiStoreRow(Catalog.StoreOpt(e.code, e.name, e.city)))
            }
        }
        if (dynamic.isNotEmpty()) {
            // 动态目录已加载完，再补上内置表里动态目录没有的门店
            val known = dynamic.values.flatten().map { it.code }.toSet()
            val missing = Catalog.CITY_STORES.filter { (city, stores) ->
                stores.any { it.code !in known }
            }
            if (missing.isNotEmpty()) {
                storeBox.addView(cityHeader("其他门店（${missing.sumOf { it.second.size }} 家）", 0))
                missing.forEach { (city, stores) ->
                    stores.filter { it.code !in known }.forEach { s ->
                        storeBox.addView(makeMultiStoreRow(s))
                    }
                }
            }
        }
        sheetAdd.addView(storeScroll)

        val btnRow = LinearLayout(this)
        btnRow.orientation = LinearLayout.HORIZONTAL
        val brLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52))
        brLp.topMargin = dp(20)
        val cancel = btn("取消", CARD) { closeAdd() }
        val ok = btn("加入列表", BLUE) { confirmAdd() }
        btnRow.addView(cancel, LinearLayout.LayoutParams(0, dp(52), 1f))
        val gap = View(this)
        gap.layoutParams = LinearLayout.LayoutParams(dp(10), 1)
        btnRow.addView(gap)
        btnRow.addView(ok, LinearLayout.LayoutParams(0, dp(52), 1f))
        sheetAdd.addView(btnRow, brLp)
    }

    private fun sheetLabel(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(SUB)
        t.textSize = 13f
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(16)
        lp.bottomMargin = dp(8)
        t.layoutParams = lp
        return t
    }

    /**
     * 手动触发门店目录同步。
     *
     * 同步期间不阻塞界面：后台按请求预算逐个片区拉取，
     * 撞到官网限流会自动暂停，等冷却期过后再继续。
     */
    private fun startStoreSync() {
        val total = Catalog.locations().size
        toast("开始同步门店列表（约 $total 个片区，约 3 分钟）")
        StoreDirectory.syncAll(this, Catalog.MODELS[selModel].part) { synced, totalN ->
            runOnUiThread {
                StoreDirectory.loadSnapshot(this)
                renderStoreTree()
                toast("门店列表已更新：$synced/$totalN 个片区")
            }
        }
    }

    /** 门店分组标题行：城市名 + 门店数。 */
    private fun cityHeader(city: String, count: Int): TextView {
        val t = TextView(this)
        t.text = if (count > 0) "$city · $count 家" else city
        t.setTextColor(SUB)
        t.textSize = 12f
        t.setTypeface(null, Typeface.BOLD)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(10)
        lp.leftMargin = dp(4)
        t.layoutParams = lp
        return t
    }

    /**
     * 生成多选门店行：带勾选框样式，点击切换选中状态。
     * 维护中的门店置灰，点击只提示不选中。
     */
    private fun makeMultiStoreRow(s: Catalog.StoreOpt): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(12), dp(10), dp(12), dp(10))
        row.isClickable = true

        val unavailable = Catalog.isStoreUnavailable(s.code)
        val checked = !unavailable && (s.code in addSelectedStores)
        val bg = GradientDrawable()
        bg.cornerRadius = dp(10).toFloat()
        bg.setColor(if (checked) CHIP_ON_BG else CARD)
        bg.setStroke(dp(1), if (checked) BLUE else LINE)
        row.background = bg

        // 勾选框
        val box = TextView(this)
        box.text = if (checked) "✓" else ""
        box.gravity = Gravity.CENTER
        box.setTextColor(Color.WHITE)
        box.textSize = 14f
        val boxLp = LinearLayout.LayoutParams(dp(22), dp(22))
        boxLp.rightMargin = dp(10)
        val boxBg = GradientDrawable()
        boxBg.cornerRadius = dp(6).toFloat()
        boxBg.setColor(if (checked) BLUE else Color.TRANSPARENT)
        boxBg.setStroke(dp(1.5f), if (checked) BLUE else FAINT)
        box.background = boxBg
        row.addView(box, boxLp)

        // 门店名
        val name = TextView(this)
        name.text = s.name
        name.setTextColor(if (unavailable) FAINT else if (checked) CHIP_ON_TXT else TXT)
        name.textSize = 14f
        if (checked) name.setTypeface(null, Typeface.BOLD)
        row.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (unavailable) {
            val tag = TextView(this)
            tag.text = "维护中"
            tag.setTextColor(AMBER)
            tag.textSize = 11f
            tag.setPadding(dp(8), 0, dp(2), 0)
            row.addView(tag)
        }

        row.setOnClickListener {
            if (unavailable) {
                toast(Catalog.STORE_UNAVAILABLE_TIP)
                return@setOnClickListener
            }
            if (s.code in addSelectedStores) {
                addSelectedStores.remove(s.code)
            } else {
                val room = Prefs.MAX_TARGETS - Prefs.targets(this).size
                if (addSelectedStores.size >= room) {
                    toast("最多 ${Prefs.MAX_TARGETS} 条监控记录，请先删除已有记录")
                    return@setOnClickListener
                }
                addSelectedStores.add(s.code)
            }
            // 重建弹层刷新勾选状态
            sheetAdd.removeAllViews()
            buildAddSheet()
        }
        return row
    }

    // ================= 渲染 =================
    /** 三级 Spinner 变化时组合出 part number，同步到监控目标。 */
    /** 生成一行带左侧标签的胶囊按钮组；getSelected 返回当前选中位置。 */
    private fun chipRow(label: String, options: List<String>, getSelected: () -> Int, onPick: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(CARD)
            setStroke(dp(1), LINE)
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48))
        row.layoutParams = lp
        val lbl = TextView(this)
        lbl.text = label
        lbl.setTextColor(SUB)
        lbl.textSize = 14f
        val lblLp = LinearLayout.LayoutParams(dp(50), ViewGroup.LayoutParams.WRAP_CONTENT)
        lblLp.leftMargin = dp(12)
        row.addView(lbl, lblLp)
        val chips = FlowLayout(this)
        chips.hGap = dp(6)
        chips.vGap = dp(6)
        row.addView(chips, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        fun render() {
            chips.removeAllViews()
            val sel = getSelected()
            options.forEachIndexed { i, opt ->
                chips.addView(chip(opt, i == sel) { onPick(i) })
            }
        }
        render()
        return row
    }

    /** 重建整个型号选择区（机型+颜色+内存三层胶囊）。 */
    private fun renderModelBox() {
        modelBox.removeAllViews()
        // 机型行
        modelBox.addView(chipRow("机型", Catalog.SIZES, { selSize }) { pos ->
            selSize = pos
            selColor = 0
            renderModelBox()
            syncModelFromSpinners()
        }, lpW())
        // 颜色行
        val colors = Catalog.colorsFor(Catalog.SIZES[selSize])
        val colorRow = LinearLayout(this)
        colorRow.orientation = LinearLayout.HORIZONTAL
        colorRow.gravity = Gravity.CENTER_VERTICAL
        colorRow.background = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat(); setColor(CARD); setStroke(dp(1), LINE)
        }
        colorRow.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply { topMargin = dp(10) }
        val cl = TextView(this); cl.text = "颜色"; cl.setTextColor(SUB); cl.textSize = 14f
        colorRow.addView(cl, LinearLayout.LayoutParams(dp(50), ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(12) })
        val cChips = FlowLayout(this); cChips.hGap = dp(6); cChips.vGap = dp(6)
        colors.forEachIndexed { i, opt ->
            cChips.addView(chip(opt, i == selColor) {
                selColor = i
                renderModelBox()
                syncModelFromSpinners()
            })
        }
        colorRow.addView(cChips, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        modelBox.addView(colorRow)
        // 内存行
        val storageRow = chipRow("内存", Catalog.STORAGES, { selStorage }) { pos ->
            selStorage = pos
            renderModelBox()
            syncModelFromSpinners()
        }
        storageRow.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply { topMargin = dp(10) }
        modelBox.addView(storageRow)
    }

    /** 渲染颜色胶囊行（根据当前尺寸动态变化）。 */
    private fun renderColorChips() {
        colorChipsBox.removeAllViews()
        val colors = Catalog.colorsFor(Catalog.SIZES[selSize])
        if (selColor >= colors.size) selColor = 0
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(CARD)
            setStroke(dp(1), LINE)
        }
        row.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48))
        val lbl = TextView(this)
        lbl.text = "颜色"
        lbl.setTextColor(SUB)
        lbl.textSize = 14f
        val lblLp = LinearLayout.LayoutParams(dp(50), ViewGroup.LayoutParams.WRAP_CONTENT)
        lblLp.leftMargin = dp(12)
        row.addView(lbl, lblLp)
        val chips = FlowLayout(this)
        chips.hGap = dp(6)
        colors.forEachIndexed { i, opt ->
            chips.addView(chip(opt, i == selColor) {
                selColor = i
                renderColorChips()
                syncModelFromSpinners()
            })
        }
        row.addView(chips, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        colorChipsBox.addView(row)
    }

    private fun syncModelFromSpinners() {
        val part = Catalog.partFor(
            Catalog.SIZES[selSize], Catalog.STORAGES[selStorage], Catalog.colorsFor(Catalog.SIZES[selSize])[selColor])
        if (part == null) {
            // 型号映射缺失：不静默改成别的型号，直接提示并放弃本次同步
            toast("该型号组合暂不可用，请重新选择")
            return
        }
        selModel = Catalog.MODELS.indexOfFirst { it.part == part }.coerceAtLeast(0)
        val targets = Prefs.targets(this).toMutableList()
        if (targets.size <= 1) {
            if (targets.isEmpty()) targets.add(Prefs.Target(part, selStore))
            else targets[0] = targets[0].copy(part = part)
            Prefs.saveTargets(this, targets)
        } else {
            toast("已设为默认型号，添加目标时生效")
        }
        renderTargets()
        refreshHero()
    }

    /**
     * 把当前选中的 part 号反解回 机型/容量/颜色 的下标，
     * 同步到 selSize / selStorage / selColor。
     *
     * 原来有两个一模一样的函数（renderModelChips / renderAddModelChips），
     * 名字却叫 "render" 其实做的是状态同步，合并成一个并改成准确的名字。
     */
    private fun syncSelFromModel() {
        val (size, storage, color) = Catalog.parsePart(Catalog.MODELS[selModel].part)
        val si = Catalog.SIZES.indexOf(size)
        val st = Catalog.STORAGES.indexOf(storage)
        val colors = Catalog.colorsFor(size)
        val ci = colors.indexOf(color)
        if (si >= 0) selSize = si
        if (st >= 0) selStorage = st
        if (ci >= 0) selColor = ci
    }

    /**
     * 间隔选择：显示当前网络类型与生效间隔，点击即修改**当前网络类型**对应的间隔。
     * WiFi 档默认 10 秒（最高频），移动数据档默认 30 秒（省流量）。
     */
    private fun renderIvlChips() {
        ivlChipsBox.removeAllViews()
        val metered = NetProbe.isMetered(this)
        val cur = if (metered) Prefs.cellInterval(this) else Prefs.wifiInterval(this)
        selIvl = Catalog.INTERVALS.indexOfFirst { it.sec == cur }.let { if (it >= 0) it else 0 }
        ivlNetText.text = "当前网络：${NetProbe.label(this)} · 生效间隔 ${Catalog.INTERVALS[selIvl].label}"
        Catalog.INTERVALS.forEachIndexed { i, iv ->
            ivlChipsBox.addView(chip(iv.label, i == selIvl, padRight = i < Catalog.INTERVALS.size - 1) {
                selIvl = i
                if (metered) Prefs.saveCellInterval(this, iv.sec)
                else Prefs.saveWifiInterval(this, iv.sec)
                Prefs.saveInterval(this, iv.sec)
                renderIvlChips()
                toast("${NetProbe.label(this)} 下间隔已设为 ${iv.label}")
            })
        }
    }

    private fun renderStoreTree() {
        storeTreeBox.removeAllViews()
        val q = (searchInput.text?.toString() ?: "").trim()

        // 门店来源：动态目录优先（接口数据，7 天缓存），没有才用内置表
        val dynamic = StoreDirectory.cachedStores(this)
        val byCity: List<Pair<String, List<Catalog.StoreOpt>>> =
            if (dynamic.isNotEmpty()) {
                dynamic.map { (city, list) ->
                    city to list.map { Catalog.StoreOpt(it.code, it.name, it.city) }
                }
            } else {
                Catalog.CITY_STORES
            }

        if (q.isNotEmpty()) {
            byCity.forEach { (city, stores) ->
                val hit = stores.filter { city.contains(q) || it.name.contains(q) || it.code.contains(q.uppercase(Locale.CHINA)) }
                if (hit.isNotEmpty()) storeTreeBox.addView(cityGroup(city, hit, true))
            }
        } else {
            val featured = listOf("广州", "上海", "北京")
            byCity.filter { it.first in featured }.forEach { (city, stores) ->
                storeTreeBox.addView(cityGroup(city, stores, city in openCities))
            }
            val rest = byCity.filter { it.first !in featured }
            val restCount = rest.sumOf { it.second.size }
            storeTreeBox.addView(cityGroup("其他城市（${rest.size} 城）", rest.flatMap { it.second }, openRest,
                rest = true, count = restCount))
        }
    }

    private fun cityGroup(city: String, stores: List<Catalog.StoreOpt>, open: Boolean, rest: Boolean = false, count: Int = stores.size): LinearLayout {
        val wrap = LinearLayout(this)
        wrap.orientation = LinearLayout.VERTICAL
        val gBg = GradientDrawable()
        gBg.cornerRadius = dp(14).toFloat()
        gBg.setColor(if (rest) Color.TRANSPARENT else CARD)
        if (!rest) gBg.setStroke(dp(1), LINE)
        wrap.background = gBg
        val mlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        mlp.bottomMargin = dp(8)
        wrap.layoutParams = mlp

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(16), dp(14), dp(16), dp(14))
        head.setOnClickListener {
            if (rest) openRest = !openRest else if (open) openCities.remove(city) else openCities.add(city)
            renderStoreTree()
        }
        val name = TextView(this)
        name.text = city
        name.setTextColor(TXT)
        name.textSize = 15f
        name.setTypeface(null, Typeface.BOLD)
        head.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val cnt = TextView(this)
        cnt.text = "$count 家"
        cnt.setTextColor(FAINT)
        cnt.textSize = 12f
        head.addView(cnt)
        val arrow = TextView(this)
        arrow.text = if (open) "▾" else "▸"
        arrow.setTextColor(SUB)
        arrow.textSize = 13f
        arrow.setPadding(dp(8), 0, 0, 0)
        head.addView(arrow)
        wrap.addView(head)

        if (open) {
            val sub = LinearLayout(this)
            sub.orientation = LinearLayout.VERTICAL
            stores.forEach { s ->
                sub.addView(storeLine(s, selStore == s.code))
            }
            wrap.addView(sub)
        }
        return wrap
    }

    private fun storeLine(s: Catalog.StoreOpt, selected: Boolean): LinearLayout {
        val line = LinearLayout(this)
        line.orientation = LinearLayout.HORIZONTAL
        line.gravity = Gravity.CENTER_VERTICAL
        line.setPadding(dp(16), dp(13), dp(16), dp(13))
        line.isClickable = true
        val unavailable = Catalog.isStoreUnavailable(s.code)
        line.setOnClickListener {
            if (unavailable) {
                toast(Catalog.STORE_UNAVAILABLE_TIP)
                return@setOnClickListener
            }
            selectStore(s.code)
        }

        val dot = View(this)
        val dlp = LinearLayout.LayoutParams(dp(16), dp(16))
        dlp.rightMargin = dp(10)
        val dBg = GradientDrawable()
        dBg.shape = GradientDrawable.OVAL
        if (selected) {
            dBg.setColor(BLUE)
        } else {
            dBg.setColor(Color.TRANSPARENT)
            dBg.setStroke(dp(1.5f), FAINT)
        }
        dot.background = dBg
        line.addView(dot, dlp)

        val name = TextView(this)
        name.text = s.name
        name.setTextColor(if (unavailable) FAINT else if (selected) CHIP_ON_TXT else TXT)
        name.textSize = 14.5f
        if (selected) name.setTypeface(null, Typeface.BOLD)
        line.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (unavailable) {
            val tag = TextView(this)
            tag.text = "维护中"
            tag.setTextColor(AMBER)
            tag.textSize = 11f
            tag.setPadding(dp(8), 0, dp(10), 0)
            line.addView(tag)
        }
        val code = TextView(this)
        code.text = s.code
        code.setTextColor(FAINT)
        code.textSize = 11.5f
        code.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL)
        line.addView(code)
        return line
    }

    private fun selectStore(code: String) {
        selStore = code
        val targets = Prefs.targets(this).toMutableList()
        if (targets.size <= 1) {
            if (targets.isEmpty()) targets.add(Prefs.Target(Catalog.MODELS[selModel].part, code))
            else targets[0] = targets[0].copy(store = code)
            Prefs.saveTargets(this, targets)
        } else {
            toast("已设为默认门店，添加目标时生效")
        }
        renderStoreTree()
        renderTargets()
        refreshHero()
    }

    private fun renderTargets() {
        targetListBox.removeAllViews()
        val targets = Prefs.targets(this)
        if (targets.isEmpty()) {
            val empty = hintText("还没有监控目标，点上方「＋ 添加目标」")
            targetListBox.addView(empty)
            return
        }
        targets.forEachIndexed { i, t ->
            targetListBox.addView(targetItem(t, i))
        }
        refreshHero()
    }

    private fun targetItem(t: Prefs.Target, idx: Int): LinearLayout {
        val item = LinearLayout(this)
        item.orientation = LinearLayout.VERTICAL
        val iBg = GradientDrawable()
        iBg.cornerRadius = dp(16).toFloat()
        iBg.setColor(CARD)
        iBg.setStroke(dp(1), LINE)
        item.background = iBg
        val mlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        mlp.bottomMargin = dp(10)
        item.layoutParams = mlp
        item.setPadding(dp(16), dp(14), dp(16), dp(14))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val name = TextView(this)
        name.text = Catalog.modelLabel(t.part)
        name.setTextColor(TXT)
        name.textSize = 15f
        name.setTypeface(null, Typeface.BOLD)
        row.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val res = Prefs.lastResult(this, t.key())
        val yes = res == "available"
        val badge = TextView(this)
        badge.text = when (res) {
            "available" -> "有货"
            "unavailable" -> "无货"
            "fail" -> "失败"
            else -> "待查"
        }
        badge.textSize = 12f
        badge.setTypeface(null, Typeface.BOLD)
        badge.setPadding(dp(10), dp(4), dp(10), dp(4))
        val bBg = GradientDrawable()
        bBg.cornerRadius = dp(20).toFloat()
        bBg.setColor(if (yes) Color.parseColor("#1A3A35") else Color.parseColor("#232B3A"))
        badge.setTextColor(if (yes) GREEN else SUB)
        badge.background = bBg
        row.addView(badge)
        val del = TextView(this)
        del.text = "×"
        del.setTextColor(FAINT)
        del.textSize = 20f
        del.setPadding(dp(12), 0, dp(2), 0)
        del.setOnClickListener { delTarget(idx) }
        row.addView(del)
        item.addView(row)

        val foot = LinearLayout(this)
        foot.orientation = LinearLayout.HORIZONTAL
        val flp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        flp.topMargin = dp(8)
        val storeTxt = TextView(this)
        storeTxt.text = "${Catalog.cityOf(t.store)} · ${Catalog.storeLabel(t.store)}"
        storeTxt.setTextColor(SUB)
        storeTxt.textSize = 12.5f
        foot.addView(storeTxt, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val timeTxt = TextView(this)
        // 每个目标显示各自的检查时间（不再所有目标共用一个全局值）
        timeTxt.text = Prefs.lastCheckTimeOf(this, t.key()).ifEmpty { "尚未检查" }.substringAfter(" ")
        timeTxt.setTextColor(FAINT)
        timeTxt.textSize = 12f
        foot.addView(timeTxt)
        item.addView(foot, flp)
        return item
    }

    private fun delTarget(idx: Int) {
        val list = Prefs.targets(this).toMutableList()
        if (idx in list.indices) {
            list.removeAt(idx)
            Prefs.saveTargets(this, list)
            renderTargets()
            toast("已删除目标")
        }
    }

    private fun renderLog() {
        logBox.removeAllViews()
        val items = Prefs.log(this)
        if (items.isEmpty()) {
            logBox.addView(hintText("还没有检查记录"))
            return
        }
        items.reversed().forEach { it ->
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.TOP
            row.setPadding(dp(4), dp(8), dp(4), dp(8))
            val dot = View(this)
            val dlp = LinearLayout.LayoutParams(dp(8), dp(8))
            dlp.topMargin = dp(5)
            dlp.rightMargin = dp(12)
            val dBg = GradientDrawable()
            dBg.shape = GradientDrawable.OVAL
            dBg.setColor(if (it.ok) GREEN else FAINT)
            dot.background = dBg
            row.addView(dot, dlp)
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            val lt = TextView(this)
            lt.text = it.t
            lt.setTextColor(FAINT)
            lt.textSize = 12f
            col.addView(lt)
            val lm = TextView(this)
            lm.text = it.m
            lm.setTextColor(if (it.ok) TXT else SUB)
            lm.textSize = 14f
            col.addView(lm)
            row.addView(col)
            logBox.addView(row)
        }
    }

    /** 弹层选择变化时只更新 selModel，不影响已有监控目标。 */
    private fun updateAddSelModel() {
        val colors = Catalog.colorsFor(Catalog.SIZES[selSize])
        val part = Catalog.partFor(
            Catalog.SIZES[selSize], Catalog.STORAGES[selStorage], colors[selColor.coerceAtMost(colors.size - 1)])
        // 映射缺失时保留上一次的 selModel，不静默切到别的型号
        if (part != null) selModel = Catalog.MODELS.indexOfFirst { it.part == part }.coerceAtLeast(0)
    }

    // ================= 动作 =================
    private fun toggleMonitor() {
        val intent = Intent(this, MonitorService::class.java)
        if (running) {
            intent.action = MonitorService.ACTION_STOP
            startService(intent)
            running = false
            toast("已停止监控")
        } else {
            val targets = Prefs.targets(this)
            if (targets.isEmpty()) {
                toast("请先添加监控目标")
                return
            }
            saveSendkeyFromInput()
            if (NetProbe.isMetered(this)) Prefs.saveCellInterval(this, Catalog.INTERVALS[selIvl].sec)
            else Prefs.saveWifiInterval(this, Catalog.INTERVALS[selIvl].sec)
            intent.action = MonitorService.ACTION_START
            startForegroundService(intent)
            running = true
            toast("监控已启动")
        }
        refreshHero()
        updateToggleButton()
    }

    /** 手动查询一次：同样按 location 合并，并受请求预算约束（否则一次点按也会撞风控）。 */
    private fun checkOnce() {
        val targets = Prefs.targets(this)
        if (targets.isEmpty()) { toast("请先添加监控目标"); return }
        val groups = groupByLocation(this, targets)
        val wait = RequestBudget.reserve(this, groups.size)
        if (wait > 0) {
            toast("请求太频繁，${wait / 1000} 秒后再试")
            return
        }
        heroState.text = "正在查询…"
        dotDot(heroDot, AMBER)
        btnCheck.isEnabled = false
        var done = 0
        var firstFail: WebStockQuerier.Outcome? = null
        var anyAvail = false
        groups.forEach { g ->
            WebStockQuerier.queryBatch(this, g.location, g.parts) { res ->
                if (res.limited) RequestBudget.tripCircuit(this)
                g.targets.forEach { t ->
                    val o = when {
                        res.limited -> WebStockQuerier.Outcome(null, "被官网限流，已暂停请求")
                        !res.ok -> WebStockQuerier.Outcome(null, res.error)
                        else -> WebStockQuerier.resolveOne(res, t.part, t.store)
                    }
                    Prefs.setLastCheckTimeOf(this, t.key(), nowStr())
                    when (o.available) {
                        // 手动查询不修改 streak：连续无货次数是后台监控的统计，
                        // 手动查一次有货就清零会让这个数字失去意义
                        true -> { Prefs.setLastResult(this, t.key(), "available"); anyAvail = true }
                        false -> Prefs.setLastResult(this, t.key(), "unavailable")
                        else -> { Prefs.setLastResult(this, t.key(), "fail"); if (firstFail == null) firstFail = o }
                    }
                }
                done++
                if (done >= groups.size) {
                    renderTargets()
                    refreshHero()
                    btnCheck.isEnabled = true
                    val ff = firstFail
                    when {
                        anyAvail -> toast("✅ 有货！")
                        ff != null -> showErrorHelp(ff.detail.ifBlank { "查询失败" })
                        else -> toast("当前无货")
                    }
                }
            }
        }
    }

    /** 查询失败时展示错误原因 + 解决建议，可直接导出日志。 */
    private fun showErrorHelp(error: String) {
        val msg = error + "\n\n" + AppLogger.diagnosis(error)
        val b = android.app.AlertDialog.Builder(this)
            .setTitle("查询失败")
            .setMessage(msg)
            .setPositiveButton("知道了", null)
        if (AppLogger.hasLogs(this)) {
            b.setNeutralButton("导出日志") { _, _ ->
                val ok = AppLogger.export(this)
                if (!ok) toast("导出失败，请稍后重试")
            }
        }
        b.show()
    }

    private fun testPush() {
        val key = inputKey.text.toString().trim()
        if (key.isBlank()) { toast("请先填写 SendKey 再测试"); return }
        Thread {
            try {
                StockChecker.pushWechat(key, "库存提醒助手 · 测试推送", "如果你收到这条消息，说明微信推送配置成功！\n\n时间：${nowStr()}")
                runOnUiThread { toast("测试推送已发送，查收微信") }
            } catch (e: Exception) {
                AppLogger.e(this, "微信推送", "测试推送", e.message ?: "推送失败", e)
                runOnUiThread { toast("推送失败：${e.message}") }
            }
        }.start()
    }

    private fun saveSendkeyFromInput() {
        Prefs.saveSendkey(this, inputKey.text.toString().trim())
    }

    private fun openAdd() {
        // 重置多选门店：默认选中当前默认门店
        addSelectedStores.clear()
        addSelectedStores.add(selStore)
        syncSelFromModel()
        maskAdd.visibility = View.VISIBLE
    }

    private fun closeAdd() {
        maskAdd.visibility = View.GONE
    }

    private fun confirmAdd() {
        val part = Catalog.MODELS[selModel].part
        if (addSelectedStores.isEmpty()) {
            toast("请至少选择一个门店")
            return
        }
        val list = Prefs.targets(this).toMutableList()
        var added = 0
        var skipped = 0
        var over = 0
        addSelectedStores.forEach { storeCode ->
            val t = Prefs.Target(part, storeCode)
            if (list.any { it.key() == t.key() }) {
                skipped++
            } else if (list.size >= Prefs.MAX_TARGETS) {
                over++
            } else {
                list.add(t)
                added++
            }
        }
        Prefs.saveTargets(this, list)
        // 清空选中集合，下次打开重置
        addSelectedStores.clear()
        closeAdd()
        renderTargets()
        when {
            added > 0 && over > 0 -> toast("已添加 $added 条，$over 条超出上限（最多 ${Prefs.MAX_TARGETS} 条）")
            added > 0 && skipped > 0 -> toast("已添加 $added 条，$skipped 条已存在")
            added > 0 -> toast("已添加 $added 条监控记录")
            over > 0 -> toast("最多 ${Prefs.MAX_TARGETS} 条监控记录，请先删除已有记录")
            else -> toast("所选门店都已在监控列表")
        }
    }

    /**
     * 设置页的网络策略：WiFi 间隔与移动数据间隔分开设置。
     * 两档互不影响，切换网络时自动取对应的一档。
     */
    private fun renderNetPolicy() {
        netPolicyBox.removeAllViews()
        val wifiIdx = Catalog.INTERVALS.indexOfFirst { it.sec == Prefs.wifiInterval(this) }.let { if (it >= 0) it else 0 }
        val cellIdx = Catalog.INTERVALS.indexOfFirst { it.sec == Prefs.cellInterval(this) }.let { if (it >= 0) it else 2 }
        netPolicyBox.addView(ivlSettingRow("WiFi 间隔（当前 ${Catalog.INTERVALS[wifiIdx].label}）", wifiIdx) { i ->
            Prefs.saveWifiInterval(this, Catalog.INTERVALS[i].sec)
            renderNetPolicy()
            renderIvlChips()
        })
        val gapLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        gapLp.topMargin = dp(18)
        netPolicyBox.addView(ivlSettingRow("移动数据间隔（当前 ${Catalog.INTERVALS[cellIdx].label}）", cellIdx) { i ->
            Prefs.saveCellInterval(this, Catalog.INTERVALS[i].sec)
            renderNetPolicy()
            renderIvlChips()
        }, gapLp)
    }

    /** 一行间隔选择：标题 + 胶囊组。 */
    private fun ivlSettingRow(title: String, cur: Int, onPick: (Int) -> Unit): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val t = TextView(this)
        t.text = title
        t.setTextColor(TXT)
        t.textSize = 14f
        t.setTypeface(null, Typeface.BOLD)
        col.addView(t)
        val chips = FlowLayout(this)
        chips.hGap = dp(8)
        chips.vGap = dp(8)
        chips.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) }
        Catalog.INTERVALS.forEachIndexed { i, iv ->
            chips.addView(chip(iv.label, i == cur, padRight = i < Catalog.INTERVALS.size - 1) { onPick(i) })
        }
        col.addView(chips)
        return col
    }

    /**
     * 更新提示条：显示已发现但还没安装的新版本，常驻直到用户更新。
     * 点整条可再次拉起更新弹窗。
     */
    private fun renderUpdateBanner() {
        val info = UpdateChecker.pendingUpdate(this)
        if (info == null) {
            updateBanner.visibility = View.GONE
            return
        }
        updateBannerText.text = "发现新版本 v${info.versionName}，建议尽快更新"
        updateBanner.visibility = View.VISIBLE
    }

    private fun refreshHero() {
        val targets = Prefs.targets(this)
        val first = targets.firstOrNull()

        // 统计全部目标状态（确保监控列表里的每个目标都被追踪）
        var availCount = 0
        var unavailCount = 0
        var failCount = 0
        var pendingCount = 0
        targets.forEach { t ->
            when (Prefs.lastResult(this, t.key())) {
                "available" -> availCount++
                "unavailable" -> unavailCount++
                "fail" -> failCount++
                else -> pendingCount++
            }
        }

        if (targets.size <= 1) {
            heroTarget.text = if (first == null) "目标：--"
            else "目标：${Catalog.modelLabel(first.part)} · ${Catalog.storeLabel(first.store)}"
        } else {
            heroTarget.text = "共 ${targets.size} 个目标 · $availCount 有货 / $unavailCount 无货" +
                if (failCount > 0) " / $failCount 失败" else ""
        }

        val overall = when {
            availCount > 0 -> "available"
            failCount > 0 && unavailCount == 0 && pendingCount == 0 -> "fail"
            pendingCount > 0 && unavailCount == 0 -> "pending"
            else -> "unavailable"
        }

        if (running) {
            heroState.text = "监控运行中 · 已跑 ${Prefs.roundCount} 轮 · 每 ${Catalog.INTERVALS[selIvl].label}（${NetProbe.label(this)}）"
            dotDot(heroDot, GREEN)
        } else {
            heroState.text = "监控未启动"
            dotDot(heroDot, FAINT)
        }
        when (overall) {
            "available" -> {
                heroBig.text = if (targets.size > 1) "$availCount 个有货！" else "有货可自提"
                heroBig.setTextColor(GREEN)
            }
            "fail" -> { heroBig.text = "查询失败"; heroBig.setTextColor(AMBER) }
            "pending" -> { heroBig.text = "等待首查"; heroBig.setTextColor(FAINT) }
            else -> {
                heroBig.text = if (targets.size > 1) "全部无货" else "当前无货"
                heroBig.setTextColor(FAINT)
            }
        }
        mLast.text = Prefs.lastCheckTime.ifEmpty { "--:--" }.substringAfter(" ")
        mNext.text = Prefs.nextCheckTime.ifEmpty { "--:--" }
        mStreak.text = "${Prefs.streak} 次"
    }

    private fun refreshAll() {
        running = Prefs.running
        selStore = Prefs.targets(this).firstOrNull()?.store ?: "R639"
        syncSelFromModel()
        renderIvlChips()
        renderStoreTree()
        renderTargets()
        renderLog()
        refreshHero()
        updateToggleButton()
    }

    private fun updateToggleButton() {
        if (running) {
            btnToggle.text = "停止监控"
            (btnToggle.background as? GradientDrawable)?.setColor(RED)
        } else {
            btnToggle.text = "启动监控"
            (btnToggle.background as? GradientDrawable)?.setColor(BLUE)
        }
    }

    private fun switchTab(idx: Int) {
        vMonitor.visibility = if (idx == 0) View.VISIBLE else View.GONE
        vLog.visibility = if (idx == 1) View.VISIBLE else View.GONE
        vSetting.visibility = if (idx == 2) View.VISIBLE else View.GONE
        tabPaint(tabMonitor, idx == 0)
        tabPaint(tabLog, idx == 1)
        tabPaint(tabSetting, idx == 2)
        if (idx == 1) renderLog()
        if (idx == 2) inputKey.setText(Prefs.sendkey(this))
    }

    // ================= UI 构建辅助 =================
    private fun makeScrolled(): ScrollView {
        val sv = ScrollView(this)
        sv.setBackgroundColor(BG)
        sv.isFillViewport = false
        return sv
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.cornerRadius = dp(22).toFloat()
        bg.setColor(CARD2)
        bg.setStroke(dp(1), LINE)
        c.background = bg
        return c
    }

    private fun chip(text: String, selected: Boolean, padRight: Boolean = true, onClick: () -> Unit): TextView {
        val c = TextView(this)
        c.text = text
        c.textSize = 13f
        c.gravity = Gravity.CENTER
        c.setSingleLine(true)
        c.setPadding(dp(12), dp(7), dp(12), dp(7))
        c.minHeight = dp(34)
        c.setMinHeight(dp(34))
        val bg = GradientDrawable()
        bg.cornerRadius = dp(17).toFloat()
        bg.setColor(if (selected) CHIP_ON_BG else CARD)
        bg.setStroke(dp(1), if (selected) BLUE else LINE)
        c.background = bg
        c.setTextColor(if (selected) CHIP_ON_TXT else SUB)
        c.setOnClickListener { onClick() }
        c.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        return c
    }

    private fun btn(text: String, color: Int, onClick: () -> Unit): TextView {
        val b = TextView(this)
        b.text = text
        b.gravity = Gravity.CENTER
        b.setTextColor(Color.WHITE)
        b.textSize = 16f
        b.setTypeface(null, Typeface.BOLD)
        b.isClickable = true
        val bg = GradientDrawable()
        bg.cornerRadius = dp(16).toFloat()
        bg.setColor(color)
        b.background = bg
        b.setOnClickListener { onClick() }
        return b
    }

    /** 统一样式的深色下拉选择器，返回(外包装布局, Spinner)。 */
    private fun darkSpinner(labels: List<String>, initialPos: Int, onSelect: (Int) -> Unit): Pair<LinearLayout, Spinner> {
        val wrap = LinearLayout(this)
        wrap.orientation = LinearLayout.HORIZONTAL
        wrap.gravity = Gravity.CENTER_VERTICAL
        val bg = GradientDrawable()
        bg.cornerRadius = dp(14).toFloat()
        bg.setColor(CARD)
        bg.setStroke(dp(1), LINE)
        wrap.background = bg
        wrap.setPadding(dp(14), 0, dp(14), 0)
        val sp = Spinner(this)
        sp.background = null
        val adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, labels) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent) as TextView
                v.setTextColor(TXT); v.textSize = 14.5f
                v.setPadding(0, dp(13), 0, dp(13)); v.setBackgroundColor(Color.TRANSPARENT)
                return v
            }
            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getDropDownView(position, convertView, parent) as TextView
                v.setTextColor(TXT); v.textSize = 14.5f
                v.setPadding(dp(16), dp(14), dp(16), dp(14)); v.setBackgroundColor(CARD)
                return v
            }
        }
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sp.adapter = adapter
        sp.setPopupBackgroundDrawable(ColorDrawable(CARD))
        sp.setSelection(initialPos)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                onSelect(position)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        wrap.addView(sp, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val arrow = TextView(this)
        arrow.text = "▾"; arrow.setTextColor(SUB); arrow.textSize = 14f
        wrap.addView(arrow)
        return wrap to sp
    }

    private fun iconBtn(text: String): TextView {
        val b = TextView(this)
        b.text = text
        b.gravity = Gravity.CENTER
        b.setTextColor(SUB)
        b.textSize = 18f
        b.isClickable = true
        val lp = LinearLayout.LayoutParams(dp(38), dp(38))
        lp.leftMargin = dp(12)
        b.layoutParams = lp
        val bg = GradientDrawable()
        bg.cornerRadius = dp(12).toFloat()
        bg.setColor(CARD)
        bg.setStroke(dp(1), LINE)
        b.background = bg
        return b
    }

    private fun setRow(
        title: String,
        desc: String,
        initial: Boolean?,
        onChange: ((Boolean) -> Unit)? = null,
        descRef: ((TextView) -> Unit)? = null
    ): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val bg = GradientDrawable()
        bg.cornerRadius = dp(16).toFloat()
        bg.setColor(CARD)
        bg.setStroke(dp(1), LINE)
        row.background = bg
        row.setPadding(dp(16), dp(15), dp(16), dp(15))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val n = TextView(this)
        n.text = title
        n.setTextColor(TXT)
        n.textSize = 15f
        n.setTypeface(null, Typeface.BOLD)
        col.addView(n)
        val d = TextView(this)
        d.text = desc
        d.setTextColor(SUB)
        d.textSize = 12.5f
        col.addView(d)
        descRef?.invoke(d)
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (initial != null && onChange != null) {
            row.addView(toggle(initial, onChange))
        }
        val mlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        mlp.bottomMargin = dp(10)
        row.layoutParams = mlp
        return row
    }

    private fun toggle(initial: Boolean, onChange: (Boolean) -> Unit): View {
        var cur = initial
        val t = LinearLayout(this)
        t.orientation = LinearLayout.HORIZONTAL
        t.isClickable = true
        val lp = LinearLayout.LayoutParams(dp(48), dp(29))
        lp.leftMargin = dp(12)
        t.layoutParams = lp
        val knob = View(this)
        val kb = GradientDrawable()
        kb.shape = GradientDrawable.OVAL
        kb.setColor(Color.WHITE)
        knob.background = kb
        t.addView(knob, LinearLayout.LayoutParams(dp(23), dp(23)))
        fun paint() {
            val bg = GradientDrawable()
            bg.cornerRadius = dp(15).toFloat()
            bg.setColor(if (cur) GREEN else LINE)
            t.background = bg
            val klp = knob.layoutParams as LinearLayout.LayoutParams
            klp.topMargin = dp(3)
            klp.leftMargin = if (cur) dp(22) else dp(3)
            knob.layoutParams = klp
        }
        t.setOnClickListener { cur = !cur; onChange(cur); paint() }
        paint()
        return t
    }

    private fun hintText(text: String): TextView {
        val h = TextView(this)
        h.text = text
        h.setTextColor(FAINT)
        h.textSize = 12f
        h.setLineSpacing(0f, 1.3f)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(14)
        h.layoutParams = lp
        return h
    }

    private fun dotDot(v: View, color: Int) {
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(color)
        v.background = bg
    }

    private fun tab(text: String): LinearLayout {
        val t = LinearLayout(this)
        t.orientation = LinearLayout.VERTICAL
        t.gravity = Gravity.CENTER
        val lb = TextView(this)
        lb.text = text
        lb.textSize = 13f
        lb.gravity = Gravity.CENTER
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        t.addView(lb, lp)
        return t
    }

    private fun tabPaint(t: LinearLayout, on: Boolean) {
        val lb = t.getChildAt(0) as TextView
        lb.setTextColor(if (on) BLUE else FAINT)
        if (on) lb.setTypeface(null, Typeface.BOLD) else lb.setTypeface(null, Typeface.NORMAL)
    }

    private fun lpMM(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)

    private fun lpW(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    override fun onResume() {
        super.onResume()
        // 隐私政策未同意时主界面未构建，跳过刷新避免崩溃
        if (!Prefs.privacyAgreed(this)) return
        refreshAll()
    }

    private fun requestNotifPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
        }
    }

    /** 首次启动隐私政策弹窗：不可取消，拒绝则退出。 */
    private fun showPrivacyConsent() {
        val short = "欢迎使用库存提醒助手。\n\n" +
            "本应用由个人开发者 TxooxT 独立开发，仅查询苹果官方门店库存，" +
            "不收集您的位置、通讯录、相册等个人信息，所有配置仅保存在本机。\n\n" +
            "请阅读完整隐私政策后点击「同意」开始使用。"
        val b = android.app.AlertDialog.Builder(this)
            .setTitle("隐私政策与用户协议")
            .setMessage(short)
            .setCancelable(false)
            .setPositiveButton("同意并继续") { _, _ ->
                Prefs.setPrivacyAgreed(this)
                // 重新走 onCreate 流程
                recreate()
            }
            .setNegativeButton("拒绝并退出") { _, _ -> finish() }
            .setNeutralButton("查看完整隐私政策") { _, _ ->
                showPrivacyPolicy(onAgreed = {
                    Prefs.setPrivacyAgreed(this)
                    recreate()
                })
            }
        val d = b.create()
        d.show()
    }

    /** 展示完整隐私政策；若用户从这里同意，回调 onAgreed。 */
    private fun showPrivacyPolicy(onAgreed: (() -> Unit)? = null) {
        val sv = ScrollView(this)
        val tv = TextView(this)
        tv.setTextIsSelectable(true)
        tv.text = PrivacyPolicy.TEXT
        tv.setTextColor(TXT)
        tv.textSize = 13f
        tv.setLineSpacing(0f, 1.4f)
        tv.setPadding(dp(20), dp(16), dp(20), dp(16))
        sv.addView(tv)
        val b = android.app.AlertDialog.Builder(this)
            .setTitle(PrivacyPolicy.TITLE)
            .setView(sv)
            .setCancelable(true)
        if (onAgreed != null) {
            b.setPositiveButton("同意") { _, _ -> onAgreed() }
        } else {
            b.setPositiveButton("关闭", null)
        }
        b.show()
    }

    private fun dp(n: Number): Int = (n.toFloat() * resources.displayMetrics.density).toInt()

    private fun nowStr(): String =
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).format(Date())
}

/** 纯系统实现的自动换行容器：子项按宽度依次排列，放不下自动换行，行列间距统一。 */
private class FlowLayout(context: android.content.Context) : ViewGroup(context) {
    var hGap: Int = 0
    var vGap: Int = 0
    private val lines = ArrayList<ArrayList<Int>>()

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val maxW = MeasureSpec.getSize(widthMeasureSpec) - paddingLeft - paddingRight
        lines.clear()
        var line = ArrayList<Int>()
        var curX = 0
        var lineH = 0
        var totalH = paddingTop
        for (i in 0 until childCount) {
            val child = getChildAt(i)
            if (child.visibility == View.GONE) continue
            measureChild(child, widthMeasureSpec, heightMeasureSpec)
            val w = child.measuredWidth
            val h = child.measuredHeight
            if (line.isNotEmpty() && curX + w > maxW) {
                lines.add(line)
                totalH += lineH + vGap
                line = ArrayList()
                curX = 0
                lineH = 0
            }
            line.add(i)
            curX += w + hGap
            lineH = maxOf(lineH, h)
        }
        if (line.isNotEmpty()) {
            lines.add(line)
            totalH += lineH
        }
        totalH += paddingBottom
        setMeasuredDimension(
            maxW + paddingLeft + paddingRight,
            resolveSize(totalH, heightMeasureSpec)
        )
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        var y = paddingTop
        for (line in lines) {
            var x = paddingLeft
            var lineH = 0
            for (idx in line) {
                val child = getChildAt(idx)
                val w = child.measuredWidth
                val h = child.measuredHeight
                child.layout(x, y, x + w, y + h)
                x += w + hGap
                lineH = maxOf(lineH, h)
            }
            y += lineH + vGap
        }
    }
}
