package com.apple.stockmonitor

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * 动态门店目录：从苹果接口拉取各片区的门店清单，本地缓存 7 天。
 *
 * **为什么要动态化**
 * - 门店会开也会关，官网接口是唯一准确来源；写死的表一旦漂移就永远错，且没有任何机制能发现；
 * - 新开的门店不用改代码就能被监控到；
 * - 查不到的门店（比如返回 0 家的南宁万象城）自然消失，不必再手工维护"维护中"名单。
 *
 * **为什么区域映射仍然写死**
 * 实测接口的 location 是**区域级**语义：「江苏 苏州」和「上海 上海」返回的是同一批 12 家店；
 * 且去掉 location 参数返回 0 家，没有"一次拿全国"的写法。
 * 所以「哪个城市该用哪个 location」这张表只能留在代码里。
 *
 * **缓存策略**
 * - 按 location 缓存整个片区的门店清单，TTL 7 天；
 * - 用户点开某个城市时，若缓存已过期才发请求，否则直接用本地数据，零流量。
 */
object StoreDirectory {

    /** 一家门店的档案。city / state 来自接口，不用自己维护。 */
    data class Entry(
        val code: String,
        val name: String,
        val city: String,
        val state: String,
        /**
         * 拉取这个门店时用的 location（缓存里按片区分组存的原始来源）。
         * 仅用于溯源与去重，**不直接用作查询 location**——
         * 宽门店集下一次请求会带回邻近城市的店，记请求串会让查询片区张冠李戴。
         * 查询用哪个片区见 [locationsOf] / [Catalog.locationForStore]。
         */
        val location: String = ""
    )

    /** 内存快照：门店编号 -> 档案。App 内任何地方都能免 IO 查门店名与城市。 */
    @Volatile
    private var snapshot: Map<String, Entry> = emptyMap()

    /** 缓存 TTL：7 天。 */
    private const val TTL_MS = 7L * 24 * 60 * 60 * 1000

    private const val SP = "stock_store_dir"
    private const val K_ENTRIES = "entries_json"
    private const val K_FETCHED = "fetched_at_json"

    // ================= 缓存读写 =================

    private fun sp(ctx: Context) = ctx.getSharedPreferences(SP, Context.MODE_PRIVATE)

    private fun readEntries(ctx: Context): MutableMap<String, MutableList<Entry>> {
        val out = LinkedHashMap<String, MutableList<Entry>>()
        val raw = sp(ctx).getString(K_ENTRIES, "") ?: ""
        try {
            val o = JSONObject(raw)
            val keys = o.keys()
            while (keys.hasNext()) {
                val loc = keys.next()
                val arr = o.optJSONArray(loc) ?: continue
                val list = ArrayList<Entry>(arr.length())
                for (i in 0 until arr.length()) {
                    val e = arr.getJSONObject(i)
                    val code = e.optString("code")
                    if (code.isBlank()) continue
                    list.add(
                        Entry(
                            code = code,
                            name = e.optString("name"),
                            city = e.optString("city"),
                            state = e.optString("state"),
                            location = e.optString("location")
                        )
                    )
                }
                out[loc] = list
            }
        } catch (e: Exception) { /* 缓存损坏就当空的 */ }
        return out
    }

    private fun writeEntries(ctx: Context, map: Map<String, List<Entry>>) {
        val o = JSONObject()
        map.forEach { (loc, list) ->
            val arr = JSONArray()
            list.forEach { e ->
                arr.put(
                    JSONObject()
                        .put("code", e.code)
                        .put("name", e.name)
                        .put("city", e.city)
                        .put("state", e.state)
                        .put("location", e.location)
                )
            }
            o.put(loc, arr)
        }
        sp(ctx).edit().putString(K_ENTRIES, o.toString()).apply()
    }

    private fun readFetched(ctx: Context): MutableMap<String, Long> {
        val out = LinkedHashMap<String, Long>()
        val raw = sp(ctx).getString(K_FETCHED, "") ?: ""
        try {
            val o = JSONObject(raw)
            val keys = o.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                out[k] = o.optLong(k, 0L)
            }
        } catch (e: Exception) { }
        return out
    }

    private fun writeFetched(ctx: Context, map: Map<String, Long>) {
        val o = JSONObject()
        map.forEach { (loc, ts) -> o.put(loc, ts) }
        sp(ctx).edit().putString(K_FETCHED, o.toString()).apply()
    }

    // ================= 对外接口 =================

    /**
     * 启动时把缓存灌进内存快照，之后各处都能直接查。
     *
     * 宽门店集下同一家店会被多个片区同时返回（广东 广州 那一片就含南宁/厦门/长沙等店），
     * 所以这里用「先到先得」而不是 `associateBy`（后者取最后一个）：
     * 门店 → 片区 的映射必须稳定，否则同一家的查询片区会随同步顺序漂移。
     */
    fun loadSnapshot(ctx: Context) {
        val all = readEntries(ctx)
        val map = LinkedHashMap<String, Entry>()
        all.values.forEach { list -> list.forEach { e -> map.putIfAbsent(e.code, e) } }
        snapshot = map
    }

    /** 查门店档案；没有就返回 null（调用方决定怎么办，不要静默兜底）。 */
    fun entryOf(code: String): Entry? = snapshot[code]

    /** 门店显示名：优先用接口名，接口没有（还没拉到）时回退到内置表。 */
    fun displayName(code: String): String? {
        val e = snapshot[code]
        return if (e != null && e.name.isNotBlank()) e.name else null
    }

    /** 门店所在城市；接口数据里取，取不到返回 null。 */
    fun cityOf(code: String): String? {
        val e = snapshot[code]
        return if (e != null && e.city.isNotBlank()) e.city else null
    }

    /** 门店所属片区（拉取它时用的 location）；没有记录返回 null。 */
    fun locationOf(code: String): String? {
        val e = snapshot[code]
        return if (e != null && e.location.isNotBlank()) e.location else null
    }

    /**
     * 这家店出现在**哪些**片区的响应里（按缓存顺序，先到先得）。
     *
     * 宽门店集下一次请求会带回邻近城市的店，所以一家店可能同时出现在多个片区的缓存里。
     * 查询它时挑哪个片区，原则是**挑它自己城市的那个**——那样响应里门店最齐、判定最准。
     */
    fun locationsOf(ctx: Context, code: String): List<String> {
        val out = ArrayList<String>()
        readEntries(ctx).forEach { (loc, list) ->
            if (list.any { it.code == code }) out.add(loc)
        }
        return out
    }

    /**
     * 查询这家店该用哪个 location。
     *
     * 优先用它**自己城市**对应的片区（内置映射表算出来的）——
     * 若该片区确实能返回这家店（缓存里出现过），就用它；
     * 否则退而求其次用"它出现过的任一片区"；
     * 都没有就用内置城市映射表。
     */
    fun queryLocationFor(ctx: Context, code: String, city: String): String {
        val own = Catalog.locationOf(city)
        val seen = locationsOf(ctx, code)
        if (own.isNotBlank() && seen.contains(own)) return own
        if (seen.isNotEmpty()) return seen.first()
        return own
    }

    /** 某个 location 下的门店（缓存，可能已过期）。 */
    fun cachedForLocation(ctx: Context, location: String): List<Entry> =
        readEntries(ctx)[location] ?: emptyList()

    /** 某个 location 的缓存是否新鲜。 */
    fun isFresh(ctx: Context, location: String): Boolean {
        val ts = readFetched(ctx)[location] ?: 0L
        return ts > 0 && System.currentTimeMillis() - ts < TTL_MS
    }

    /** 已缓存门店里属于某个城市的那些（按门店编号去重）。 */
    fun cachedForCity(ctx: Context, city: String): List<Entry> {
        val seen = LinkedHashSet<String>()
        val out = ArrayList<Entry>()
        readEntries(ctx).values.forEach { list ->
            list.forEach { if (it.city == city && seen.add(it.code)) out.add(it) }
        }
        return out
    }

    /**
     * 已缓存的全部门店，按城市分组（城市用接口返回的 city 字段）。
     * 返回 city -> 该城市的门店列表，组内按门店名排序。
     *
     * **必须按门店编号去重**：接口用宽门店集（pl=false）时，
     * 不同片区返回的门店集互相重叠（广东 广州 那一片就同时含南宁/厦门/长沙等店），
     * 同一编号会在多个片区的缓存里各存一份，不去重界面会把同一家店列出来很多遍。
     */
    fun cachedStores(ctx: Context): Map<String, List<Entry>> {
        val byCity = LinkedHashMap<String, MutableList<Entry>>()
        val seen = HashSet<String>()
        readEntries(ctx).values.forEach { list ->
            list.forEach { e ->
                if (!seen.add(e.code)) return@forEach
                val city = e.city.ifBlank { "其他" }
                byCity.getOrPut(city) { ArrayList() }.add(e)
            }
        }
        return byCity.mapValues { (_, l) -> l.sortedBy { it.name } }
    }

    /**
     * 门店档案（带缓存里记录的 location）。
     *
     * 宽门店集下同一家店会在多个片区的缓存里出现，`location` 字段可能各不相同。
     * 这里返回**它自己城市**对应的那份（最准），没有才回退到任意一份。
     */
    fun entryOf(ctx: Context, code: String): Entry? {
        var fallback: Entry? = null
        readEntries(ctx).forEach { (loc, list) ->
            list.forEach { e ->
                if (e.code != code) return@forEach
                if (fallback == null) fallback = e
                if (e.city.isNotBlank() && Catalog.locationOf(e.city) == loc) {
                    fallback = e
                    return@forEach
                }
            }
        }
        return fallback
    }

    /** 某城市是否有可用的缓存（决定界面上要不要显示"加载中"）。 */
    fun hasAnyCached(ctx: Context): Boolean = readEntries(ctx).values.any { it.isNotEmpty() }

    /**
     * 拉取一个片区的门店清单并写入缓存。
     *
     * 走后台配额池：门店目录同步是不紧急的后台任务，
     * 不能占用前台（监控 + 手动查询）的请求额度。
     *
     * @param cb 回调在主线程执行；(门店列表, 错误信息)，成功时错误信息为空串。
     */
    fun fetch(
        ctx: Context,
        location: String,
        part: String,
        cb: (List<Entry>?, String) -> Unit
    ) {
        val wait = RequestBudget.reserve(ctx, 1, RequestBudget.Pool.BACKGROUND)
        if (wait > 0) {
            cb(null, "请求太频繁，请 ${wait / 1000} 秒后再试")
            return
        }
        WebStockQuerier.queryBatch(ctx, location, listOf(part)) { res ->
            when {
                res.limited -> {
                    // 后台同步撞 541：只停后台同步，**不触发全局熔断**。
                    // 熔断是给前台用的——后台目录同步不该让用户查不了库存。
                    RequestBudget.tripBackgroundCircuit(ctx)
                    cb(null, "被官网限流，请稍后再试")
                }
                !res.ok -> cb(null, res.error.ifEmpty { "获取门店列表失败" })
                else -> {
                    // location 记原始请求串（用于溯源与去重），
                    // 查询用哪个片区由 locationsOf() 按"这家店在哪些片区的响应里出现过"决定。
                    val list = res.stores.map {
                        Entry(it.code, it.name, it.city, it.state, location)
                    }.filter { it.code.isNotBlank() }
                    if (list.isEmpty()) {
                        cb(null, "该区域暂无直营店")
                    } else {
                        saveLocation(ctx, location, list)
                        cb(list, "")
                    }
                }
            }
        }
    }

    /** 把一个片区的门店写进缓存并刷新内存快照。 */
    private fun saveLocation(ctx: Context, location: String, list: List<Entry>) {
        val all = readEntries(ctx)
        all[location] = ArrayList(list)
        writeEntries(ctx, all)
        val fetched = readFetched(ctx)
        fetched[location] = System.currentTimeMillis()
        writeFetched(ctx, fetched)
        loadSnapshot(ctx)
    }

    /**
     * 后台同步全国门店目录。
     *
     * 依次拉取所有内置 location 的门店清单，遵守请求预算与熔断：
     * 预算不足就等待，撞 541 就停止并等冷却期结束。
     * 16 个片区约需 6 分钟（受后台池 3 次/分钟限制），跑完后缓存 7 天内都直接用。
     *
     * 走**后台配额池**，与用户的前台请求（监控 + 手动查询）完全隔离——
     * 后台同步再慢也不会让用户「点了查询查不了」。
     *
     * 撞 541 时只暂停**后台**（[RequestBudget.backgroundCircuitRemaining]），
     * 不触发前台熔断——门店名拿不到不影响用户查库存。
     *
     * 这样门店表不需要每次发版人工维护：苹果新开门店会自动出现，
     * 关门的会自动消失。
     */
    fun syncAll(ctx: Context, part: String, onDone: (synced: Int, total: Int) -> Unit) {
        Thread {
            val locations = Catalog.locations()
            var synced = 0
            for (loc in locations) {
                // 已缓存且新鲜的片区跳过
                if (isFresh(ctx, loc)) {
                    synced++
                    continue
                }
                // 后台熔断中就整体退出，等冷却期过后下次再续
                if (RequestBudget.backgroundCircuitRemaining(ctx) > 0) break
                // 预算不足：等额度恢复。
                // 这里用 peek（只看不扣），实际扣额度交给下面的 fetch——
                // 否则一次片区会扣两次额度（外层预留 + 内层预留），
                // 请求根本没发出去额度却已经没了。
                var wait = RequestBudget.peek(ctx, 1, RequestBudget.Pool.BACKGROUND)
                var guard = 0
                while (wait > 0 && guard < 120) {
                    Thread.sleep(minOf(wait, 15_000L))
                    if (RequestBudget.backgroundCircuitRemaining(ctx) > 0) break
                    wait = RequestBudget.peek(ctx, 1, RequestBudget.Pool.BACKGROUND)
                    guard++
                }
                if (RequestBudget.backgroundCircuitRemaining(ctx) > 0) break

                val done = java.util.concurrent.CountDownLatch(1)
                var failed = false
                fetch(ctx, loc, part) { list, err ->
                    if (list != null) synced++
                    else if (err.contains("限流")) failed = true
                    done.countDown()
                }
                done.await(40, java.util.concurrent.TimeUnit.SECONDS)
                if (failed) break
            }
            loadSnapshot(ctx)
            onDone(synced, locations.size)
        }.start()
    }
}
