package com.apple.stockmonitor

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator

/**
 * 前台常驻监控服务：多目标（型号×门店）轮询直营店取货信号。
 *
 * v2.3.0 起改为**按 location 分组请求**：
 * - 同一片区的多个监控目标合并成一次请求（接口支持 parts.0 / parts.1 … 多 part）；
 * - 每轮开始前向 [RequestBudget] 申请额度，额度不足就推迟本轮，绝不超发；
 * - 撞上 HTTP 541 立即熔断（10→20→40→60 分钟），冷却期内一个请求都不发；
 * - 生效间隔按网络类型取：WiFi 高频档，移动数据省流量档；
 * - 去重：同一目标有货只通知一次，变无货后重置；
 * - 限流自适应：连续 2 轮失败 → 间隔 ×1.8（封顶 5 分钟）；连续 2 轮成功 → 回落。
 */
class MonitorService : Service() {

    companion object {
        const val ACTION_START = "com.apple.stockmonitor.START"
        const val ACTION_STOP = "com.apple.stockmonitor.STOP"
        const val CHANNEL_FOREGROUND = "fg"
        const val CHANNEL_ALERT = "alert_v2"
        const val NOTIF_FG = 1001
        const val NOTIF_ALERT = 1002
    }

    private lateinit var thread: HandlerThread
    private lateinit var handler: Handler
    @Volatile private var running = false

    // 限流自适应会话状态
    private var failStreak = 0
    private var successStreak = 0

    /** 熔断剩余毫秒数；>0 表示正在熔断冷却期。 */
    @Volatile private var circuitLeft = 0L

    override fun onCreate() {
        super.onCreate()
        createChannels()
        thread = HandlerThread("stock-monitor").also { it.start() }
        handler = Handler(thread.looper)
        failStreak = 0
        successStreak = 0
        circuitLeft = 0L
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopMonitoring()
                return START_NOT_STICKY
            }
            else -> startMonitoring()
        }
        return START_STICKY
    }

    private fun startMonitoring() {
        Prefs.running = true
        // 重启监控时只重置「已变成无货」目标的通知标记，
        // 仍然有货的目标保持已通知状态，避免每次重启都把同一批有货目标再弹一遍横幅。
        val stillAvailable = Prefs.targets(this)
            .filter { Prefs.lastResult(this, it.key()) == "available" }
            .map { it.key() }
            .toSet()
        Prefs.clearNotifiedForNoLongerAvailable(this, stillAvailable)
        Prefs.roundCount = 0      // 重置轮次计数
        startForeground(NOTIF_FG, buildFgNotification())
        running = true
        circuitLeft = 0L
        val n = Prefs.targets(this).size
        AppLogger.i(this, "监控", "监控已启动：共 $n 个目标，${NetProbe.label(this)}下每 ${Prefs.effectiveInterval(this)} 秒")
        scheduleNext(0L)
    }

    private fun stopMonitoring() {
        running = false
        Prefs.running = false
        handler.removeCallbacksAndMessages(null)
        WebStockQuerier.destroy()
        stopForeground(STOP_FOREGROUND_REMOVE)
        AppLogger.i(this, "监控", "监控已停止")
        stopSelf()
    }

    private fun scheduleNext(delayMs: Long) {
        handler.postDelayed({ if (running) tick() }, delayMs)
    }

    private fun tick() {
        if (!running) return

        // ---- 541 熔断：冷却期内一个请求都不发 ----
        val left = RequestBudget.circuitRemaining(this)
        if (left > 0) {
            if (circuitLeft <= 0L) {
                AppLogger.i(this, "监控", "被苹果官网限流，暂停请求，约 ${(left + 59_999) / 60_000} 分钟后自动恢复")
            }
            circuitLeft = left
            updateFgNotification()
            scheduleNext(minOf(left, 30_000L))
            return
        }
        circuitLeft = 0L

        val targets = Prefs.targets(this)
        if (targets.isEmpty()) {
            scheduleNext(Prefs.effectiveInterval(this) * 1000L)
            return
        }

        // ---- 按 location 分组：同片区的多个目标合并成一次请求 ----
        val groups = groupByLocation(this, targets)

        // ---- 请求预算：额度不足就推迟本轮 ----
        val wait = RequestBudget.reserve(this, groups.size)
        if (wait > 0) {
            Prefs.nextCheckTime = fmt(System.currentTimeMillis() + wait)
            scheduleNext(wait)
            return
        }

        queryGroups(groups, 0, Round(targets.size))
    }

    private class Round(val total: Int) {
        var done = 0
        var failAny = false
        var availAny = false
        val results = mutableListOf<Pair<Prefs.Target, WebStockQuerier.Outcome>>()
    }

    /** 同一 location 的一组目标（由顶层 [groupByLocation] 构造）。 */
    private fun queryGroups(groups: List<LocationGroup>, idx: Int, round: Round) {
        if (!running) return
        if (idx >= groups.size) {
            finishRound(round)
            return
        }
        val g = groups[idx]
        WebStockQuerier.queryBatch(this, g.location, g.parts) { res ->
            if (!running) return@queryBatch
            when {
                res.limited -> {
                    // 撞风控：整组失败并立即熔断，不再发后续请求
                    RequestBudget.tripCircuit(this)
                    circuitLeft = RequestBudget.circuitRemaining(this)
                    round.failAny = true
                    AppLogger.e(this, "监控", "被苹果官网限流，已暂停请求",
                        "HTTP 541，约 ${(circuitLeft + 59_999) / 60_000} 分钟后自动恢复")
                    g.targets.forEach {
                        val o = WebStockQuerier.Outcome(null, "被官网限流，已暂停请求")
                        round.results.add(it to o)
                        handleTarget(it, o)
                    }
                    finishRound(round)
                    return@queryBatch
                }
                !res.ok -> {
                    round.failAny = true
                    g.targets.forEach {
                        val o = WebStockQuerier.Outcome(null, res.error)
                        round.results.add(it to o)
                        handleTarget(it, o)
                    }
                }
                else -> {
                    RequestBudget.clearCircuit(this)
                    g.targets.forEach {
                        val o = WebStockQuerier.resolveOne(res, it.part, it.store)
                        round.results.add(it to o)
                        if (o.available == null) round.failAny = true
                        if (o.available == true) round.availAny = true
                        handleTarget(it, o)
                    }
                }
            }
            queryGroups(groups, idx + 1, round)
        }
    }

    private fun handleTarget(t: Prefs.Target, o: WebStockQuerier.Outcome) {
        // 每个目标各记各的最后检查时间（不再用一个全局单值）
        Prefs.setLastCheckTimeOf(this, t.key(), nowStr())
        val key = t.key()
        when (o.available) {
            true -> {
                Prefs.setLastResult(this, key, "available")
                // 有货：首次必弹；之后每 2 轮重复弹一次
                val roundsSinceNotify = Prefs.notifyRound(this, key)
                val shouldNotify = (key !in Prefs.notified(this)) || (roundsSinceNotify >= 2)
                if (shouldNotify) {
                    Prefs.setNotified(this, key)
                    Prefs.setNotifyRound(this, key, 0)
                    alert(t, o.detail)
                    val sk = Prefs.sendkey(this)
                    if (sk.isNotBlank()) {
                        try {
                            StockChecker.pushWechat(
                                sk,
                                "📱 ${t.label()} 有货可自提！",
                                buildDesp(t, o.detail)
                            )
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                    Prefs.addEvent(this, "${t.shortLabel()}：${o.detail.ifEmpty { "有货可自提" }}", true)
                } else {
                    // 持续有货但未到2轮，累计轮数
                    Prefs.setNotifyRound(this, key, roundsSinceNotify + 1)
                }
            }
            false -> {
                Prefs.setLastResult(this, key, "unavailable")
                // 无货不弹横幅；清除通知标记和轮次计数，下次有货重新弹
                if (key in Prefs.notified(this)) Prefs.resetNotified(this, key)
                Prefs.setNotifyRound(this, key, 0)
            }
            else -> {
                Prefs.setLastResult(this, key, "fail")
                // 被限流时不刷屏（同一组会连续失败多条）
                if (!o.detail.contains("限流")) {
                    Prefs.addEvent(this, "${t.shortLabel()}：${o.detail.ifEmpty { "查询失败" }}", false)
                }
            }
        }
    }

    private fun finishRound(round: Round) {
        if (!running) return
        // 统计本轮结果
        var avail = 0; var unavail = 0; var fail = 0
        round.results.forEach { (_, o) ->
            when (o.available) {
                true -> avail++
                false -> unavail++
                else -> fail++
            }
        }
        // 连续无货次数：本轮全部成功且全无货才累计；任一有货即清零
        if (round.failAny) {
            // 失败轮：不动 streak
        } else if (round.availAny) {
            Prefs.streak = 0
        } else {
            Prefs.streak = Prefs.streak + 1
        }

        // 运行轮次 +1（用于 hero 显示"已运行 N 轮"，判断 Service 是否还活着）
        Prefs.roundCount = Prefs.roundCount + 1

        // 每 60 轮检查一次新版本：用户不打开 App 也能收到更新提示
        if (Prefs.roundCount % 60 == 0) {
            UpdateChecker.check(this)
        }

        // 每轮写一条简要日志，让记录页能看到连续查询历史
        val summary = "第${Prefs.roundCount}轮：$avail 有货/$unavail 无货" + if (fail > 0) "/$fail 失败" else ""
        Prefs.addLog(this, summary, avail > 0)

        // 全局检查时间每轮只写一次（每个目标的时间各自存在 Prefs.setLastCheckTimeOf）
        Prefs.lastCheckTime = nowStr()

        val base = Prefs.effectiveInterval(this)
        var eff = base.toLong()
        if (Prefs.adaptive(this)) {
            if (round.failAny) {
                failStreak++; successStreak = 0
            } else {
                successStreak++; failStreak = 0
            }
            var factor = Prefs.factor(this)
            val cap = 300.0 / base
            if (failStreak >= 2) factor = minOf(factor * 1.8f, cap.toFloat())
            else if (successStreak >= 2) factor = maxOf(1f, factor / 1.8f)
            Prefs.saveFactor(this, factor)
            eff = (base * factor).toLong().coerceAtMost(300)
        }
        Prefs.nextCheckTime = fmt(System.currentTimeMillis() + eff * 1000)
        // 每轮更新前台通知，状态栏实时反映有货/无货状态
        updateFgNotification()
        scheduleNext(eff * 1000L)
    }

    private fun alert(t: Prefs.Target, detail: String) {
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val buyUrl = Catalog.buyUrl(t.part)
        val openStore = PendingIntent.getActivity(
            this, 1,
            Intent(Intent.ACTION_VIEW, android.net.Uri.parse(buyUrl)),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builder = Notification.Builder(this, CHANNEL_ALERT)
            .setSmallIcon(R.drawable.ic_stat_stock)
            .setContentTitle("📱 ${t.label()} 可到店自提！")
            .setContentText("${Catalog.storeLabel(t.store)} 有货，赶紧下单")
            .setStyle(Notification.BigTextStyle()
                .bigText("门店：${Catalog.storeLabel(t.store)}（${Catalog.cityOf(t.store)}）\n" +
                        "型号：${t.part}\n" +
                        "官网状态：$detail\n" +
                        "补货窗口短，尽快去官网确认下单。"))
            .setPriority(Notification.PRIORITY_HIGH)
            .setCategory(Notification.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(openApp)
            .addAction(android.R.drawable.ic_menu_send, "去官网抢购", openStore)
        if (!Prefs.notifySound(this)) {
            builder.setSound(null, null)
        } else {
            builder.setDefaults(Notification.DEFAULT_SOUND)
        }
        if (Prefs.notifyVibrate(this)) {
            val vm = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (vm.hasVibrator()) {
                vm.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 300, 150, 300), -1))
            }
        }
        if (Prefs.notifyLocal(this)) {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .notify(NOTIF_ALERT, builder.build())
        }
    }

    private fun buildFgNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val targets = Prefs.targets(this)
        val n = targets.size
        val availCount = targets.count { Prefs.lastResult(this, it.key()) == "available" }
        val circuit = RequestBudget.circuitRemaining(this)
        val net = NetProbe.label(this)
        val ivl = Prefs.effectiveInterval(this)
        val title = when {
            circuit > 0 -> "已暂停 · 官网限流"
            availCount > 0 -> "有货可自提！"
            else -> "库存提醒助手"
        }
        val text = when {
            circuit > 0 -> "被苹果官网限流，约 ${(circuit + 59_999) / 60_000} 分钟后自动恢复"
            n == 1 -> "监控中 · ${targets[0].shortLabel()}"
            else -> "监控中 · $n 个目标" + if (availCount > 0) "（$availCount 有货）" else ""
        }
        val icon = if (availCount > 0) R.drawable.ic_stat_stock else R.drawable.ic_stat_monitor
        return Notification.Builder(this, CHANNEL_FOREGROUND)
            .setSmallIcon(icon)
            .setContentTitle(title)
            .setContentText(text)
            .setSubText("$net · 每 $ivl 秒")
            .setOngoing(true)
            .setContentIntent(openApp)
            .build()
    }

    /** 更新前台通知（不重建通知，只改内容）。 */
    private fun updateFgNotification() {
        try {
            startForeground(NOTIF_FG, buildFgNotification())
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun buildDesp(t: Prefs.Target, detail: String): String {
        val buyUrl = Catalog.buyUrl(t.part)
        return "【${t.label()}】${Catalog.storeLabel(t.store)} 现已显示可到店自提！\n\n" +
                "- 型号编号：${t.part}\n" +
                "- 门店：${Catalog.storeLabel(t.store)}（${Catalog.cityOf(t.store)}）\n" +
                "- 官网状态：$detail\n\n" +
                "补货窗口短，请立刻确认下单：\n$buyUrl\n\n" +
                "时间：${nowStr()}"
    }

    private fun createChannels() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_FOREGROUND, "监控常驻", NotificationManager.IMPORTANCE_LOW)
                .apply { description = "保持后台监控运行" }
        )
        // 有货提醒：HIGH 重要性才能弹横幅；不锁定静音，让用户设置控制声音
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ALERT, "有货提醒", NotificationManager.IMPORTANCE_HIGH)
                .apply {
                    description = "有货时弹出醒目横幅通知"
                    setBypassDnd(true)
                    enableVibration(true)
                    enableLights(true)
                }
        )
    }

    override fun onDestroy() {
        running = false
        Prefs.running = false
        handler.removeCallbacksAndMessages(null)
        WebStockQuerier.destroy()
        thread.quitSafely()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun nowStr(): String =
        java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.CHINA)
            .format(java.util.Date())

    private fun fmt(ts: Long): String =
        java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.CHINA)
            .format(java.util.Date(ts))
}
