package com.apple.stockmonitor

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator

/**
 * 前台常驻监控服务：多目标（型号×门店）串行轮询全国直营店取货信号。
 * - 去重：同一目标有货只通知一次，变无货后重置；
 * - 限流自适应：连续 2 轮失败 → 间隔 ×1.8（封顶 5 分钟）；连续 2 轮成功 → 回落；失败当轮不硬重试；
 * - 状态栏：监控中常驻「手机+运行点」，查到货切「铃铛+提示点」；
 * - 仅系统 Framework，无第三方依赖。
 */
class MonitorService : Service() {

    companion object {
        const val ACTION_START = "com.apple.stockmonitor.START"
        const val ACTION_STOP = "com.apple.stockmonitor.STOP"
        const val CHANNEL_FOREGROUND = "fg"
        const val CHANNEL_ALERT = "alert_v2"
        const val NOTIF_FG = 1001
        const val NOTIF_ALERT = 1002
    }

    private lateinit var thread: HandlerThread
    private lateinit var handler: Handler
    @Volatile private var running = false

    // 限流自适应会话状态
    private var failStreak = 0
    private var successStreak = 0

    override fun onCreate() {
        super.onCreate()
        createChannels()
        thread = HandlerThread("stock-monitor").also { it.start() }
        handler = Handler(thread.looper)
        failStreak = 0
        successStreak = 0
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopMonitoring()
                return START_NOT_STICKY
            }
            else -> startMonitoring()
        }
        return START_STICKY
    }

    private fun startMonitoring() {
        Prefs.running = true
        Prefs.clearNotified(this) // 重启后有货目标重新触发提醒
        Prefs.roundCount = 0      // 重置轮次计数
        startForeground(NOTIF_FG, buildFgNotification())
        running = true
        scheduleNext(0L)
    }

    private fun stopMonitoring() {
        running = false
        Prefs.running = false
        handler.removeCallbacksAndMessages(null)
        WebStockQuerier.destroy()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun scheduleNext(delayMs: Long) {
        handler.postDelayed({ if (running) tick() }, delayMs)
    }

    private fun tick() {
        val targets = Prefs.targets(this)
        if (targets.isEmpty()) {
            scheduleNext(Prefs.interval(this) * 1000L)
            return
        }
        queryTargets(targets, 0, Round(targets.size))
    }

    private class Round(val total: Int) {
        var done = 0
        var failAny = false
        var availAny = false
        val results = mutableListOf<Pair<Prefs.Target, WebStockQuerier.Outcome>>()
    }

    private fun queryTargets(targets: List<Prefs.Target>, idx: Int, round: Round) {
        if (!running) return
        if (idx >= targets.size) {
            finishRound(round)
            return
        }
        val t = targets[idx]
        WebStockQuerier.query(this, t.part, t.store, object : WebStockQuerier.Listener {
            override fun onResult(o: WebStockQuerier.Outcome) {
                if (!running) return
                round.done++
                round.results.add(t to o)
                if (o.available == null) round.failAny = true
                if (o.available == true) round.availAny = true
                handleTarget(t, o)
                queryTargets(targets, idx + 1, round)
            }
        })
    }

    private fun handleTarget(t: Prefs.Target, o: WebStockQuerier.Outcome) {
        Prefs.lastCheckTime = nowStr()
        val key = t.key()
        when (o.available) {
            true -> {
                Prefs.setLastResult(this, key, "available")
                // 有货：首次必弹；之后每 2 轮重复弹一次
                val roundsSinceNotify = Prefs.notifyRound(this, key)
                val shouldNotify = (key !in Prefs.notified(this)) || (roundsSinceNotify >= 2)
                if (shouldNotify) {
                    Prefs.setNotified(this, key)
                    Prefs.setNotifyRound(this, key, 0)
                    alert(t, o.detail)
                    val sk = Prefs.sendkey(this)
                    if (sk.isNotBlank()) {
                        try {
                            StockChecker.pushWechat(
                                sk,
                                "📱 ${t.label()} 有货可自提！",
                                buildDesp(t, o.detail)
                            )
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                    Prefs.addLog(this, "${t.shortLabel()}：${o.detail.ifEmpty { "有货可自提" }}", true)
                } else {
                    // 持续有货但未到2轮，累计轮数
                    Prefs.setNotifyRound(this, key, roundsSinceNotify + 1)
                }
            }
            false -> {
                Prefs.setLastResult(this, key, "unavailable")
                // 无货不弹横幅；清除通知标记和轮次计数，下次有货重新弹
                if (key in Prefs.notified(this)) Prefs.resetNotified(this, key)
                Prefs.setNotifyRound(this, key, 0)
            }
            else -> {
                Prefs.setLastResult(this, key, "fail")
                Prefs.addLog(this, "${t.shortLabel()}：${o.detail.ifEmpty { "查询失败" }}", false)
            }
        }
    }

    private fun finishRound(round: Round) {
        if (!running) return
        // 统计本轮结果
        var avail = 0; var unavail = 0; var fail = 0
        round.results.forEach { (_, o) ->
            when (o.available) {
                true -> avail++
                false -> unavail++
                else -> fail++
            }
        }
        // 连续无货次数：本轮全部成功且全无货才累计；任一有货即清零
        if (round.failAny) {
            // 失败轮：不动 streak
        } else if (round.availAny) {
            Prefs.streak = 0
        } else {
            Prefs.streak = Prefs.streak + 1
        }

        // 运行轮次 +1（用于 hero 显示"已运行 N 轮"，判断 Service 是否还活着）
        Prefs.roundCount = Prefs.roundCount + 1

        // 每轮写一条简要日志，让记录页能看到连续查询历史
        val summary = "第${Prefs.roundCount}轮：${avail}有货/${unavail}无货" + if (fail > 0) "/${fail}失败" else ""
        Prefs.addLog(this, summary, avail > 0)

        val base = Prefs.interval(this)
        var eff = base.toLong()
        if (Prefs.adaptive(this)) {
            if (round.failAny) {
                failStreak++; successStreak = 0
            } else {
                successStreak++; failStreak = 0
            }
            var factor = Prefs.factor(this)
            val cap = 300.0 / base
            if (failStreak >= 2) factor = minOf(factor * 1.8f, cap.toFloat())
            else if (successStreak >= 2) factor = maxOf(1f, factor / 1.8f)
            Prefs.saveFactor(this, factor)
            eff = (base * factor).toLong().coerceAtMost(300)
        }
        Prefs.nextCheckTime =
            java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.CHINA)
                .format(java.util.Date(System.currentTimeMillis() + eff * 1000))
        // 每轮更新前台通知，状态栏实时反映有货/无货状态
        try {
            startForeground(NOTIF_FG, buildFgNotification())
        } catch (e: Exception) {
            e.printStackTrace()
        }
        scheduleNext(eff * 1000L)
    }

    private fun alert(t: Prefs.Target, detail: String) {
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val buyUrl = "https://www.apple.com.cn/shop/buy-iphone/iphone-18-pro/${t.part.lowercase()}"
        val openStore = PendingIntent.getActivity(
            this, 1,
            Intent(Intent.ACTION_VIEW, android.net.Uri.parse(buyUrl)),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builder = Notification.Builder(this, CHANNEL_ALERT)
            .setSmallIcon(R.drawable.ic_stat_stock)
            .setContentTitle("📱 ${t.label()} 可到店自提！")
            .setContentText("${Catalog.storeLabel(t.store)} 有货，赶紧下单")
            .setStyle(Notification.BigTextStyle()
                .bigText("门店：${Catalog.storeLabel(t.store)}（${Catalog.cityOf(t.store)}）\n" +
                        "型号：${t.part}\n" +
                        "官网状态：$detail\n" +
                        "补货窗口短，尽快去官网确认下单。"))
            .setPriority(Notification.PRIORITY_HIGH)
            .setCategory(Notification.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(openApp)
            .addAction(android.R.drawable.ic_menu_send, "去官网抢购", openStore)
        if (!Prefs.notifySound(this)) {
            builder.setSound(null, null)
        } else {
            builder.setDefaults(Notification.DEFAULT_SOUND)
        }
        if (Prefs.notifyVibrate(this)) {
            val vm = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (vm.hasVibrator()) {
                vm.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 300, 150, 300), -1))
            }
        }
        if (Prefs.notifyLocal(this)) {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .notify(NOTIF_ALERT, builder.build())
        }
    }

    private fun buildFgNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val targets = Prefs.targets(this)
        val n = targets.size
        val availCount = targets.count { Prefs.lastResult(this, it.key()) == "available" }
        val title = if (availCount > 0) "有货可自提！" else "iPhone 库存监控"
        val text = if (n == 1) "监控中 · ${targets[0].shortLabel()}"
        else "监控中 · $n 个目标" + if (availCount > 0) "（$availCount 有货）" else ""
        val icon = if (availCount > 0) R.drawable.ic_stat_stock else R.drawable.ic_stat_monitor
        return Notification.Builder(this, CHANNEL_FOREGROUND)
            .setSmallIcon(icon)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(openApp)
            .build()
    }

    private fun buildDesp(t: Prefs.Target, detail: String): String {
        val buyUrl = "https://www.apple.com.cn/shop/buy-iphone/iphone-18-pro/${t.part.lowercase()}"
        return "【${t.label()}】${Catalog.storeLabel(t.store)} 现已显示可到店自提！\n\n" +
                "- 型号编号：${t.part}\n" +
                "- 门店：${Catalog.storeLabel(t.store)}（${Catalog.cityOf(t.store)}）\n" +
                "- 官网状态：$detail\n\n" +
                "补货窗口短，请立刻确认下单：\n$buyUrl\n\n" +
                "时间：${nowStr()}"
    }

    private fun createChannels() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_FOREGROUND, "监控常驻", NotificationManager.IMPORTANCE_LOW)
                .apply { description = "保持后台监控运行" }
        )
        // 有货提醒：HIGH 重要性才能弹横幅；不锁定静音，让用户设置控制声音
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ALERT, "有货提醒", NotificationManager.IMPORTANCE_HIGH)
                .apply {
                    description = "有货时弹出醒目横幅通知"
                    setBypassDnd(true)
                    enableVibration(true)
                    enableLights(true)
                }
        )
    }

    override fun onDestroy() {
        running = false
        Prefs.running = false
        handler.removeCallbacksAndMessages(null)
        WebStockQuerier.destroy()
        thread.quitSafely()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun nowStr(): String =
        java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.CHINA)
            .format(java.util.Date())
}
