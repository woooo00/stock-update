package com.apple.stockmonitor

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * 开机广播接收器。
 *
 * 设备重启后 Android 会杀掉所有前台服务，监控随之停摆。
 * 本接收器**不自动恢复监控**，而是发一条通知告诉用户「监控已暂停」，
 * 用户点通知才重新开启。
 *
 * 为什么不让它自动恢复：
 * - 自动恢复会在用户没预期的时候开始消耗流量与电量；
 * - 部分系统 ROM 对开机自启后台服务管控严格，强行拉起反而可能被杀；
 * - 交给用户一个明确的选择，体验更可控。
 *
 * 只在「用户此前确实开着监控」时才发通知，避免打扰从未使用过该功能的人。
 */
class BootReceiver : BroadcastReceiver() {

    companion object {
        private const val CHANNEL_BOOT = "boot_restore_v1"
        private const val NOTIF_BOOT = 3001
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED &&
            intent.action != "android.intent.action.QUICKBOOT_POWERON" &&
            intent.action != "com.htc.intent.action.QUICKBOOT_POWERON"
        ) return

        // 只有此前开着监控才提示；用户主动停掉的就不打扰
        if (!Prefs.running) return
        if (Prefs.targets(context).isEmpty()) return

        try {
            notifyPaused(context)
        } catch (e: Exception) {
            AppLogger.e(context, "开机恢复", "发送暂停提示", e.message ?: "通知发送失败", e)
        }
    }

    private fun notifyPaused(context: Context) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_BOOT, "监控恢复提示", NotificationManager.IMPORTANCE_DEFAULT)
                    .apply { description = "设备重启后提示监控已暂停" }
            )
        }

        val resume = PendingIntent.getService(
            context, 0,
            Intent(context, MonitorService::class.java).setAction(MonitorService.ACTION_START),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val n = Notification.Builder(context, CHANNEL_BOOT)
            .setSmallIcon(R.drawable.ic_stat_monitor)
            .setContentTitle("监控已暂停")
            .setContentText("设备重启后监控已停止，点此恢复")
            .setAutoCancel(true)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "恢复监控", resume).build())
            .build()
        nm.notify(NOTIF_BOOT, n)

        AppLogger.i(context, "开机恢复", "设备重启，监控已暂停，已发送恢复提示通知")
    }
}
