package com.apple.stockmonitor

/** 型号、门店（全国直营 25 城 49 店）、间隔档位；门店编号与 location 均已用官网接口核对。 */
object Catalog {

    data class ModelOpt(val part: String, val label: String)
    data class StoreOpt(val code: String, val name: String, val city: String)
    data class IntervalOpt(val sec: Int, val label: String)

    // ---- 三级选择：尺寸 / 颜色 / 内存 ----
    val SIZES = listOf("Pro Max", "Pro", "Duo")
    val STORAGES = listOf("256GB", "512GB", "1TB", "2TB")
    // Pro/Pro Max 4色；Duo 2色（运行时按尺寸过滤显示）
    val COLORS_PRO = listOf("黑色", "银色", "酒红", "冰川蓝")
    val COLORS_DUO = listOf("夜空色", "星光白色")

    /** 某尺寸下可选颜色。 */
    fun colorsFor(size: String): List<String> = if (size == "Duo") COLORS_DUO else COLORS_PRO

    /** SKU 映射：尺寸 → 内存 → 颜色 → part number（与官网购买页核对）。 */
    private val SKU_MAP: Map<String, Map<String, Map<String, String>>> = mapOf(
        "Pro Max" to mapOf(
            "256GB" to mapOf("黑色" to "MJY64CH/A", "银色" to "MJY74CH/A", "酒红" to "MJY84CH/A", "冰川蓝" to "MJY94CH/A"),
            "512GB" to mapOf("黑色" to "MJYA4CH/A", "银色" to "MJYC4CH/A", "酒红" to "MJYD4CH/A", "冰川蓝" to "MJYE4CH/A"),
            "1TB" to mapOf("黑色" to "MJYF4CH/A", "银色" to "MJYG4CH/A", "酒红" to "MJYH4CH/A", "冰川蓝" to "MJYJ4CH/A"),
            "2TB" to mapOf("黑色" to "MJYK4CH/A", "银色" to "MJYL4CH/A", "酒红" to "MJYM4CH/A", "冰川蓝" to "MJYN4CH/A"),
        ),
        "Pro" to mapOf(
            "256GB" to mapOf("黑色" to "MJT74CH/A", "银色" to "MJT84CH/A", "酒红" to "MJT94CH/A", "冰川蓝" to "MJTA4CH/A"),
            "512GB" to mapOf("黑色" to "MJTC4CH/A", "银色" to "MJTD4CH/A", "酒红" to "MJTE4CH/A", "冰川蓝" to "MJTF4CH/A"),
            "1TB" to mapOf("黑色" to "MJTG4CH/A", "银色" to "MJTH4CH/A", "酒红" to "MJTJ4CH/A", "冰川蓝" to "MJTK4CH/A"),
            "2TB" to mapOf("黑色" to "MJTL4CH/A", "银色" to "MJTM4CH/A", "酒红" to "MJTN4CH/A", "冰川蓝" to "MJTP4CH/A"),
        ),
        "Duo" to mapOf(
            "256GB" to mapOf("夜空色" to "MK2N4CH/A", "星光白色" to "MK2M4CH/A"),
            "512GB" to mapOf("夜空色" to "MK2Q4CH/A", "星光白色" to "MK2P4CH/A"),
            "1TB" to mapOf("夜空色" to "MK2U4CH/A", "星光白色" to "MK2T4CH/A"),
            "2TB" to mapOf("夜空色" to "MK2W4CH/A", "星光白色" to "MK2V4CH/A"),
        ),
    )

    fun partFor(size: String, storage: String, color: String): String =
        SKU_MAP[size]?.get(storage)?.get(color) ?: MODELS[0].part

    fun parsePart(part: String): Triple<String, String, String> {
        for ((size, sm) in SKU_MAP) {
            for ((storage, cm) in sm) {
                for ((color, p) in cm) {
                    if (p == part) return Triple(size, storage, color)
                }
            }
        }
        return Triple("Pro Max", "512GB", "银色")
    }

    /** iPhone 18 全系列在售型号：Pro（非 Max）16 款 + Pro Max 16 款，4 容量 × 4 颜色，共 32 款（SKU 已与官网购买页核对）。 */
    val MODELS: List<ModelOpt> = listOf(
        // ---- iPhone 18 Pro Max ----
        ModelOpt("MJY64CH/A", "Pro Max · 256GB · 黑色"),
        ModelOpt("MJY74CH/A", "Pro Max · 256GB · 银色"),
        ModelOpt("MJY84CH/A", "Pro Max · 256GB · 酒红"),
        ModelOpt("MJY94CH/A", "Pro Max · 256GB · 冰川蓝"),
        ModelOpt("MJYA4CH/A", "Pro Max · 512GB · 黑色"),
        ModelOpt("MJYC4CH/A", "Pro Max · 512GB · 银色"),
        ModelOpt("MJYD4CH/A", "Pro Max · 512GB · 酒红"),
        ModelOpt("MJYE4CH/A", "Pro Max · 512GB · 冰川蓝"),
        ModelOpt("MJYF4CH/A", "Pro Max · 1TB · 黑色"),
        ModelOpt("MJYG4CH/A", "Pro Max · 1TB · 银色"),
        ModelOpt("MJYH4CH/A", "Pro Max · 1TB · 酒红"),
        ModelOpt("MJYJ4CH/A", "Pro Max · 1TB · 冰川蓝"),
        ModelOpt("MJYK4CH/A", "Pro Max · 2TB · 黑色"),
        ModelOpt("MJYL4CH/A", "Pro Max · 2TB · 银色"),
        ModelOpt("MJYM4CH/A", "Pro Max · 2TB · 酒红"),
        ModelOpt("MJYN4CH/A", "Pro Max · 2TB · 冰川蓝"),
        // ---- iPhone 18 Pro（非 Max）----
        ModelOpt("MJT74CH/A", "Pro · 256GB · 黑色"),
        ModelOpt("MJT84CH/A", "Pro · 256GB · 银色"),
        ModelOpt("MJT94CH/A", "Pro · 256GB · 酒红"),
        ModelOpt("MJTA4CH/A", "Pro · 256GB · 冰川蓝"),
        ModelOpt("MJTC4CH/A", "Pro · 512GB · 黑色"),
        ModelOpt("MJTD4CH/A", "Pro · 512GB · 银色"),
        ModelOpt("MJTE4CH/A", "Pro · 512GB · 酒红"),
        ModelOpt("MJTF4CH/A", "Pro · 512GB · 冰川蓝"),
        ModelOpt("MJTG4CH/A", "Pro · 1TB · 黑色"),
        ModelOpt("MJTH4CH/A", "Pro · 1TB · 银色"),
        ModelOpt("MJTJ4CH/A", "Pro · 1TB · 酒红"),
        ModelOpt("MJTK4CH/A", "Pro · 1TB · 冰川蓝"),
        ModelOpt("MJTL4CH/A", "Pro · 2TB · 黑色"),
        ModelOpt("MJTM4CH/A", "Pro · 2TB · 银色"),
        ModelOpt("MJTN4CH/A", "Pro · 2TB · 酒红"),
        ModelOpt("MJTP4CH/A", "Pro · 2TB · 冰川蓝"),
        // ---- iPhone Duo ----
        ModelOpt("MK2M4CH/A", "Duo · 256GB · 星光白色"),
        ModelOpt("MK2N4CH/A", "Duo · 256GB · 夜空色"),
        ModelOpt("MK2P4CH/A", "Duo · 512GB · 星光白色"),
        ModelOpt("MK2Q4CH/A", "Duo · 512GB · 夜空色"),
        ModelOpt("MK2T4CH/A", "Duo · 1TB · 星光白色"),
        ModelOpt("MK2U4CH/A", "Duo · 1TB · 夜空色"),
        ModelOpt("MK2V4CH/A", "Duo · 2TB · 星光白色"),
        ModelOpt("MK2W4CH/A", "Duo · 2TB · 夜空色"),
    )

    /** 25 城 49 家直营店（常用 3 城前置）。 */
    val CITY_STORES: List<Pair<String, List<StoreOpt>>> = listOf(
        "广州" to listOf(
            StoreOpt("R639", "珠江新城（天汇广场）", "广州"),
            StoreOpt("R577", "天环广场", "广州"),
        ),
        "上海" to listOf(
            StoreOpt("R683", "环球港", "上海"),
            StoreOpt("R390", "香港广场", "上海"),
            StoreOpt("R581", "五角场", "上海"),
            StoreOpt("R401", "上海环贸 iapm", "上海"),
            StoreOpt("R389", "浦东", "上海"),
            StoreOpt("R678", "静安", "上海"),
            StoreOpt("R359", "南京东路", "上海"),
            StoreOpt("R705", "七宝", "上海"),
        ),
        "北京" to listOf(
            StoreOpt("R388", "西单大悦城", "北京"),
            StoreOpt("R792", "北京荟聚", "北京"),
            StoreOpt("R645", "朝阳大悦城", "北京"),
            StoreOpt("R448", "王府井", "北京"),
            StoreOpt("R479", "华贸购物中心", "北京"),
            StoreOpt("R320", "三里屯", "北京"),
        ),
        "深圳" to listOf(
            StoreOpt("R761", "深圳万象城", "深圳"),
            StoreOpt("R484", "深圳益田假日广场", "深圳"),
            StoreOpt("R793", "前海壹方城", "深圳"),
        ),
        "成都" to listOf(
            StoreOpt("R502", "成都万象城", "成都"),
            StoreOpt("R580", "成都太古里", "成都"),
        ),
        "天津" to listOf(
            StoreOpt("R637", "天津大悦城", "天津"),
            StoreOpt("R638", "天津万象城", "天津"),
            StoreOpt("R579", "天津恒隆广场", "天津"),
        ),
        "南京" to listOf(
            StoreOpt("R643", "虹悦城", "南京"),
            StoreOpt("R493", "新街口", "南京"),
            StoreOpt("R703", "玄武湖", "南京"),
        ),
        "重庆" to listOf(
            StoreOpt("R480", "解放碑", "重庆"),
            StoreOpt("R573", "重庆万象城", "重庆"),
            StoreOpt("R476", "重庆北城天街", "重庆"),
        ),
        "沈阳" to listOf(
            StoreOpt("R576", "沈阳万象城", "沈阳"),
            StoreOpt("R534", "中街大悦城", "沈阳"),
        ),
        "杭州" to listOf(
            StoreOpt("R471", "西湖", "杭州"),
            StoreOpt("R532", "杭州万象城", "杭州"),
        ),
        "合肥" to listOf(StoreOpt("R765", "合肥万象城", "合肥")),
        "济南" to listOf(StoreOpt("R648", "济南恒隆广场", "济南")),
        "青岛" to listOf(StoreOpt("R557", "青岛万象城", "青岛")),
        "南宁" to listOf(StoreOpt("R571", "南宁万象城", "南宁")),
        "无锡" to listOf(StoreOpt("R574", "无锡恒隆广场", "无锡")),
        "苏州" to listOf(StoreOpt("R688", "苏州中心", "苏州")),
        "郑州" to listOf(StoreOpt("R572", "郑州万象城", "郑州")),
        "宁波" to listOf(StoreOpt("R531", "天一广场", "宁波")),
        "温州" to listOf(StoreOpt("R766", "温州万象城", "温州")),
        "武汉" to listOf(StoreOpt("R575", "武商 MALL 武汉", "武汉")),
        "长沙" to listOf(StoreOpt("R617", "长沙 IFS", "长沙")),
        "厦门" to listOf(StoreOpt("R644", "厦门新生活广场", "厦门")),
        "福州" to listOf(StoreOpt("R646", "泰禾广场", "福州")),
        "大连" to listOf(StoreOpt("R609", "大连恒隆广场", "大连")),
        "昆明" to listOf(StoreOpt("R670", "昆明顺城", "昆明")),
    )

    val STORES: List<StoreOpt> = CITY_STORES.flatMap { it.second }

    private val STORE_MAP: Map<String, StoreOpt> = STORES.associateBy { it.code }

    fun storeOf(code: String): StoreOpt? = STORE_MAP[code]

    fun storeLabel(code: String): String =
        STORE_MAP[code]?.name ?: code

    fun cityOf(code: String): String =
        STORE_MAP[code]?.city ?: "广州"

    /** 查询接口 location 参数：需"省 市"格式。 */
    fun locationOf(city: String): String = when (city) {
        // 实测：苹果接口把深圳门店挂在"广东 广州"下，用"广东 深圳"返回0店
        "广州", "深圳" -> "广东 广州"
        "成都" -> "四川 成都"
        "南京", "无锡", "苏州" -> "江苏 $city"
        "杭州", "宁波", "温州" -> "浙江 $city"
        "济南", "青岛" -> "山东 $city"
        "合肥" -> "安徽 合肥"
        "南宁" -> "广西 南宁"
        "郑州" -> "河南 郑州"
        "武汉" -> "湖北 武汉"
        "长沙" -> "湖南 长沙"
        "厦门", "福州" -> "福建 $city"
        "沈阳", "大连" -> "辽宁 $city"
        "昆明" -> "云南 昆明"
        "重庆" -> "重庆 重庆"
        "天津" -> "天津 天津"
        "上海" -> "上海 上海"
        "北京" -> "北京 北京"
        else -> "广东 广州"
    }

    fun locationForStore(code: String): String = locationOf(cityOf(code))

    val INTERVALS: List<IntervalOpt> = listOf(
        IntervalOpt(10, "10 秒"),
        IntervalOpt(15, "15 秒"),
        IntervalOpt(30, "30 秒"),
        IntervalOpt(60, "1 分钟"),
        IntervalOpt(120, "2 分钟"),
        IntervalOpt(300, "5 分钟"),
    )

    fun modelLabel(part: String): String =
        MODELS.firstOrNull { it.part == part }?.label ?: part
}
