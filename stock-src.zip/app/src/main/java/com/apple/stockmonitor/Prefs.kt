package com.apple.stockmonitor

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** 配置、多目标、去重与自适应状态存取（SharedPreferences）。 */
object Prefs {
    private const val NAME = "stock_monitor_prefs"

    const val DEFAULT_PART = "MJYC4CH/A"
    const val DEFAULT_STORE = "R639"
    // SendKey 默认留空，用户在设置页自行申请填写
    const val DEFAULT_SENDKEY = ""
    const val DEFAULT_INTERVAL = 60

    /** 监控记录条数上限（型号 × 门店 的组合数），不是门店数。 */
    const val MAX_TARGETS = 5

    /** WiFi 下的检查间隔（秒）：默认最高频档。 */
    const val DEFAULT_WIFI_INTERVAL = 10

    /** 移动数据下的检查间隔（秒）：默认 30 秒，避免流量跑太快。 */
    const val DEFAULT_CELL_INTERVAL = 30

    private const val K_TARGETS = "targets_json"
    private const val K_SENDKEY = "sendkey"
    private const val K_INTERVAL = "interval"
    private const val K_WIFI_INTERVAL = "wifi_interval"
    private const val K_CELL_INTERVAL = "cell_interval"
    private const val K_NOTIFIED = "notified_set"
    private const val K_LAST_RESULT = "last_result_map"
    private const val K_LAST_TIME_MAP = "last_check_time_map"
    private const val K_STREAK = "streak"
    private const val K_LAST_TIME = "last_check_time"
    private const val K_NEXT_TIME = "next_check_time"
    private const val K_ROUND_COUNT = "round_count"
    private const val K_LOG = "log_json"
    private const val K_EVENT_LOG = "event_log_json"
    private const val K_NOTIFY_LOCAL = "notify_local"
    private const val K_NOTIFY_SOUND = "notify_sound"
    private const val K_NOTIFY_VIBRATE = "notify_vibrate"
    private const val K_ADAPTIVE = "adaptive"
    private const val K_FACTOR = "factor"
    private const val K_RUNNING = "running"
    private const val K_AGREED = "privacy_agreed"
    private const val K_UPDATE_INFO = "update_info_json"
    private const val K_UPDATE_DISMISS_AT = "update_dismiss_at"
    private const val K_UPDATE_CHECKED_AT = "update_checked_at"

    data class Target(val part: String, val store: String) {
        fun key(): String = "$part|$store"
        fun label(): String = "${Catalog.modelLabel(part)} · ${Catalog.storeLabel(store)}"
        fun shortLabel(): String =
            "${Catalog.modelLabel(part).removePrefix("Pro Max · ")} · ${Catalog.storeLabel(store)}"
    }

    fun cfg(ctx: Context): Pair<List<Target>, Int> = Pair(targets(ctx), interval(ctx))

    // ---- 多目标 ----
    fun targets(ctx: Context): List<Target> {
        val raw = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .getString(K_TARGETS, "") ?: ""
        if (raw.isBlank()) return listOf(Target(DEFAULT_PART, DEFAULT_STORE))
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Target(o.optString("part", DEFAULT_PART), o.optString("store", DEFAULT_STORE))
            }.ifEmpty { listOf(Target(DEFAULT_PART, DEFAULT_STORE)) }
        } catch (e: Exception) {
            listOf(Target(DEFAULT_PART, DEFAULT_STORE))
        }
    }

    fun saveTargets(ctx: Context, list: List<Target>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("part", it.part).put("store", it.store)) }
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit()
            .putString(K_TARGETS, arr.toString()).apply()
    }

    // ---- 单值 ----
    fun sendkey(ctx: Context): String =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getString(K_SENDKEY, DEFAULT_SENDKEY)!!

    fun saveSendkey(ctx: Context, v: String) {
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit()
            .putString(K_SENDKEY, v.trim()).apply()
    }

    fun interval(ctx: Context): Int =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getInt(K_INTERVAL, DEFAULT_INTERVAL)

    fun saveInterval(ctx: Context, v: Int) {
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit()
            .putInt(K_INTERVAL, v.coerceIn(10, 3600)).apply()
    }

    /**
     * WiFi 下的检查间隔（秒）。默认最高频档 10 秒。
     * 兼容旧数据：早期只有一个 interval 字段，这里读不到就沿用它。
     */
    fun wifiInterval(ctx: Context): Int {
        val sp = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
        if (sp.contains(K_WIFI_INTERVAL)) return sp.getInt(K_WIFI_INTERVAL, DEFAULT_WIFI_INTERVAL)
        return sp.getInt(K_INTERVAL, DEFAULT_WIFI_INTERVAL)
    }

    fun saveWifiInterval(ctx: Context, v: Int) {
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit()
            .putInt(K_WIFI_INTERVAL, v.coerceIn(10, 3600)).apply()
    }

    /** 移动数据下的检查间隔（秒）。默认 30 秒，避免流量跑太快。 */
    fun cellInterval(ctx: Context): Int =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getInt(K_CELL_INTERVAL, DEFAULT_CELL_INTERVAL)

    fun saveCellInterval(ctx: Context, v: Int) {
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit()
            .putInt(K_CELL_INTERVAL, v.coerceIn(10, 3600)).apply()
    }

    /** 按当前网络类型取生效间隔：WiFi 用高频档，移动数据用省流量档。 */
    fun effectiveInterval(ctx: Context): Int =
        if (NetProbe.isMetered(ctx)) cellInterval(ctx) else wifiInterval(ctx)

    /**
     * 升级迁移：监控记录超过 [MAX_TARGETS] 条时只保留前 N 条。
     * @return 被裁掉的条数（0 表示无需处理）。
     */
    fun migrateTargets(ctx: Context): Int {
        val list = targets(ctx)
        if (list.size <= MAX_TARGETS) return 0
        saveTargets(ctx, list.take(MAX_TARGETS))
        return list.size - MAX_TARGETS
    }

    // ---- 通知去重（按 target key） ----
    private fun strSet(ctx: Context, key: String): Set<String> {
        val raw = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getString(key, "") ?: ""
        return raw.split(",").filter { it.isNotBlank() }.toSet()
    }

    private fun saveStrSet(ctx: Context, key: String, s: Set<String>) {
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit()
            .putString(key, s.joinToString(",")).apply()
    }

    fun notified(ctx: Context): Set<String> = strSet(ctx, K_NOTIFIED)

    fun setNotified(ctx: Context, targetKey: String) {
        saveStrSet(ctx, K_NOTIFIED, notified(ctx) + targetKey)
    }

    fun resetNotified(ctx: Context, targetKey: String) {
        saveStrSet(ctx, K_NOTIFIED, notified(ctx) - targetKey)
    }

    /**
     * 重启监控时重置通知标记。
     *
     * 只重置「已经变成无货」的目标：这些目标下次有货时应该重新弹横幅。
     * 仍然有货的目标保持已通知状态，避免每次重启都把同一批有货目标
     * 重新弹一遍（原来是无差别清空，用户重启一次就被横幅刷屏）。
     */
    fun clearNotifiedForNoLongerAvailable(ctx: Context, availableKeys: Set<String>) {
        val stale = notified(ctx) - availableKeys
        if (stale.isEmpty()) return
        saveStrSet(ctx, K_NOTIFIED, stale)
    }

    // ---- 每目标上次通知时间（用于有货重复提醒间隔） ----
    private const val K_LAST_NOTIFY = "last_notify_map"
    fun lastNotifyTime(ctx: Context, key: String): Long {
        val raw = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getString(K_LAST_NOTIFY, "") ?: ""
        return try { JSONObject(raw).optLong(key, 0L) } catch (e: Exception) { 0L }
    }
    fun setLastNotifyTime(ctx: Context, key: String, ts: Long) {
        val raw = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getString(K_LAST_NOTIFY, "") ?: ""
        val json = try { JSONObject(raw) } catch (e: Exception) { JSONObject() }
        json.put(key, ts)
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit().putString(K_LAST_NOTIFY, json.toString()).apply()
    }

    // ---- 每目标距上次弹横幅经过的有货轮数（每2轮重复弹一次） ----
    private const val K_NOTIFY_ROUND = "notify_round_map"
    fun notifyRound(ctx: Context, key: String): Int {
        val raw = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getString(K_NOTIFY_ROUND, "") ?: ""
        return try { JSONObject(raw).optInt(key, 0) } catch (e: Exception) { 0 }
    }
    fun setNotifyRound(ctx: Context, key: String, n: Int) {
        val raw = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getString(K_NOTIFY_ROUND, "") ?: ""
        val json = try { JSONObject(raw) } catch (e: Exception) { JSONObject() }
        json.put(key, n)
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit().putString(K_NOTIFY_ROUND, json.toString()).apply()
    }

    // ---- 每目标上次结果：available / unavailable / fail ----
    fun lastResult(ctx: Context, key: String): String? {
        val raw = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getString(K_LAST_RESULT, "") ?: ""
        return try {
            JSONObject(raw).optString(key, "")
        } catch (e: Exception) { "" }
    }

    fun setLastResult(ctx: Context, key: String, v: String) {
        val raw = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getString(K_LAST_RESULT, "") ?: ""
        val o = try { JSONObject(raw) } catch (e: Exception) { JSONObject() }
        o.put(key, v)
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit()
            .putString(K_LAST_RESULT, o.toString()).apply()
    }

    // ---- 连续无货次数 ----
    var streak: Int
        get() = sp().getInt(K_STREAK, 0)
        set(v) = sp().edit().putInt(K_STREAK, v).apply()

    var lastCheckTime: String
        get() = sp().getString(K_LAST_TIME, "") ?: ""
        set(v) = sp().edit().putString(K_LAST_TIME, v).apply()

    /**
     * 每个监控目标各自的最后一次检查时间。
     *
     * 原来只有一个全局值，监控列表里所有目标显示同一时间，看不出谁刚查过。
     */
    fun lastCheckTimeOf(ctx: Context, key: String): String {
        val raw = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .getString(K_LAST_TIME_MAP, "") ?: ""
        return try { JSONObject(raw).optString(key, "") } catch (e: Exception) { "" }
    }

    fun setLastCheckTimeOf(ctx: Context, key: String, v: String) {
        val raw = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .getString(K_LAST_TIME_MAP, "") ?: ""
        val o = try { JSONObject(raw) } catch (e: Exception) { JSONObject() }
        o.put(key, v)
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit()
            .putString(K_LAST_TIME_MAP, o.toString()).apply()
    }

    /** 迁移旧的全局检查时间：老版本只有一个值，升级后清掉即可（没有 per-target 数据可迁移）。 */
    fun migrateLastCheckTime(ctx: Context) {
        val sp = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
        if (sp.contains(K_LAST_TIME)) {
            sp.edit().remove(K_LAST_TIME).apply()
        }
    }

    var nextCheckTime: String
        get() = sp().getString(K_NEXT_TIME, "") ?: ""
        set(v) = sp().edit().putString(K_NEXT_TIME, v).apply()

    // ---- 本轮监控累计轮次（判断 Service 是否还活着） ----
    var roundCount: Int
        get() = sp().getInt(K_ROUND_COUNT, 0)
        set(v) = sp().edit().putInt(K_ROUND_COUNT, v).apply()

    // ---- 记录时间线（摘要与事件分两个池） ----
    data class LogItem(val t: String, val m: String, val ok: Boolean)

    private fun readLogItems(raw: String): List<LogItem> {
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                LogItem(o.optString("t"), o.optString("m"), o.optBoolean("ok"))
            }
        } catch (e: Exception) { emptyList() }
    }

    private fun writeLogItems(ctx: Context, key: String, items: List<LogItem>) {
        val arr = JSONArray()
        items.forEach { arr.put(JSONObject().put("t", it.t).put("m", it.m).put("ok", it.ok)) }
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit()
            .putString(key, arr.toString()).apply()
    }

    /**
     * 全部记录（事件优先，摘要垫后）。
     *
     * 分两个池的原因：原来事件和「第 N 轮：0 有货」摘要混在一起，
     * 30 条上限很快把「某店有货」这种真事件冲掉。
     */
    fun log(ctx: Context): List<LogItem> {
        val events = readLogItems(
            ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getString(K_EVENT_LOG, "") ?: ""
        )
        val summaries = readLogItems(
            ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getString(K_LOG, "") ?: ""
        )
        return events + summaries
    }

    /** 写一条轮次摘要（低优先级，会被事件挤下去）。 */
    fun addLog(ctx: Context, m: String, ok: Boolean) {
        val sp = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
        val items = readLogItems(sp.getString(K_LOG, "") ?: "").takeLast(29).toMutableList()
        items.add(LogItem(nowHms(), m, ok))
        writeLogItems(ctx, K_LOG, items)
    }

    /** 写一条真实事件（有货、失败等），优先级最高。 */
    fun addEvent(ctx: Context, m: String, ok: Boolean) {
        val sp = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)
        val items = readLogItems(sp.getString(K_EVENT_LOG, "") ?: "").takeLast(49).toMutableList()
        items.add(LogItem(nowHms(), m, ok))
        writeLogItems(ctx, K_EVENT_LOG, items)
    }

    fun clearLog(ctx: Context) {
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit()
            .remove(K_LOG).remove(K_EVENT_LOG).apply()
    }

    // ---- 提醒与自适应开关 ----
    fun notifyLocal(ctx: Context): Boolean =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getBoolean(K_NOTIFY_LOCAL, true)

    fun saveNotifyLocal(ctx: Context, v: Boolean) {
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit().putBoolean(K_NOTIFY_LOCAL, v).apply()
    }

    fun notifySound(ctx: Context): Boolean =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getBoolean(K_NOTIFY_SOUND, false)

    fun saveNotifySound(ctx: Context, v: Boolean) {
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit().putBoolean(K_NOTIFY_SOUND, v).apply()
    }

    fun notifyVibrate(ctx: Context): Boolean =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getBoolean(K_NOTIFY_VIBRATE, true)

    fun saveNotifyVibrate(ctx: Context, v: Boolean) {
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit().putBoolean(K_NOTIFY_VIBRATE, v).apply()
    }

    fun adaptive(ctx: Context): Boolean =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getBoolean(K_ADAPTIVE, true)

    fun saveAdaptive(ctx: Context, v: Boolean) {
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit().putBoolean(K_ADAPTIVE, v).apply()
    }

    /** 限流自适应因子：失败连击拉高、成功连击回落；持久化防重启丢失。 */
    fun factor(ctx: Context): Float =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getFloat(K_FACTOR, 1f)

    fun saveFactor(ctx: Context, v: Float) {
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit().putFloat(K_FACTOR, v).apply()
    }

    // ---- 服务运行标记 ----
    var running: Boolean
        get() = sp().getBoolean(K_RUNNING, false)
        set(v) = sp().edit().putBoolean(K_RUNNING, v).apply()

    // ---- 隐私政策同意标记 ----
    fun privacyAgreed(ctx: Context): Boolean =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getBoolean(K_AGREED, false)

    fun setPrivacyAgreed(ctx: Context) {
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit().putBoolean(K_AGREED, true).apply()
    }

    // ---- 版本更新状态 ----

    /** 已发现的新版本信息（JSON 字符串），没有则为空。 */
    fun pendingUpdate(ctx: Context): String =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getString(K_UPDATE_INFO, "") ?: ""

    fun savePendingUpdate(ctx: Context, json: String) {
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit()
            .putString(K_UPDATE_INFO, json).apply()
    }

    /** 用户点「稍后再说」的时间戳；用来控制多久之后才再提醒。 */
    var updateDismissAt: Long
        get() = sp().getLong(K_UPDATE_DISMISS_AT, 0L)
        set(v) = sp().edit().putLong(K_UPDATE_DISMISS_AT, v).apply()

    /** 上次检查更新的时间戳。 */
    var updateCheckedAt: Long
        get() = sp().getLong(K_UPDATE_CHECKED_AT, 0L)
        set(v) = sp().edit().putLong(K_UPDATE_CHECKED_AT, v).apply()

    private fun sp() = AppContext.get().getSharedPreferences(NAME, Context.MODE_PRIVATE)

    private fun nowHms(): String =
        java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.CHINA).format(java.util.Date())
}
