package com.apple.stockmonitor

import android.content.Context

/**
 * 请求预算（令牌桶）与 HTTP 541 熔断。
 *
 * 实测依据：苹果官网风控按「滑动窗口内累计请求数」触发，不是单纯的 QPS 阈值。
 * 傍晚累计到第 38 次开始返回 541，深夜累计到第 43 次返回 541，
 * 与这些请求摊在 60 秒还是 200 秒内无关；冷却期超过 10 分钟。
 *
 * 因此本类把预算压到触发点的一半：
 * - 60 秒窗口内最多 [LIMIT] 次请求
 * - 两次请求之间最小间隔 [MIN_GAP_MS]，防止瞬时突发
 *
 * 状态持久化在 SharedPreferences：App 被系统杀死重启后计数不会清零，
 * 避免「重启即绕过预算」继续撞风控。
 */
object RequestBudget {

    /** 预算窗口（毫秒）。 */
    private const val WINDOW_MS = 60_000L

    /** 窗口内最大请求数。实测触发点约 40 次，取一半留足余量。 */
    const val LIMIT = 10

    /** 两次请求之间的最小间隔。 */
    private const val MIN_GAP_MS = 6_000L

    /** 同一轮内相邻分组请求的间隔。 */
    const val GROUP_GAP_MS = 800L

    /** 熔断时长：首次 10 分钟，每次继续失败翻倍，封顶 60 分钟。 */
    private const val CIRCUIT_FIRST_MS = 10 * 60_000L
    private const val CIRCUIT_MAX_MS = 60 * 60_000L

    private const val SP_NAME = "stock_monitor_prefs"
    private const val K_TS = "budget_recent_ts"
    private const val K_CIRCUIT_UNTIL = "budget_circuit_until"
    private const val K_CIRCUIT_LEVEL = "budget_circuit_level"

    /**
     * 为 [n] 次请求申请额度。
     *
     * @return 0 表示额度已预留、可以发请求；>0 表示需要等待的毫秒数
     *         （等到最早的那次请求滑出窗口即可）。
     */
    @Synchronized
    fun reserve(ctx: Context, n: Int): Long {
        if (n <= 0) return 0L
        val now = System.currentTimeMillis()
        val sp = ctx.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE)
        val recent = readTs(sp.getString(K_TS, "") ?: "")
            .filter { now - it < WINDOW_MS }
            .sorted()
        if (recent.size + n > LIMIT) {
            // 额度不够：等最早的那次滑出窗口
            val earliest = recent.firstOrNull() ?: return 0L
            return (earliest + WINDOW_MS - now).coerceAtLeast(1L)
        }
        // 预留：按最小间隔铺开时间戳，保证同轮内不会瞬时突发
        val reserved = ArrayList<Long>(n)
        var cursor = now
        if (recent.isNotEmpty()) cursor = maxOf(cursor, recent.last() + MIN_GAP_MS)
        for (i in 0 until n) {
            reserved.add(cursor)
            cursor += GROUP_GAP_MS
        }
        saveTs(sp, (recent + reserved).sorted())
        return 0L
    }

    /** 熔断剩余毫秒数；0 表示当前没有熔断。 */
    fun circuitRemaining(ctx: Context): Long {
        val sp = ctx.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE)
        val until = sp.getLong(K_CIRCUIT_UNTIL, 0L)
        val left = until - System.currentTimeMillis()
        return if (left > 0) left else 0L
    }

    /** 记录一次 541：熔断时长按 10 → 20 → 40 → 60 分钟递增。 */
    fun tripCircuit(ctx: Context) {
        val sp = ctx.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE)
        val level = sp.getInt(K_CIRCUIT_LEVEL, 0)
        val dur = minOf(CIRCUIT_FIRST_MS * (1L shl minOf(level, 3)), CIRCUIT_MAX_MS)
        sp.edit()
            .putLong(K_CIRCUIT_UNTIL, System.currentTimeMillis() + dur)
            .putInt(K_CIRCUIT_LEVEL, level + 1)
            .apply()
    }

    /** 请求成功一次：清零熔断等级与截止时间。 */
    fun clearCircuit(ctx: Context) {
        val sp = ctx.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE)
        sp.edit().putInt(K_CIRCUIT_LEVEL, 0).putLong(K_CIRCUIT_UNTIL, 0L).apply()
    }

    /** 当前熔断等级（0 = 未熔断过）。 */
    fun circuitLevel(ctx: Context): Int =
        ctx.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE).getInt(K_CIRCUIT_LEVEL, 0)

    private fun readTs(raw: String): List<Long> =
        raw.split(",").mapNotNull { it.trim().toLongOrNull() }

    private fun saveTs(sp: android.content.SharedPreferences, ts: List<Long>) {
        sp.edit().putString(K_TS, ts.joinToString(",")).apply()
    }
}
