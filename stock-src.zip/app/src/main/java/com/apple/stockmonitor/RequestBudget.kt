package com.apple.stockmonitor

import android.content.Context

/**
 * 请求预算（滑动窗口计数）与 HTTP 541 熔断。
 *
 * 实测依据：苹果官网风控按「滑动窗口内累计请求数」触发，不是单纯的 QPS 阈值。
 * 傍晚累计到第 38 次开始返回 541，深夜累计到第 43 次返回 541，
 * 与这些请求摊在 60 秒还是 200 秒内无关；冷却期超过 10 分钟。
 *
 * 因此本类把预算压到触发点的一半：
 * - 60 秒窗口内最多 [LIMIT] 次请求
 * - 两次「批次」之间的最小间隔 [MIN_GAP_MS]，防止瞬时突发
 *
 * ## 两个独立配额池（v2.3.1 修复「点了查询查不了」）
 *
 * 之前所有请求共用一个池，结果是：
 * App 冷启动 → 自动同步门店目录（16 个片区）→ 把额度抢光 →
 * 用户点「立即查询」被挡 → 界面只弹一句「请求太频繁，5 秒后再试」，
 * 用户既查不了也看不懂为什么。
 *
 * 现在分成两池，互不占用：
 * - [Pool.FOREGROUND]：监控轮次 + 用户手动查询。额度紧张时用户会「点不动」，
 *   所以前台池必须优先保证。
 * - [Pool.BACKGROUND]：门店目录同步等非紧急后台任务。额度更紧、间隔更长，
 *   但**绝不占用前台额度**，后台跑多久都不影响用户查询。
 *
 * ## 记账的三个坑（v2.3.1 修复）
 *
 * 1. **不能把「预留时刻」当「实际发出时刻」记账**。旧实现把预留出来的时间戳
 *    写进窗口，并用 `cursor = recent.last() + MIN_GAP_MS` 往前推游标——
 *    一旦出现未来时间戳，游标会越推越远（now+6s → now+12s → now+18s…），
 *    而过滤条件 `now - it < WINDOW_MS` 对**负数**（未来时刻）同样成立，
 *    于是这些时间戳在真实时间追上之前**永远占着窗口额度**，
 *    连调十几次 reserve 就能把预算永久锁死，用户再也查不了。
 *    现在只记**真实发生时刻**，并且显式排除任何未来时间戳。
 *
 * 2. **一次 reserve 只对应一次真实请求组**。之前门店同步外层预留一次、
 *    内层又预留一次，等于一次请求扣两份额度，请求根本没发出去额度却已经没了。
 *    现在拆成 [peek]（只看不扣）与 [reserve]（真正扣），由调用方自己决定顺序。
 *
 * 3. **批次内部靠网络往返自然拉开间隔**，批次之间由最小间隔强制隔开。
 *
 * 状态持久化在 SharedPreferences：App 被系统杀死重启后计数不会清零，
 * 避免「重启即绕过预算」继续撞风控。
 */
object RequestBudget {

    /** 配额池。 */
    enum class Pool {
        /** 前台：监控轮次 + 用户手动查询。 */
        FOREGROUND,

        /** 后台：门店目录同步等非紧急任务。 */
        BACKGROUND
    }

    /** 预算窗口（毫秒）。 */
    private const val WINDOW_MS = 60_000L

    /** 前台池窗口内最大请求数。实测触发点约 40 次，取一半留足余量。 */
    const val LIMIT = 10

    /** 后台池窗口内最大请求数。后台任务不紧急，额度压得更紧。 */
    const val BG_LIMIT = 3

    /**
     * 移动数据下的前台额度上限（比 WiFi 少一半）。
     *
     * 原因不是流量贵，而是**出口 IP 的性质不同**：
     * - WiFi 是自家独占的公网 IP，苹果风控只统计你自己；
     * - 移动数据走运营商 CGNAT，**同一个出口 IP 后面背着成千上万用户**，
     *   别人访问苹果官网的请求也记在这个 IP 的账上，风控阈值会被别人提前消耗掉。
     *
     * 实测反馈：同一台设备，WiFi 下正常查询，移动数据下频繁弹限流。
     * 所以移动数据不仅要更保守，还要留更大的余量给真正的用户操作。
     */
    private const val METERED_LIMIT = 5

    /** 移动数据下的后台额度上限。 */
    private const val METERED_BG_LIMIT = 2

    /** 前台两批次之间的最小间隔。 */
    private const val MIN_GAP_MS = 6_000L

    /** 移动数据下的前台最小间隔：拉开一点，给共享 IP 留恢复余地。 */
    private const val METERED_MIN_GAP_MS = 10_000L

    /** 后台两批次之间的最小间隔（后台慢一点没关系）。 */
    private const val BG_MIN_GAP_MS = 20_000L

    /** 移动数据下的后台最小间隔。 */
    private const val METERED_BG_MIN_GAP_MS = 30_000L

    /** 熔断时长：首次 10 分钟，每次继续失败翻倍，封顶 60 分钟。 */
    private const val CIRCUIT_FIRST_MS = 10 * 60_000L
    private const val CIRCUIT_MAX_MS = 60 * 60_000L

    private const val SP_NAME = "stock_monitor_prefs"
    private const val K_FG_TS = "budget_fg_ts"
    private const val K_BG_TS = "budget_bg_ts"
    private const val K_FG_NEXT = "budget_fg_next_at"
    private const val K_BG_NEXT = "budget_bg_next_at"
    private const val K_CIRCUIT_UNTIL = "budget_circuit_until"
    private const val K_CIRCUIT_LEVEL = "budget_circuit_level"
    private const val K_BG_CIRCUIT_UNTIL = "budget_bg_circuit_until"

    /**
     * v2.3.0 及更早版本用的单池时间戳键。
     *
     * 旧实现会把「未来的预留时刻」写进这个键，升级后如果不删，
     * 那些坏数据虽然不再被读取，但留着容易在排查时误导人，直接清掉。
     */
    private const val K_LEGACY_TS = "budget_recent_ts"

    /**
     * 升级迁移：清理旧版单池预算残留。
     *
     * 旧版只用一个键 `budget_recent_ts` 记账，且会把未来时间戳写进去。
     * 新版用 `budget_fg_ts` / `budget_bg_ts` 两个独立键，不会读到旧数据，
     * 所以这里只是删掉残留键，保持数据干净。
     */
    fun migrate(ctx: Context) {
        ctx.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE).edit()
            .remove(K_LEGACY_TS)
            .apply()
    }

    /**
     * **只看不扣**：查询申请 [n] 次请求额度要等多久。
     *
     * 与 [reserve] 的区别是不占用额度——用来让调用方「先等一等再申请」，
     * 避免出现「预留成功但请求没发出去，额度却已经没了」的情况。
     *
     * @return 0 表示现在就能发；>0 表示需要等待的毫秒数。
     */
    @Synchronized
    fun peek(ctx: Context, n: Int, pool: Pool = Pool.FOREGROUND): Long {
        if (n <= 0) return 0L
        val now = System.currentTimeMillis()
        val sp = ctx.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE)
        val tsKey = tsKeyOf(pool)
        val limit = limitOf(ctx, pool)

        // 只保留「已经发生、且还在窗口内」的请求。
        // 排除未来时间戳是必须的：一个坏时间戳能把预算永久锁死。
        val recent = readTs(sp.getString(tsKey, "") ?: "")
            .filter { now - it in 0 until WINDOW_MS }
            .sorted()

        // 窗口内额度不够：等最早的那次滑出窗口
        var wait = 0L
        if (recent.size + n > limit) {
            val earliest = recent.firstOrNull() ?: return 0L
            wait = (earliest + WINDOW_MS - now).coerceAtLeast(1L)
        }
        // 最小间隔：离上一批次太近也要等
        val nextAt = sp.getLong(nextKeyOf(pool), 0L)
        if (nextAt > now) {
            wait = maxOf(wait, nextAt - now)
        }
        return wait
    }

    /**
     * 申请 [n] 次请求额度并记账。
     *
     * @param pool 配额池。默认前台池。
     * @return 0 表示额度已预留、可以发请求；>0 表示需要等待的毫秒数。
     */
    @Synchronized
    fun reserve(ctx: Context, n: Int, pool: Pool = Pool.FOREGROUND): Long {
        if (n <= 0) return 0L
        val now = System.currentTimeMillis()
        val sp = ctx.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE)
        val tsKey = tsKeyOf(pool)
        val limit = limitOf(ctx, pool)

        val recent = readTs(sp.getString(tsKey, "") ?: "")
            .filter { now - it in 0 until WINDOW_MS }
            .sorted()

        if (recent.size + n > limit) {
            val earliest = recent.firstOrNull() ?: return 0L
            return (earliest + WINDOW_MS - now).coerceAtLeast(1L)
        }
        val nextAt = sp.getLong(nextKeyOf(pool), 0L)
        if (nextAt > now) return nextAt - now

        // 通过：按**真实发生时刻**记账（不是预留时刻）
        val add = List(n) { now }
        saveTs(sp, tsKey, (recent + add).sorted())
        sp.edit().putLong(nextKeyOf(pool), now + gapOf(ctx, pool)).apply()
        return 0L
    }

    /** 熔断剩余毫秒数；0 表示当前没有熔断。 */
    fun circuitRemaining(ctx: Context): Long {
        val sp = ctx.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE)
        val until = sp.getLong(K_CIRCUIT_UNTIL, 0L)
        val left = until - System.currentTimeMillis()
        return if (left > 0) left else 0L
    }

    /** 记录一次 541：熔断时长按 10 → 20 → 40 → 60 分钟递增。 */
    fun tripCircuit(ctx: Context) {
        val sp = ctx.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE)
        val level = sp.getInt(K_CIRCUIT_LEVEL, 0)
        val dur = minOf(CIRCUIT_FIRST_MS * (1L shl minOf(level, 3)), CIRCUIT_MAX_MS)
        sp.edit()
            .putLong(K_CIRCUIT_UNTIL, System.currentTimeMillis() + dur)
            .putInt(K_CIRCUIT_LEVEL, level + 1)
            .apply()
    }

    /** 请求成功一次：清零熔断等级与截止时间。 */
    fun clearCircuit(ctx: Context) {
        val sp = ctx.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE)
        sp.edit().putInt(K_CIRCUIT_LEVEL, 0).putLong(K_CIRCUIT_UNTIL, 0L).apply()
    }

    /** 当前熔断等级（0 = 未熔断过）。 */
    fun circuitLevel(ctx: Context): Int =
        ctx.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE).getInt(K_CIRCUIT_LEVEL, 0)

    /**
     * 后台熔断剩余毫秒数；0 表示后台同步未被限流。
     *
     * **后台熔断与前台熔断分开记**（v2.3.1）：
     * 门店目录同步是最容易被风控的活儿（一次要连打十几个片区），
     * 如果它一撞 541 就触发全局熔断，用户会莫名其妙地查不了库存——
     * 而后台同步只是"门店名列表拿不到"，内置表还能兜底。
     * 所以后台只暂停自己，不牵连前台。
     */
    fun backgroundCircuitRemaining(ctx: Context): Long {
        val sp = ctx.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE)
        val until = sp.getLong(K_BG_CIRCUIT_UNTIL, 0L)
        val left = until - System.currentTimeMillis()
        return if (left > 0) left else 0L
    }

    /** 后台同步撞 541：只暂停后台同步，不影响用户的前台查询。 */
    fun tripBackgroundCircuit(ctx: Context) {
        ctx.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE).edit()
            .putLong(K_BG_CIRCUIT_UNTIL, System.currentTimeMillis() + CIRCUIT_FIRST_MS)
            .apply()
    }

    private fun tsKeyOf(pool: Pool): String =
        if (pool == Pool.FOREGROUND) K_FG_TS else K_BG_TS

    private fun nextKeyOf(pool: Pool): String =
        if (pool == Pool.FOREGROUND) K_FG_NEXT else K_BG_NEXT

    private fun limitOf(ctx: Context, pool: Pool): Int {
        val metered = NetProbe.isMetered(ctx)
        return when {
            pool == Pool.FOREGROUND -> if (metered) METERED_LIMIT else LIMIT
            else -> if (metered) METERED_BG_LIMIT else BG_LIMIT
        }
    }

    private fun gapOf(ctx: Context, pool: Pool): Long {
        val metered = NetProbe.isMetered(ctx)
        return when {
            pool == Pool.FOREGROUND -> if (metered) METERED_MIN_GAP_MS else MIN_GAP_MS
            else -> if (metered) METERED_BG_MIN_GAP_MS else BG_MIN_GAP_MS
        }
    }

    private fun readTs(raw: String): List<Long> =
        raw.split(",").mapNotNull { it.trim().toLongOrNull() }

    private fun saveTs(sp: android.content.SharedPreferences, key: String, ts: List<Long>) {
        sp.edit().putString(key, ts.joinToString(",")).apply()
    }
}
