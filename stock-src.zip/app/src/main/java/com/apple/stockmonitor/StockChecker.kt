package com.apple.stockmonitor

import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** 库存查询与 Server酱 微信推送（全部在后台线程调用）。 */
object StockChecker {

    private const val API = "https://www.apple.com.cn/shop/sba/availability-message"
    private const val SCT = "https://sctapi.ftqq.com/%s.send"
    const val PRODUCT_PAGE_URL =
        "https://www.apple.com.cn/shop/buy-iphone/iphone-18-pro/mjyc4ch/a"
    private const val UA =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) " +
        "Chrome/124.0.0.0 Mobile Safari/537.36"

    data class Result(
        val anyStore: Boolean,
        val storeCount: Int,
        val raw: String,
    )

    /** 查询全国自提信号。失败抛异常，由调用方捕获重试。 */
    fun check(part: String): Result {
        val url = API + "?parts.0=" + URLEncoder.encode(part, "UTF-8") + "&cppart=CH"
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15000
            readTimeout = 15000
            setRequestProperty("User-Agent", UA)
            setRequestProperty("Accept", "application/json, text/plain, */*")
            setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9")
            setRequestProperty("Referer", PRODUCT_PAGE_URL)
        }
        try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = BufferedReader(InputStreamReader(stream, "UTF-8")).use { it.readText() }
            if (code !in 200..299) throw RuntimeException("HTTP $code")
            val json = JSONObject(text)
            val content = json.optJSONObject("body")?.optJSONArray("content")
            val item = if (content != null && content.length() > 0) content.getJSONObject(0) else JSONObject()
            val any = item.optBoolean("availableAtAnyStore", false)
            val count = item.optInt("partAvailableStoresCount", 0)
            return Result(any, count, text)
        } finally {
            conn.disconnect()
        }
    }

    /** Server酱 推送微信。失败抛异常。 */
    fun pushWechat(sendkey: String, title: String, desp: String) {
        if (sendkey.isBlank()) return
        val url = String.format(SCT, sendkey)
        val body = ("title=" + URLEncoder.encode(title, "UTF-8") +
                "&desp=" + URLEncoder.encode(desp, "UTF-8")).toByteArray(Charsets.UTF_8)
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 15000
            doOutput = true
            setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            setRequestProperty("User-Agent", UA)
        }
        try {
            conn.outputStream.use { it.write(body) }
            val code = conn.responseCode
            val text = BufferedReader(InputStreamReader(conn.inputStream, "UTF-8")).use { it.readText() }
            val json = JSONObject(text)
            if (json.optInt("code", -1) != 0) throw RuntimeException("Server酱: $text")
        } finally {
            conn.disconnect()
        }
    }
}
