package com.apple.stockmonitor

import android.app.AlertDialog
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.widget.Toast
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/**
 * 内置版本更新模块：
 * - 启动时请求远程版本JSON，对比versionCode
 * - 有新版本弹窗显示更新日志
 * - 点击更新后台下载APK，完成后自动安装
 */
object UpdateChecker {

    // 版本信息JSON地址（jsDelivr 国内CDN，加速GitHub仓库文件）
    private const val VERSION_URL = "https://cdn.jsdelivr.net/gh/woooo00/stock-update@main/version.json"

    data class UpdateInfo(
        val versionCode: Int,
        val versionName: String,
        val changelog: String,
        val apkUrl: String
    )

    fun check(context: Context) {
        Thread {
            try {
                val conn = URL(VERSION_URL).openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                conn.requestMethod = "GET"
                conn.instanceFollowRedirects = true

                val code = conn.responseCode
                if (code != 200) return@Thread

                val reader = BufferedReader(InputStreamReader(conn.inputStream, "UTF-8"))
                val text = reader.readText()
                reader.close()

                // 从飞书文档页面里提取JSON（飞书文档不是纯API，需要找JSON片段）
                // 如果直接是纯JSON就解析，否则尝试匹配
                val jsonStr = extractJson(text) ?: return@Thread
                val json = JSONObject(jsonStr)

                val remoteCode = json.optInt("versionCode", 0)
                val localCode = try {
                    context.packageManager.getPackageInfo(context.packageName, 0).longVersionCode.toInt()
                } catch (e: Exception) { 0 }
                if (remoteCode <= localCode) return@Thread

                val info = UpdateInfo(
                    versionCode = remoteCode,
                    versionName = json.optString("versionName", remoteCode.toString()),
                    changelog = json.optString("changelog", "有新版本可用"),
                    apkUrl = json.optString("apkUrl", "")
                )

                (context as? android.app.Activity)?.runOnUiThread {
                    showUpdateDialog(context, info)
                }
            } catch (e: Exception) {
                // 静默失败，不影响正常使用
            }
        }.start()
    }

    private fun extractJson(text: String): String? {
        // 尝试直接解析
        try { JSONObject(text.trim()); return text.trim() } catch (_: Exception) {}
        // 尝试从页面里找 {"versionCode":...}
        val start = text.indexOf("{\"versionCode\"")
        if (start < 0) return null
        var depth = 0
        for (i in start until text.length) {
            when (text[i]) {
                '{' -> depth++
                '}' -> { depth--; if (depth == 0) return text.substring(start, i + 1) }
            }
        }
        return null
    }

    private fun showUpdateDialog(context: Context, info: UpdateInfo) {
        AlertDialog.Builder(context)
            .setTitle("发现新版本 v${info.versionName}")
            .setMessage(info.changelog + "\n\n此版本为强制更新，请更新后继续使用。")
            .setCancelable(false)
            .setPositiveButton("立即更新") { _, _ ->
                downloadWithProgress(context, info.apkUrl)
            }
            .setOnCancelListener {
                // 用户试图取消（点返回键），直接退出App
                (context as? android.app.Activity)?.finish()
            }
            .show()
    }

    /** 带进度条的下载：弹窗实时显示进度，下载完成自动安装。 */
    private fun downloadWithProgress(context: Context, url: String) {
        if (url.isBlank()) {
            Toast.makeText(context, "下载地址未配置", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val request = DownloadManager.Request(Uri.parse(url))
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            request.setTitle("库存提醒助手 更新下载中")
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "stock_monitor_update.apk")
            request.setMimeType("application/vnd.android.package-archive")

            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val downloadId = dm.enqueue(request)

            // 进度条弹窗
            val progressDialog = android.app.ProgressDialog(context).apply {
                setTitle("正在下载更新")
                setMessage("下载中... 0%")
                setProgressStyle(android.app.ProgressDialog.STYLE_HORIZONTAL)
                setMax(100)
                setCancelable(false)
                setButton(android.content.DialogInterface.BUTTON_NEGATIVE, "退出") { _, _ ->
                    dm.remove(downloadId)
                    (context as? android.app.Activity)?.finish()
                }
                show()
            }

            // 定时查询下载进度
            val handler = android.os.Handler(android.os.Looper.getMainLooper())
            val progressRunnable = object : Runnable {
                override fun run() {
                    val query = DownloadManager.Query().setFilterById(downloadId)
                    dm.query(query).use { cursor ->
                        if (cursor.moveToFirst()) {
                            val status = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                            if (status == DownloadManager.STATUS_SUCCESSFUL) {
                                progressDialog.dismiss()
                                installApk(context, downloadId)
                                return@use
                            }
                            val bytesDownloaded = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                            val bytesTotal = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                            if (bytesTotal > 0) {
                                val progress = (bytesDownloaded * 100 / bytesTotal).toInt()
                                progressDialog.progress = progress
                                progressDialog.setMessage("下载中... $progress%")
                            }
                        }
                    }
                    handler.postDelayed(this, 500)
                }
            }
            handler.post(progressRunnable)

            // 注册下载完成广播（备用，进度条轮询为主）
            context.registerReceiver(object : BroadcastReceiver() {
                override fun onReceive(ctx: Context?, intent: Intent?) {
                    val id = intent?.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1) ?: -1
                    if (id == downloadId) {
                        progressDialog.dismiss()
                        installApk(ctx ?: return, downloadId)
                        try { ctx?.unregisterReceiver(this) } catch (_: Exception) {}
                    }
                }
            }, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE))

        } catch (e: Exception) {
            Toast.makeText(context, "下载失败：${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun downloadApk(context: Context, url: String) {
        if (url.isBlank()) {
            Toast.makeText(context, "下载地址未配置", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val request = DownloadManager.Request(Uri.parse(url))
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            request.setTitle("库存提醒助手 更新下载中")
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "stock_monitor_update.apk")
            request.setMimeType("application/vnd.android.package-archive")

            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val downloadId = dm.enqueue(request)

            // 注册下载完成广播
            context.registerReceiver(object : BroadcastReceiver() {
                override fun onReceive(ctx: Context?, intent: Intent?) {
                    val id = intent?.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1) ?: -1
                    if (id == downloadId) {
                        installApk(ctx ?: return, downloadId)
                        try { ctx.unregisterReceiver(this) } catch (_: Exception) {}
                    }
                }
            }, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE))

            Toast.makeText(context, "开始下载更新，请通知栏查看", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(context, "下载失败：${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun installApk(context: Context, downloadId: Long) {
        try {
            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                dm.getUriForDownloadedFile(downloadId)
            } else {
                Uri.parse("file://${Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)}/stock_monitor_update.apk")
            } ?: return

            val intent = Intent(Intent.ACTION_VIEW)
            intent.setDataAndType(uri, "application/vnd.android.package-archive")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "请手动到下载目录安装APK", Toast.LENGTH_LONG).show()
        }
    }
}
