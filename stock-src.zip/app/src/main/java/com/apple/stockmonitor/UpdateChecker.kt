package com.apple.stockmonitor

import android.app.AlertDialog
import android.app.DownloadManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.widget.Toast
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/**
 * 内置版本更新模块：
 * - 启动时请求远程版本JSON，对比versionCode
 * - 有新版本弹窗显示更新日志
 * - 点击更新后台下载APK，完成后自动安装
 *
 * v2.3.0 更新策略（**不再强制升级**）：
 * 商店审核普遍要求"不得强制升级"，且"提示内容须与实际行为一致"，
 * 原来的写死「此版本为强制更新」+ 不可取消 + 返回键退出属于明确的驳回风险。
 * 现在改成：
 * - 弹窗始终可取消，文案与实际行为一致；
 * - 用户点「稍后再说」后，主界面顶部**常驻**一条更新提示，直到更新完成；
 * - 普通更新 24 小时后再提醒一次；服务端标记 forceUpdate 的紧急版本 3 小时后提醒一次；
 * - 后台监控服务每 60 轮也会检查一次，用户不打开 App 也能收到更新提示。
 */
object UpdateChecker {

    // 版本信息JSON地址：优先 GitHub 源站（避免 CDN 缓存导致更新延迟），失败回退 jsDelivr
    private const val VERSION_URL = "https://raw.githubusercontent.com/woooo00/stock-update/main/version.json"
    private const val VERSION_URL_FALLBACK = "https://cdn.jsdelivr.net/gh/woooo00/stock-update@main/version.json"

    /**
     * APK 下载的 CDN 兜底地址（v2.3.1）。
     *
     * `raw.githubusercontent.com` 在部分网络下会断流（实测本机 curl 返回空），
     * 而更新检查拿到的 apkUrl 就是 raw 地址，DownloadManager 直接用它会卡住。
     * 下载前并发探测，主源不通就改走这个 CDN 地址。
     */
    private const val CDN_APK_URL = "https://cdn.jsdelivr.net/gh/woooo00/stock-update@main/stock.apk"

    /** forceUpdate 版本被忽略后的再次提醒间隔：3 小时。 */
    private const val FORCE_REMIND_MS = 3 * 60 * 60_000L

    /** 普通版本被忽略后的再次提醒间隔：24 小时。 */
    private const val NORMAL_REMIND_MS = 24 * 60 * 60_000L

    /** 后台提醒用的通知渠道与通知 ID。 */
    private const val CH_UPDATE = "update_v1"
    private const val NOTIF_UPDATE = 2001

    data class UpdateInfo(
        val versionCode: Int,
        val versionName: String,
        val changelog: String,
        val apkUrl: String,
        /** 服务端标记的紧急版本：提醒更频繁，但同样可以取消。 */
        val forceUpdate: Boolean = false
    )

    /**
     * 检查更新。[onFound] 在检查结束后于主线程回调（无论是否发现新版本）。
     */
    fun check(context: Context, onFound: (() -> Unit)? = null) {
        Thread {
            try {
                var text: String? = null
                // 先请求主源站，失败回退 CDN
                for (url in listOf(VERSION_URL, VERSION_URL_FALLBACK)) {
                    try {
                        val conn = URL(url).openConnection() as HttpURLConnection
                        conn.connectTimeout = 8000
                        conn.readTimeout = 8000
                        conn.requestMethod = "GET"
                        conn.instanceFollowRedirects = true
                        if (conn.responseCode == 200) {
                            text = BufferedReader(InputStreamReader(conn.inputStream, "UTF-8")).readText()
                            conn.disconnect()
                            break
                        }
                        conn.disconnect()
                    } catch (_: Exception) {}
                }
                if (text == null) {
                    AppLogger.e(context, "版本更新", "检查更新", "主源站和CDN均请求失败")
                    notifyFound(context, onFound)
                    return@Thread
                }

                val jsonStr = extractJson(text)
                if (jsonStr == null) {
                    notifyFound(context, onFound)
                    return@Thread
                }
                val json = JSONObject(jsonStr)

                val remoteCode = json.optInt("versionCode", 0)
                val localCode = try {
                    context.packageManager.getPackageInfo(context.packageName, 0).longVersionCode.toInt()
                } catch (e: Exception) { 0 }
                Prefs.updateCheckedAt = System.currentTimeMillis()
                if (remoteCode <= localCode) {
                    // 已是最新（或更新），清掉待更新标记
                    Prefs.savePendingUpdate(context, "")
                    notifyFound(context, onFound)
                    return@Thread
                }

                val info = UpdateInfo(
                    versionCode = remoteCode,
                    versionName = json.optString("versionName", remoteCode.toString()),
                    changelog = json.optString("changelog", "有新版本可用"),
                    apkUrl = json.optString("apkUrl", ""),
                    forceUpdate = json.optBoolean("forceUpdate", false)
                )
                Prefs.savePendingUpdate(context, toJson(info))
                AppLogger.i(context, "版本更新", "发现新版本 v${info.versionName}（versionCode $remoteCode）")

                val act = context as? android.app.Activity
                if (act != null) {
                    act.runOnUiThread {
                        onFound?.invoke()
                        maybePrompt(context, info)
                    }
                } else {
                    // 后台服务发现新版本：发通知提醒，用户点通知进 App 更新
                    notifyFound(context, onFound)
                    notifyInBackground(context, info)
                }
            } catch (e: Exception) {
                AppLogger.e(context, "版本更新", "检查更新", e.message ?: "网络异常", e)
                notifyFound(context, onFound)
            }
        }.start()
    }

    private fun notifyFound(context: Context, onFound: (() -> Unit)?) {
        if (onFound == null) return
        (context as? android.app.Activity)?.runOnUiThread { onFound() }
    }

    /**
     * 后台上下文（前台服务）发现新版本时发一条通知：
     * 用户不打开 App 也能收到提醒，点通知直接进主界面。
     */
    private fun notifyInBackground(context: Context, info: UpdateInfo) {
        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                nm.createNotificationChannel(
                    NotificationChannel(CH_UPDATE, "版本更新", NotificationManager.IMPORTANCE_DEFAULT)
                        .apply { description = "有新版本可用时提醒" }
                )
            }
            val open = PendingIntent.getActivity(
                context, 0, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = Notification.Builder(context, CH_UPDATE)
                .setSmallIcon(R.drawable.ic_stat_monitor)
                .setContentTitle("发现新版本 v${info.versionName}")
                .setContentText("点击前往更新")
                .setAutoCancel(true)
                .setContentIntent(open)
                .build()
            nm.notify(NOTIF_UPDATE, n)
        } catch (e: Exception) {
            AppLogger.e(context, "版本更新", "后台更新提醒", e.message ?: "通知发送失败", e)
        }
    }

    /** 已发现但还没安装的新版本；没有则返回 null。 */
    fun pendingUpdate(context: Context): UpdateInfo? {
        val raw = Prefs.pendingUpdate(context)
        if (raw.isBlank()) return null
        return try {
            val o = JSONObject(raw)
            UpdateInfo(
                versionCode = o.optInt("versionCode", 0),
                versionName = o.optString("versionName", ""),
                changelog = o.optString("changelog", ""),
                apkUrl = o.optString("apkUrl", ""),
                forceUpdate = o.optBoolean("forceUpdate", false)
            )
        } catch (e: Exception) { null }
    }

    /** 由主界面的常驻提示条调用：直接拉起更新弹窗。 */
    fun promptUpdate(context: Context) {
        val info = pendingUpdate(context) ?: return
        showUpdateDialog(context, info)
    }

    /**
     * 只有在「忽略间隔」到期后才弹窗，避免用户点一次「稍后再说」就被反复打扰。
     */
    private fun maybePrompt(context: Context, info: UpdateInfo) {
        val last = Prefs.updateDismissAt
        if (last > 0L) {
            val remind = if (info.forceUpdate) FORCE_REMIND_MS else NORMAL_REMIND_MS
            if (System.currentTimeMillis() - last < remind) return
        }
        showUpdateDialog(context, info)
    }

    private fun toJson(i: UpdateInfo): String = JSONObject().apply {
        put("versionCode", i.versionCode)
        put("versionName", i.versionName)
        put("changelog", i.changelog)
        put("apkUrl", i.apkUrl)
        put("forceUpdate", i.forceUpdate)
    }.toString()

    private fun extractJson(text: String): String? {
        // 尝试直接解析
        try { JSONObject(text.trim()); return text.trim() } catch (_: Exception) {}
        // 尝试从页面里找 {"versionCode":...}
        val start = text.indexOf("{\"versionCode\"")
        if (start < 0) return null
        var depth = 0
        for (i in start until text.length) {
            when (text[i]) {
                '{' -> depth++
                '}' -> { depth--; if (depth == 0) return text.substring(start, i + 1) }
            }
        }
        return null
    }

    /**
     * 更新弹窗：**可取消**，文案与实际行为一致（不再宣称"强制更新"）。
     * 用户选择「稍后再说」后记录时间，由常驻提示条 + 定时再提醒促成更新。
     */
    private fun showUpdateDialog(context: Context, info: UpdateInfo) {
        val msg = if (info.forceUpdate) {
            info.changelog + "\n\n这个版本包含必要的修复，建议尽快更新。"
        } else {
            info.changelog + "\n\n建议更新以获得最新功能和修复。"
        }
        AlertDialog.Builder(context)
            .setTitle(if (info.forceUpdate) "建议更新到 v${info.versionName}" else "发现新版本 v${info.versionName}")
            .setMessage(msg)
            .setCancelable(true)
            .setPositiveButton("立即更新") { _, _ ->
                downloadWithProgress(context, info.apkUrl)
            }
            .setNegativeButton("稍后再说") { _, _ ->
                Prefs.updateDismissAt = System.currentTimeMillis()
            }
            .setOnCancelListener {
                Prefs.updateDismissAt = System.currentTimeMillis()
            }
            .show()
    }

    /**
     * 带进度条的下载：弹窗实时显示进度，下载完成自动安装。
     *
     * **下载前先探测可用源**（v2.3.1 修复）：
     * 原来只把 `version.json` 里的 apkUrl 丢给 DownloadManager，
     * 而那个地址指向 `raw.githubusercontent.com` —— 在部分网络下会断流
     * （实测本机 curl 该地址返回空），表现是进度条卡在 0% 直到超时。
     *
     * 现在先并发探测各候选源，挑一个能返回 200 的再交给 DownloadManager，
     * 并且保留 CDN 兜底，主源不通时自动改走 jsDelivr。
     */
    private fun downloadWithProgress(context: Context, url: String) {
        if (url.isBlank()) {
            AppLogger.e(context, "版本更新", "下载更新包", "下载地址未配置")
            Toast.makeText(context, "下载地址未配置", Toast.LENGTH_SHORT).show()
            return
        }

        // 候选源：主源在前，CDN 兜底在后
        val candidates = ArrayList<String>()
        candidates.add(url)
        val cdn = CDN_APK_URL
        if (!cdn.isBlank() && !candidates.contains(cdn)) candidates.add(cdn)

        Thread {
            val picked = pickReachable(context, candidates)
            if (picked == null) {
                AppLogger.e(context, "版本更新", "下载更新包", "所有下载源均不可达")
                (context as? android.app.Activity)?.runOnUiThread {
                    Toast.makeText(context, "下载失败：网络无法连接更新服务器，请换个网络再试", Toast.LENGTH_LONG).show()
                }
                return@Thread
            }
            (context as? android.app.Activity)?.runOnUiThread {
                startDownload(context, picked)
            }
        }.start()
    }

    /**
     * 并发探测候选源，返回第一个能返回 200 的地址。
     * 探测用 HEAD（不下载正文），失败就直接换下一个。
     */
    private fun pickReachable(context: Context, candidates: List<String>): String? {
        val pool = java.util.concurrent.Executors.newFixedThreadPool(candidates.size)
        try {
            val futures = candidates.map { u ->
                pool.submit<String?> {
                    try {
                        val conn = URL(u).openConnection() as HttpURLConnection
                        conn.requestMethod = "HEAD"
                        conn.connectTimeout = 8000
                        conn.readTimeout = 8000
                        conn.instanceFollowRedirects = true
                        val code = conn.responseCode
                        conn.disconnect()
                        if (code in 200..299) u else null
                    } catch (e: Exception) {
                        null
                    }
                }
            }
            for (f in futures) {
                val ok = try { f.get(12, java.util.concurrent.TimeUnit.SECONDS) } catch (e: Exception) { null }
                if (ok != null) return ok
            }
            return null
        } finally {
            pool.shutdownNow()
        }
    }

    /** 真正把下载任务交给系统 DownloadManager。 */
    private fun startDownload(context: Context, url: String) {
        try {
            val request = DownloadManager.Request(Uri.parse(url))
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            request.setTitle("库存提醒助手 更新下载中")
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "stock_monitor_update.apk")
            request.setMimeType("application/vnd.android.package-archive")

            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val downloadId = dm.enqueue(request)
            AppLogger.i(context, "版本更新", "开始下载更新包：$url")

            // 进度条弹窗
            val progressDialog = android.app.ProgressDialog(context).apply {
                setTitle("正在下载更新")
                setMessage("下载中... 0%")
                setProgressStyle(android.app.ProgressDialog.STYLE_HORIZONTAL)
                setMax(100)
                setCancelable(false)
                setButton(android.content.DialogInterface.BUTTON_NEGATIVE, "退出") { _, _ ->
                    dm.remove(downloadId)
                    (context as? android.app.Activity)?.finish()
                }
                show()
            }

            // 定时查询下载进度
            val handler = android.os.Handler(android.os.Looper.getMainLooper())
            val progressRunnable = object : Runnable {
                override fun run() {
                    val query = DownloadManager.Query().setFilterById(downloadId)
                    dm.query(query).use { cursor ->
                        if (cursor.moveToFirst()) {
                            val status = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                            if (status == DownloadManager.STATUS_SUCCESSFUL) {
                                handler.removeCallbacks(this)
                                progressDialog.dismiss()
                                AppLogger.i(context, "版本更新", "更新包下载完成，开始安装")
                                installApk(context, downloadId)
                                return@use
                            }
                            if (status == DownloadManager.STATUS_FAILED) {
                                handler.removeCallbacks(this)
                                progressDialog.dismiss()
                                val reason = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
                                AppLogger.e(context, "版本更新", "下载更新包", "下载失败，错误码$reason")
                                Toast.makeText(context, "下载失败（错误码$reason），请重试或通知栏查看", Toast.LENGTH_LONG).show()
                                return@use
                            }
                            val bytesDownloaded = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                            val bytesTotal = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                            if (bytesTotal > 0) {
                                val progress = (bytesDownloaded * 100 / bytesTotal).toInt()
                                progressDialog.progress = progress
                                progressDialog.setMessage("下载中... $progress%")
                            }
                        }
                    }
                    handler.postDelayed(this, 500)
                }
            }
            handler.post(progressRunnable)

            // 注册下载完成广播（备用，进度条轮询为主）
            // Android 13+ 必须显式指定 RECEIVER_NOT_EXPORTED flag，否则注册抛异常
            try {
                val receiver = object : BroadcastReceiver() {
                    override fun onReceive(ctx: Context?, intent: Intent?) {
                        val id = intent?.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1) ?: -1
                        if (id == downloadId) {
                            try { handler.removeCallbacks(progressRunnable) } catch (_: Exception) {}
                            try { progressDialog.dismiss() } catch (_: Exception) {}
                            installApk(ctx ?: return, downloadId)
                            try { ctx?.unregisterReceiver(this) } catch (_: Exception) {}
                        }
                    }
                }
                val filter = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
                } else {
                    context.registerReceiver(receiver, filter)
                }
            } catch (e: Exception) {
                // 广播注册失败不影响下载（进度轮询仍能完成安装）
                AppLogger.e(context, "版本更新", "注册下载完成广播", e.message ?: "注册失败", e)
            }

        } catch (e: Exception) {
            AppLogger.e(context, "版本更新", "下载更新包", e.message ?: "下载失败", e)
            Toast.makeText(context, "下载失败：${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun installApk(context: Context, downloadId: Long) {
        try {
            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val uri: Uri? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                dm.getUriForDownloadedFile(downloadId)
            } else {
                Uri.parse("file://${Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)}/stock_monitor_update.apk")
            }
            if (uri == null) {
                AppLogger.e(context, "版本更新", "安装更新", "安装失败：系统未返回已下载文件的位置（downloadId=$downloadId）")
                Toast.makeText(context, "未找到已下载的安装包，请重新下载", Toast.LENGTH_LONG).show()
                return
            }

            // Android 8.0+ 要求用户先授予本应用「安装未知来源应用」权限，
            // 未授权时直接拉起安装会失败（INSTALL_FAILED...），这里引导用户去系统设置开启。
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                !context.packageManager.canRequestPackageInstalls()
            ) {
                AppLogger.i(context, "版本更新", "尚未获得安装未知来源应用权限，引导用户开启")
                promptInstallPermission(context)
                return
            }

            val intent = Intent(Intent.ACTION_VIEW)
            intent.setDataAndType(uri, "application/vnd.android.package-archive")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            AppLogger.e(context, "版本更新", "安装更新", e.message ?: "安装失败", e)
            Toast.makeText(context, "请手动到下载目录安装APK", Toast.LENGTH_LONG).show()
        }
    }

    /**
     * 引导用户到系统设置授予「安装未知来源应用」权限。
     * 说明文字与权限申请理由一致：本应用只安装自身官方更新包。
     */
    private fun promptInstallPermission(context: Context) {
        val msg = "安装更新包需要您授予本应用「安装未知来源应用」权限。\n\n" +
            "该权限仅用于安装本应用自身的官方更新包，不会安装任何第三方应用。" +
            "开启后回到本应用即可完成更新。"
        val act = context as? android.app.Activity
        val builder = android.app.AlertDialog.Builder(context)
            .setTitle("需要安装权限")
            .setMessage(msg)
            .setCancelable(true)
            .setNegativeButton("暂不更新", null)
            .setPositiveButton("去设置开启") { _, _ ->
                try {
                    val i = Intent(
                        android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:${context.packageName}")
                    )
                    if (act != null) {
                        act.startActivity(i)
                    } else {
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(i)
                    }
                } catch (e: Exception) {
                    // 少数 ROM 没有这个页面，退回到应用详情页
                    try {
                        val i = Intent(
                            android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:${context.packageName}")
                        )
                        if (act != null) {
                            act.startActivity(i)
                        } else {
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            context.startActivity(i)
                        }
                    } catch (e2: Exception) {
                        AppLogger.e(context, "版本更新", "打开安装权限设置", e2.message ?: "打开失败", e2)
                    }
                }
            }
        builder.show()
    }
}
