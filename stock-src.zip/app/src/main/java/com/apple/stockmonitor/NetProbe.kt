package com.apple.stockmonitor

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities

/**
 * 网络类型探测：用于「WiFi 跑最高频、移动数据自动降速」策略。
 *
 * 判定用所有网络的 transport（`hasTransport`），而不是只看 activeNetwork：
 * 开了 VPN 时 activeNetwork 的 transport 可能是 VPN，会被误判成移动数据而白白降速。
 *
 * 用 `hasTransport` 而不是 `transportTypes` 位掩码：
 * 后者是 API 34 才引入的新接口，公开 SDK 里取不到。
 */
object NetProbe {

    /** 当前是否有 WiFi 连接。 */
    fun isWifi(ctx: Context): Boolean = hasWifiTransport(ctx)

    /** 是否按「计费网络」处理：没有 WiFi 就按移动数据对待。 */
    fun isMetered(ctx: Context): Boolean = !isWifi(ctx)

    /** 网络类型文案，用于界面提示。 */
    fun label(ctx: Context): String = if (isWifi(ctx)) "WiFi" else "移动数据"

    /**
     * 任一网络带 WiFi transport 就算 WiFi。
     *
     * 遍历 allNetworks 而不是只看 activeNetwork：开 VPN 时 activeNetwork 是 VPN，
     * 但底层仍然跑在 WiFi 上，按位掩码判定会误判成移动数据而白白降速。
     */
    private fun hasWifiTransport(ctx: Context): Boolean = try {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var found = false
        for (nw in cm.allNetworks) {
            val caps = cm.getNetworkCapabilities(nw) ?: continue
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                found = true
                break
            }
        }
        found
    } catch (e: Exception) {
        false
    }
}
