package com.apple.stockmonitor

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities

/**
 * 网络类型探测：用于「WiFi 跑最高频、移动数据自动降速」策略。
 *
 * 判定用所有网络的 transport 位掩码，而不是只看 activeNetwork：
 * 开了 VPN 时 activeNetwork 的 transport 可能是 VPN，会被误判成移动数据而白白降速。
 */
object NetProbe {

    /** 当前是否有 WiFi 连接。 */
    fun isWifi(ctx: Context): Boolean =
        (transportMask(ctx) and NetworkCapabilities.TRANSPORT_WIFI) != 0

    /** 是否按「计费网络」处理：没有 WiFi 就按移动数据对待。 */
    fun isMetered(ctx: Context): Boolean = !isWifi(ctx)

    /** 网络类型文案，用于界面提示。 */
    fun label(ctx: Context): String = if (isWifi(ctx)) "WiFi" else "移动数据"

    private fun transportMask(ctx: Context): Int = try {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var mask = 0
        for (nw in cm.allNetworks) {
            val caps = cm.getNetworkCapabilities(nw) ?: continue
            mask = mask or caps.transportTypes
        }
        mask
    } catch (e: Exception) {
        0
    }
}
