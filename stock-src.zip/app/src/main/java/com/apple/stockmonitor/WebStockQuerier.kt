package com.apple.stockmonitor

import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * 库存查询引擎：原生 HTTP 直连苹果开放端点 /shop/retail/pickup-message。
 *
 * 该端点在普通网络（含手机网络、服务器）返回 200，不像 fulfillment-messages
 * 那样被 541 拦截。按 location（广东 广州）返回附近门店，再按门店编号过滤，
 * 读取 partsAvailability[part].pickupDisplay（available=有货）。
 *
 * 查询在后台线程执行，结果统一切回主线程回调；保留 Listener/Outcome 接口，
 * 调用方（MainActivity / MonitorService）无需改动。
 */
object WebStockQuerier {

    /** available=true 有货，false 无货，null=本轮失败（下次重试，不改状态）。 */
    data class Outcome(val available: Boolean?, val detail: String)

    interface Listener {
        fun onResult(o: Outcome)
    }

    private const val BASE = "https://www.apple.com.cn/shop/retail/pickup-message"
    private const val UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    private val main = Handler(Looper.getMainLooper())

    /** 后台线程阻塞查询，主线程回调。 */
    fun query(context: android.content.Context, part: String, store: String, cb: Listener) {
        Thread {
            val out: Outcome = try {
                doCheck(part, store)
            } catch (e: Exception) {
                Outcome(null, e.message ?: "网络异常，稍后重试")
            }
            main.post { cb.onResult(out) }
        }.start()
    }

    private fun doCheck(part: String, store: String): Outcome {
        // 按门店所在城市取 location（"省 市"），全国 25 城门店均可命中
        val loc = Catalog.locationForStore(store)
        val url = BASE + "?pl=true&mts.0=regular&parts.0=" + enc(part) +
            "&location=" + enc(loc)
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15000
            readTimeout = 15000
            setRequestProperty("User-Agent", UA)
            setRequestProperty("Accept", "application/json, text/plain, */*")
            setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9")
            setRequestProperty("Referer", "https://www.apple.com.cn/shop/buy-iphone")
        }
        try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = BufferedReader(InputStreamReader(stream, "UTF-8")).use { it.readText() }
            if (code !in 200..299) throw RuntimeException("HTTP $code（稍后重试）")

            val json = JSONObject(text)
            val stores = json.optJSONObject("body")?.optJSONArray("stores")
                ?: throw RuntimeException("响应结构变化，稍后重试")
            if (stores.length() == 0) throw RuntimeException("附近无直营店，稍后重试")

            // 指定门店：按 storeNumber 精确匹配；全国：任一店有货即报
            var matched = false
            for (i in 0 until stores.length()) {
                val s = stores.getJSONObject(i)
                if (store.isNotBlank() && s.optString("storeNumber", "") != store) continue
                matched = true
                val pa = s.optJSONObject("partsAvailability")?.optJSONObject(part)
                    ?: continue
                val disp = pa.optString("pickupDisplay", "")
                val quote = pa.optString("pickupSearchQuote", "").ifEmpty { disp }
                val name = s.optString("storeName", "").trim()
                if (disp.equals("available", true)) {
                    return Outcome(true, "$name：$quote")
                }
                // 指定门店且已匹配到该店、但无货，直接返回无货
                if (store.isNotBlank()) {
                    return Outcome(false, "$name：$quote")
                }
            }
            if (!matched && store.isNotBlank()) {
                return Outcome(null, "本次未返回所选门店，稍后重试")
            }
            // 全国模式：遍历完无任一有货
            return Outcome(false, "所选门店暂无供应")
        } finally {
            conn.disconnect()
        }
    }

    fun destroy() {
        // 原生 HTTP 无 WebView 资源需要释放
    }

    private fun enc(v: String): String = URLEncoder.encode(v, "UTF-8")
}
