package com.apple.stockmonitor

import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * 库存查询引擎：原生 HTTP 直连苹果开放端点 /shop/retail/pickup-message。
 *
 * 核心设计（v2.3.0）：**一次请求可携带多个 part**（`parts.0` / `parts.1` …），
 * 因此同一 location 下的多个监控目标合并成一次请求。
 * 实测 16 个 part 一次请求 HTTP 200，响应体大小与单 part 相同（按门店数计），
 * 合并省的是请求次数（触发苹果官网风控的正是请求次数），不省字节数。
 *
 * 该端点在普通网络（含手机网络、服务器）返回 200，不像 fulfillment-messages
 * 那样被 541 拦截。按 location（广东 广州）返回附近门店，再按门店编号过滤，
 * 读取 partsAvailability[part].pickupDisplay（available=有货）。
 *
 * 查询在后台线程执行，结果统一切回主线程回调。
 */
object WebStockQuerier {

    /** available=true 有货，false 无货，null=本轮失败（下次重试，不改状态）。 */
    data class Outcome(val available: Boolean?, val detail: String)

    /** 批量结果里的一家门店。 */
    data class BatchStore(
        val code: String,
        val name: String,
        /** part 号 -> (pickupDisplay, pickupSearchQuote) */
        val parts: Map<String, Pair<String, String>>,
        /** 接口返回的城市名（实测有值，用于动态门店目录按城市分组）。 */
        val city: String = "",
        /** 接口返回的省份名。 */
        val state: String = "",
        /**
         * 门店对象里**是否带** `partsAvailability` 字段。
         *
         * 带这个字段但里面没有目标 part → 该店确实不提供此型号（可判无货）；
         * 连这个字段都没有 → 这家店离得远、接口没给数据（**不能判无货**，要重试）。
         *
         * 宽门店集（pl=false）下响应里会混进邻近片区的店，
         * 远端店经常没有库存数据，不区分这两者就会把「数据不可用」误报成「无货」。
         */
        val hasAvailability: Boolean = false
    )

    /** 一次批量查询的结果。 */
    data class BatchResult(
        val location: String,
        val stores: List<BatchStore> = emptyList(),
        /** 是否被苹果官网风控（HTTP 541），需要触发熔断。 */
        val limited: Boolean = false,
        /** 失败原因；空串表示成功。 */
        val error: String = ""
    ) {
        val ok: Boolean get() = error.isEmpty() && !limited
    }

    interface Listener {
        fun onResult(o: Outcome)
    }

    private const val BASE = "https://www.apple.com.cn/shop/retail/pickup-message"
    private const val UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    /**
     * 接口的 `pl` 参数取值：`false` = 宽门店集（该片区 + 邻近片区）。
     *
     * 实测（2026-10-26，24 个内置 location 全量巡检）：
     * - `pl=true`  → 只返回该片区**精确**门店（广东 广州 = 5 家），窄但准；
     * - `pl=false` → 返回该片区 + 邻近片区门店（广东 广州 = 12 家），
     *   且 24 个 location 合计覆盖内置 49/49 家门店，无一遗漏。
     *
     * 关键差异：**R571（南宁万象城）只在 `pl=false` 的响应里出现**，
     * 且带完整 partsAvailability（`pickupDisplay=available` / "今天可取货"）。
     * `pl=true` 时它一次都不出现——这正是之前误判「南宁店维护中、永远查不到」的根因。
     *
     * 代价是响应体变大（广东 广州：28KB → 66KB），但响应体大小按**门店数**计、
     * 与 part 数无关，合并请求的收益（省请求次数）远大于多传的这几十 KB。
     *
     * 所以取宽集。窄集的唯一优点是省流量，而苹果的风控按**请求次数**算。
     */
    private const val PL_PARAM = "false"

    private val main = Handler(Looper.getMainLooper())

    /**
     * 批量查询：一次请求覆盖同 location 下的多个 part。回调在主线程执行。
     *
     * 结果里的 `limited=true` 表示撞上 HTTP 541，调用方应触发熔断。
     */
    fun queryBatch(
        context: android.content.Context,
        location: String,
        parts: List<String>,
        cb: (BatchResult) -> Unit
    ) {
        Thread {
            val res: BatchResult = try {
                doBatch(context, location, parts)
            } catch (e: Exception) {
                AppLogger.e(context, "库存查询", "批量查询 $location（${parts.size} 个型号）",
                    e.message ?: "网络异常", e)
                BatchResult(location, error = e.message ?: "网络异常，稍后重试")
            }
            main.post { cb(res) }
        }.start()
    }

    /** 单目标查询（内部走同一批量接口）。 */
    fun query(context: android.content.Context, part: String, store: String, cb: Listener) {
        val loc = Catalog.locationForStore(context, store)
        queryBatch(context, loc, listOf(part)) { res ->
            if (!res.ok) {
                cb.onResult(Outcome(null, res.error.ifEmpty { "查询失败，稍后重试" }))
                return@queryBatch
            }
            cb.onResult(resolveOne(res, part, store))
        }
    }

    /**
     * 从批量结果里解析单个「型号 × 门店」目标的结论。
     *
     * - 门店没出现在本次返回里 → 失败（本轮漏了，下轮重试）
     * - 门店在、但**没有** `partsAvailability` 数据（远端店，接口没给）→ 失败重试。
     *   宽门店集下远端店经常没有数据，**不能当成无货**，否则会误报。
     * - 门店在、有数据但没回显这个 part，同片区别的店有 → 该店暂不提供此型号（无货）
     * - 门店在、有数据，整个片区都没有这个 part → 型号可能已下架（失败，提示用户）
     */
    fun resolveOne(res: BatchResult, part: String, store: String): Outcome {
        val st = res.stores.firstOrNull { it.code == store }
        if (st == null) return Outcome(null, "本次未返回所选门店，稍后重试")
        val hit = st.parts[part]
        if (hit == null) {
            // 该店压根没有库存数据（远端店 / 接口未覆盖）：判失败重试，不误报无货
            if (!st.hasAvailability) {
                return Outcome(null, "${st.name}：本次无该型号的库存数据，稍后重试")
            }
            val elsewhere = res.stores.any { it.parts.containsKey(part) }
            return if (elsewhere) {
                Outcome(false, "${st.name}：暂未提供此型号")
            } else {
                Outcome(null, "该型号暂无库存数据（可能已下架）")
            }
        }
        val disp = hit.first
        val quote = hit.second.ifEmpty { disp }
        val detail = "${st.name}：$quote"
        return if (disp.equals("available", true)) Outcome(true, detail) else Outcome(false, detail)
    }

    private fun targetDesc(part: String, store: String): String {
        val model = Catalog.parsePart(part).let { (sz, st, cl) -> "$sz · $st · $cl" }
        val storeName = if (store.isBlank()) "全国门店" else Catalog.storeLabel(store)
        return "$model / $storeName"
    }

    private fun doBatch(context: android.content.Context, location: String, parts: List<String>): BatchResult {
        val query = StringBuilder("?pl=").append(PL_PARAM).append("&mts.0=regular")
        parts.forEachIndexed { i, p -> query.append("&parts.$i=").append(enc(p)) }
        query.append("&location=").append(enc(location))
        val url = BASE + query.toString()
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15000
            readTimeout = 20000
            setRequestProperty("User-Agent", UA)
            setRequestProperty("Accept", "application/json, text/plain, */*")
            setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9")
            setRequestProperty("Referer", "https://www.apple.com.cn/shop/buy-iphone")
        }
        try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = BufferedReader(InputStreamReader(stream, "UTF-8")).use { it.readText() }
            if (code == 541) {
                AppLogger.e(context, "库存查询", "批量查询 $location（${parts.size} 个型号）",
                    "HTTP 541：访问过于频繁，已被苹果官网临时风控")
                return BatchResult(location, limited = true, error = "HTTP 541 被官网限流")
            }
            if (code !in 200..299) {
                AppLogger.e(context, "库存查询", "批量查询 $location（${parts.size} 个型号）", "HTTP $code（稍后重试）")
                return BatchResult(location, error = "HTTP $code（稍后重试）")
            }

            val json = JSONObject(text)
            val stores = json.optJSONObject("body")?.optJSONArray("stores")
            if (stores == null) {
                AppLogger.e(context, "库存查询", "批量查询 $location", "响应结构变化，稍后重试")
                return BatchResult(location, error = "响应结构变化，稍后重试")
            }
            if (stores.length() == 0) {
                AppLogger.e(context, "库存查询", "批量查询 $location", "附近无直营店，稍后重试")
                return BatchResult(location, error = "附近无直营店，稍后重试")
            }

            val list = ArrayList<BatchStore>(stores.length())
            for (i in 0 until stores.length()) {
                val s = stores.getJSONObject(i)
                val m = HashMap<String, Pair<String, String>>()
                val pa = s.optJSONObject("partsAvailability")
                if (pa != null) {
                    val keys = pa.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        val o = pa.optJSONObject(k) ?: continue
                        m[k] = o.optString("pickupDisplay", "") to o.optString("pickupSearchQuote", "")
                    }
                }
                list.add(BatchStore(
                    code = s.optString("storeNumber", ""),
                    name = s.optString("storeName", "").trim(),
                    parts = m,
                    city = s.optString("city", "").trim(),
                    state = s.optString("state", "").trim(),
                    hasAvailability = pa != null
                ))
            }
            return BatchResult(location, stores = list)
        } finally {
            conn.disconnect()
        }
    }

    fun destroy() {
        // 原生 HTTP 无 WebView 资源需要释放
    }

    private fun enc(v: String): String = URLEncoder.encode(v, "UTF-8")
}

/**
 * 一个 location 分组：共享同一片区的监控目标。
 * 同一组的所有 part 可以在一次请求里全部拿到。
 */
data class LocationGroup(val location: String, val targets: List<Prefs.Target>) {
    val parts: List<String> = targets.map { it.part }.distinct()
}

/**
 * 按 location 把监控目标分组——**请求合并的核心**。
 *
 * 接口的 location 是区域级语义（"广东 广州" 同时覆盖广州和深圳的门店），
 * 所以同一个 location 下的所有目标只需一次请求。
 */
fun groupByLocation(context: android.content.Context, targets: List<Prefs.Target>): List<LocationGroup> {
    val map = LinkedHashMap<String, MutableList<Prefs.Target>>()
    targets.forEach { t ->
        val loc = Catalog.locationForStore(context, t.store)
        map.getOrPut(loc) { ArrayList() }.add(t)
    }
    return map.map { (loc, ts) -> LocationGroup(loc, ts) }
}
