package com.apple.stockmonitor

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import androidx.core.content.FileProvider
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 错误日志系统：
 * - 所有错误统一写入本地日志文件（仅保存在本机）
 * - 每条错误附带「可能原因 + 解决建议」，未识别错误提示提交开发人员
 * - 可一键导出完整报告（含设备环境信息），通过系统分享发送
 */
object AppLogger {

    private const val DIR = "logs"
    private const val FILE_NAME = "error_log.txt"
    private const val MAX_BYTES = 300_000 // 日志文件超过 300KB 自动截断旧内容

    private fun logDir(context: Context): File =
        File(context.filesDir, DIR).apply { if (!exists()) mkdirs() }

    private fun logFile(context: Context): File = File(logDir(context), FILE_NAME)

    /** 记录一条错误。scene：场景（库存查询/版本更新等）；target：目标描述；error：错误信息。 */
    @Synchronized
    fun e(context: Context, scene: String, target: String, error: String, t: Throwable? = null) {
        try {
            val sb = StringBuilder()
            sb.append("================ 错误记录 ================\n")
            sb.append("时间：").append(now()).append('\n')
            sb.append("场景：").append(scene).append('\n')
            if (target.isNotBlank()) sb.append("目标：").append(target).append('\n')
            sb.append("错误：").append(error).append('\n')
            sb.append('\n').append(diagnosis(error))
            if (t != null) {
                val sw = StringWriter()
                t.printStackTrace(PrintWriter(sw))
                var trace = sw.toString()
                if (trace.length > 1500) trace = trace.substring(0, 1500) + "\n…（堆栈已截断）"
                sb.append('\n').append("【技术堆栈】\n").append(trace).append('\n')
            }
            sb.append("------------------------------------------\n\n")

            val f = logFile(context)
            val existed = f.exists()
            // 超过上限时保留最近的一半内容
            if (existed && f.length() > MAX_BYTES) {
                val old = f.readText()
                val keep = old.takeLast(MAX_BYTES / 2)
                f.writeText(keep)
            }
            f.appendText(sb.toString())
        } catch (_: Throwable) {
            // 日志失败不能影响主流程
        }
    }

    /** 普通信息（如版本更新检查、监控启停），帮助排查上下文。 */
    @Synchronized
    fun i(context: Context, scene: String, msg: String) {
        try {
            val f = logFile(context)
            if (f.exists() && f.length() > MAX_BYTES) {
                val old = f.readText()
                f.writeText(old.takeLast(MAX_BYTES / 2))
            }
            f.appendText("[${now()}] $scene：$msg\n")
        } catch (_: Throwable) {}
    }

    /** 根据错误文本匹配「可能原因 + 解决建议」。 */
    fun diagnosis(error: String): String {
        val s = error.lowercase(Locale.ROOT)
        return when {
            s.contains("541") ->
                "【可能原因】\n" +
                "1、访问苹果官网接口过于频繁，被官网临时风控（最常见）；\n" +
                "2、当前网络的公网 IP 已被临时限制（同一 WiFi 下多个设备/程序高频访问都会触发）。\n\n" +
                "【解决建议】\n" +
                "1、把监控间隔调大到 10 秒以上，关闭其他同时访问苹果官网的程序；\n" +
                "2、切换网络：WiFi 和手机流量互相切换，或重启路由器/光猫以更换公网 IP；\n" +
                "3、风控通常等待 10-30 分钟自动恢复，期间不要反复点查询；\n" +
                "4、恢复后请先手动查询一次确认，再启动监控。"

            s.contains("403") ->
                "【可能原因】\n" +
                "1、当前网络被苹果官网拒绝访问（代理、VPN 或机房 IP 容易触发）；\n" +
                "2、请求被网络环境拦截。\n\n" +
                "【解决建议】\n" +
                "1、关闭 VPN、代理、加速器后重试；\n" +
                "2、WiFi 与手机流量互相切换；\n" +
                "3、用手机浏览器打开 apple.com.cn 确认网络本身正常。"

            s.contains("404") ->
                "【可能原因】\n" +
                "1、型号编号（part）已失效，或苹果官网接口地址调整；\n" +
                "2、苹果官网正在维护。\n\n" +
                "【解决建议】\n" +
                "1、确认 App 已升级到最新版；\n" +
                "2、稍后重试；若持续出现请导出日志提交给开发人员。"

            s.contains("http 5") || s.contains("500") || s.contains("502") || s.contains("503") ->
                "【可能原因】\n" +
                "苹果官网服务器临时异常或维护。\n\n" +
                "【解决建议】\n" +
                "1、等待几分钟后重试；\n" +
                "2、用浏览器打开 apple.com.cn 确认官网是否正常；\n" +
                "3、持续超过 1 小时请导出日志提交给开发人员。"

            s.contains("timeout") || s.contains("timed out") || s.contains("超时") ||
                s.contains("connect") || s.contains("etimedout") || s.contains("unreachable") ->
                "【可能原因】\n" +
                "1、当前网络连接苹果官网超时（网络慢、信号弱或不稳定）；\n" +
                "2、路由器/运营商到苹果服务器的链路拥堵。\n\n" +
                "【解决建议】\n" +
                "1、WiFi 与手机流量互相切换后重试；\n" +
                "2、WiFi 信号弱时靠近路由器，或重启路由器；\n" +
                "3、关闭 VPN、代理、加速器；\n" +
                "4、如果浏览器也打不开苹果官网，说明是网络问题，等网络恢复。"

            s.contains("unknownhost") || s.contains("unable to resolve") || s.contains("dns") ||
                s.contains("无网络") || s.contains("network") ->
                "【可能原因】\n" +
                "手机当前没有可用网络，或 DNS 解析失败。\n\n" +
                "【解决建议】\n" +
                "1、确认手机能正常上网（随便打开一个网页）；\n" +
                "2、开关一次飞行模式，或重启手机；\n" +
                "3、WiFi 与手机流量互相切换；\n" +
                "4、如果连的是公司/校园 WiFi，可能有限制，换家庭网络或流量。"

            s.contains("ssl") || s.contains("handshake") || s.contains("trust") ||
                s.contains("certificate") || s.contains("证书") ->
                "【可能原因】\n" +
                "1、HTTPS 连接被中间人代理（VPN、抓包工具、公司网络代理）；\n" +
                "2、手机系统时间/日期不正确。\n\n" +
                "【解决建议】\n" +
                "1、关闭 VPN、代理、抓包工具后重试；\n" +
                "2、检查系统设置里的日期时间是否准确（开启自动设置）；\n" +
                "3、更换网络后重试。"

            s.contains("响应结构变化") ->
                "【可能原因】\n" +
                "苹果官网库存接口返回内容发生变化（官网改版）。\n\n" +
                "【解决建议】\n" +
                "1、先升级 App 到最新版；\n" +
                "2、若已是最新版仍频繁出现，请导出日志提交给开发人员。"

            s.contains("附近无直营店") ->
                "【可能原因】\n" +
                "所选门店所在城市没有苹果直营店，或官网未返回该城市门店。\n\n" +
                "【解决建议】\n" +
                "1、重新选择有直营店的城市门店（如广州、深圳、北京、上海等）；\n" +
                "2、删除该监控目标后重新添加。"

            s.contains("未返回所选门店") ->
                "【可能原因】\n" +
                "本轮官网返回的门店列表里没有所选门店（偶发，多见于高频访问或官网限流）。\n\n" +
                "【解决建议】\n" +
                "1、偶发属正常，App 会自动在下一轮重试；\n" +
                "2、若连续多轮出现，请调大监控间隔或切换网络；\n" +
                "3、持续出现请导出日志提交给开发人员。"

            s.contains("下载") && (s.contains("错误码") || s.contains("fail") || s.contains("失败")) ->
                downloadDiagnosis(error)

            s.contains("安装") ->
                "【可能原因】\n" +
                "1、系统禁止安装未知来源应用；\n" +
                "2、安装包下载不完整。\n\n" +
                "【解决建议】\n" +
                "1、到系统设置允许安装应用（设置 → 应用 → 特殊权限 → 安装未知应用）；\n" +
                "2、重新下载更新包；\n" +
                "3、仍不行请导出日志提交给开发人员。"

            else ->
                "【可能原因】\n" +
                "暂未识别该错误，可能是 App 未覆盖的新情况或网络异常。\n\n" +
                "【解决建议】\n" +
                "请将本日志完整导出后发送给开发人员（微信/QQ/文件传输助手均可），开发人员会根据日志定位问题。"
        }
    }

    /** DownloadManager 错误码对照。 */
    private fun downloadDiagnosis(error: String): String {
        val code = Regex("(\\d{3,4})").find(error)?.value?.toIntOrNull()
        val specific = when (code) {
            1001 -> "存储文件出错（存储空间不足或下载目录不可写）"
            1002 -> "下载服务器返回了无法处理的状态码"
            1004 -> "下载过程中网络中断（HTTP 数据错误）"
            1005 -> "下载链接重定向次数过多"
            1006 -> "手机存储空间不足"
            1007 -> "找不到目标存储设备（SD 卡被拔出等）"
            1008 -> "下载中断后无法续传"
            1009 -> "下载文件已存在导致冲突"
            1010 -> "下载被系统策略阻止"
            401, 403 -> "下载地址鉴权失败"
            404 -> "下载地址已失效（版本配置可能未更新）"
            in 500..599 -> "下载服务器暂时异常"
            else -> null
        }
        return "【可能原因】\n" +
            (specific ?: "更新包下载失败，多为网络不稳定或存储空间不足。") + "\n\n" +
            "【解决建议】\n" +
            "1、切换稳定网络（WiFi）后重新打开 App 再试；\n" +
            "2、检查手机剩余存储空间；\n" +
            "3、到系统「下载」内容目录删除旧的 stock_monitor_update.apk 后重试；\n" +
            "4、仍失败请导出本日志提交给开发人员。"
    }

    /** 生成完整报告并通过系统分享发送。返回是否成功。 */
    fun export(context: Context): Boolean {
        return try {
            val f = logFile(context)
            if (!f.exists() || f.length() == 0L) return false
            val report = buildReport(context, f.readText())
            // 报告写到单独文件用于分享
            val exportDir = File(context.filesDir, DIR).apply { mkdirs() }
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.CHINA).format(Date())
            val exportFile = File(exportDir, "库存监控日志_$stamp.txt")
            exportFile.writeText(report)

            val uri: Uri = FileProvider.getUriForFile(
                context, "${context.packageName}.fileprovider", exportFile
            )
            val share = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "库存监控错误日志")
                putExtra(Intent.EXTRA_TEXT, "库存监控错误日志（$stamp）")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(share, "导出错误日志").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
            true
        } catch (e: Throwable) {
            false
        }
    }

    fun hasLogs(context: Context): Boolean {
        val f = logFile(context)
        return f.exists() && f.length() > 0L
    }

    fun clear(context: Context): Boolean {
        return try {
            val f = logFile(context)
            if (f.exists()) f.writeText("")
            true
        } catch (e: Throwable) { false }
    }

    private fun buildReport(context: Context, body: String): String {
        val pi = try {
            context.packageManager.getPackageInfo(context.packageName, 0)
        } catch (e: Exception) { null }
        val verName = pi?.versionName ?: "?"
        val verCode = if (Build.VERSION.SDK_INT >= 28) {
            pi?.longVersionCode?.toString() ?: "?"
        } else {
            @Suppress("DEPRECATION")
            pi?.versionCode?.toString() ?: "?"
        }
        val netType = currentNetworkType(context)
        val head = StringBuilder()
        head.append("======== iPhone库存监控 错误日志报告 ========\n")
        head.append("App 版本：").append(verName).append("（versionCode ").append(verCode).append("）\n")
        head.append("手机型号：").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n')
        head.append("系统版本：Android ").append(Build.VERSION.RELEASE)
            .append("（SDK ").append(Build.VERSION.SDK_INT).append("）\n")
        head.append("当前网络：").append(netType).append('\n')
        head.append("导出时间：").append(now()).append('\n')
        head.append("=============================================\n\n")
        head.append(body)
        return head.toString()
    }

    private fun currentNetworkType(context: Context): String {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val nw = cm.activeNetwork ?: return "无网络"
            val caps = cm.getNetworkCapabilities(nw) ?: return "未知"
            when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WiFi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "移动数据"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
                else -> "其他网络"
            }
        } catch (e: Exception) { "未知" }
    }

    private fun now(): String =
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).format(Date())
}
