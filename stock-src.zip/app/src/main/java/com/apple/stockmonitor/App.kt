package com.apple.stockmonitor

import android.app.Application
import android.util.Log
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date

/** 全局 Application，提供 Context 给静态存取，并捕获未处理异常写日志。 */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        AppContext.init(this)
        // 清理旧版单池预算的脏数据（v2.3.1）：
        // 旧实现会把"未来的预留时刻"写进窗口，升级后这些坏时间戳
        // 虽然不再被读取，但留着会让排查问题的人一头雾水。
        RequestBudget.migrate(this)
        // 门店目录：先加载本地缓存（7 天有效），保证首屏就有数据
        StoreDirectory.loadSnapshot(this)
        // 缓存过旧就在后台自动同步一次（不阻塞启动）
        try {
            val needSync = Catalog.locations().any { !StoreDirectory.isFresh(this, it) }
            // 移动数据下**不自动全量同步**（v2.3.1）：
            // 一次全量同步要打十几个片区，流量费且极易撞苹果风控——
            // 而移动数据的出口 IP 是运营商共享的，风控阈值本来就低。
            // 用户想要最新门店表，可以连 WiFi 后在设置里手动点「同步门店列表」。
            val metered = NetProbe.isMetered(this)
            if (needSync && !metered) {
                StoreDirectory.syncAll(this, Prefs.DEFAULT_PART) { synced, total ->
                    android.util.Log.i("StockApp", "门店目录同步完成 $synced/$total")
                }
            } else if (needSync) {
                android.util.Log.i("StockApp", "移动数据下不自动同步门店目录（省流量 + 避开风控）")
            }
        } catch (e: Exception) {
            Log.e("StockApp", "门店目录同步启动失败", e)
        }
        // 全局崩溃捕获：把堆栈写到日志文件，便于闪退排查
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = PrintWriter(StringWriter())
                e.printStackTrace(PrintWriter(sw))
                val ts = SimpleDateFormat("MM-dd HH:mm:ss", java.util.Locale.CHINA).format(Date())
                val dir = File(getExternalFilesDir(null), "logs")
                dir.mkdirs()
                val f = File(dir, "crash_$ts.txt")
                f.writeText("时间: $ts\n线程: ${t.name}\n\n$sw", Charsets.UTF_8)
                Log.e("StockApp", "crash saved to ${f.absolutePath}", e)
            } catch (_: Exception) {}
            defaultHandler?.uncaughtException(t, e)
        }
    }
}

object AppContext {
    private lateinit var ctx: android.content.Context
    fun init(c: android.content.Context) { ctx = c.applicationContext }
    fun get(): android.content.Context = ctx
}
