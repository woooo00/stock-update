package com.apple.stockmonitor

import android.app.Application
import android.util.Log
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date

/** 全局 Application，提供 Context 给静态存取，并捕获未处理异常写日志。 */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        AppContext.init(this)
        // 全局崩溃捕获：把堆栈写到日志文件，便于闪退排查
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                val ts = SimpleDateFormat("MM-dd HH:mm:ss", java.util.Locale.CHINA).format(Date())
                val dir = File(getExternalFilesDir(null), "logs")
                dir.mkdirs()
                val f = File(dir, "crash_$ts.txt")
                f.writeText("时间: $ts\n线程: ${t.name}\n\n$sw", Charsets.UTF_8)
                Log.e("StockApp", "crash saved to ${f.absolutePath}", e)
            } catch (_: Exception) {}
            defaultHandler?.uncaughtException(t, e)
        }
    }
}

object AppContext {
    private lateinit var ctx: android.content.Context
    fun init(c: android.content.Context) { ctx = c.applicationContext }
    fun get(): android.content.Context = ctx
}
