package com.apple.stockmonitor

import android.app.Application

/** 全局 Application，提供 Context 给静态存取。 */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        AppContext.init(this)
    }
}

object AppContext {
    private lateinit var ctx: android.content.Context
    fun init(c: android.content.Context) { ctx = c.applicationContext }
    fun get(): android.content.Context = ctx
}
