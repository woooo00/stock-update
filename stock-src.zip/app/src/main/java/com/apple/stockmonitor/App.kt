package com.apple.stockmonitor

import android.app.Application
import android.util.Log
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date

/** 全局 Application，提供 Context 给静态存取，并捕获未处理异常写日志。 */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        AppContext.init(this)
        // 门店目录：先加载本地缓存（7 天有效），保证首屏就有数据
        StoreDirectory.loadSnapshot(this)
        // 缓存过旧就在后台自动同步一次（不阻塞启动）
        try {
            val needSync = Catalog.locations().any { !StoreDirectory.isFresh(this, it) }
            if (needSync) {
                StoreDirectory.syncAll(this, Prefs.DEFAULT_PART) { synced, total ->
                    android.util.Log.i("StockApp", "门店目录同步完成 $synced/$total")
                }
            }
        } catch (e: Exception) {
            Log.e("StockApp", "门店目录同步启动失败", e)
        }
        // 全局崩溃捕获：把堆栈写到日志文件，便于闪退排查
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = PrintWriter(StringWriter())
                e.printStackTrace(PrintWriter(sw))
                val ts = SimpleDateFormat("MM-dd HH:mm:ss", java.util.Locale.CHINA).format(Date())
                val dir = File(getExternalFilesDir(null), "logs")
                dir.mkdirs()
                val f = File(dir, "crash_$ts.txt")
                f.writeText("时间: $ts\n线程: ${t.name}\n\n$sw", Charsets.UTF_8)
                Log.e("StockApp", "crash saved to ${f.absolutePath}", e)
            } catch (_: Exception) {}
            defaultHandler?.uncaughtException(t, e)
        }
    }
}

object AppContext {
    private lateinit var ctx: android.content.Context
    fun init(c: android.content.Context) { ctx = c.applicationContext }
    fun get(): android.content.Context = ctx
}
